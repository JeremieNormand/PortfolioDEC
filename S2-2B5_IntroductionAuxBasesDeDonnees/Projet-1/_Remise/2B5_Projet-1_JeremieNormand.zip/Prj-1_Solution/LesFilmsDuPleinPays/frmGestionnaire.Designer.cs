﻿
namespace LesFilmsDuPleinPays
{
    partial class frmGestionnaire
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbcGestionnaire = new System.Windows.Forms.TabControl();
            this.tabAccueil = new System.Windows.Forms.TabPage();
            this.tlpPrimaireAccueil = new System.Windows.Forms.TableLayoutPanel();
            this.tlpSecondaireTitresAccueil = new System.Windows.Forms.TableLayoutPanel();
            this.lblSousTitreAccueil = new System.Windows.Forms.Label();
            this.lblTitreAccueil = new System.Windows.Forms.Label();
            this.tlpSecondaireActionsAccueil = new System.Windows.Forms.TableLayoutPanel();
            this.lblActionsAccueil = new System.Windows.Forms.Label();
            this.btnAllerAOngletSelect = new System.Windows.Forms.Button();
            this.btnAllerAOngletUpdate = new System.Windows.Forms.Button();
            this.btnAllerAOngletInsert = new System.Windows.Forms.Button();
            this.btnAllerAOngletDelete = new System.Windows.Forms.Button();
            this.tabSelect = new System.Windows.Forms.TabPage();
            this.tlpPrimaireSelect = new System.Windows.Forms.TableLayoutPanel();
            this.tlpSecondaireResumeSelect = new System.Windows.Forms.TableLayoutPanel();
            this.txtResumeSelect = new System.Windows.Forms.TextBox();
            this.lblResumeSelect = new System.Windows.Forms.Label();
            this.tlpSecondaireTitreEtIdSelect = new System.Windows.Forms.TableLayoutPanel();
            this.lblTitreSelect = new System.Windows.Forms.Label();
            this.lblIdSelect = new System.Windows.Forms.Label();
            this.cbxTitreSelect = new System.Windows.Forms.ComboBox();
            this.txtIdSelect = new System.Windows.Forms.TextBox();
            this.tlpSecondaireDateEtDureeSelect = new System.Windows.Forms.TableLayoutPanel();
            this.lblDateSelect = new System.Windows.Forms.Label();
            this.lblDureeSelect = new System.Windows.Forms.Label();
            this.datDateSelect = new System.Windows.Forms.DateTimePicker();
            this.txtDureeSelect = new System.Windows.Forms.TextBox();
            this.lblDureeMinutesSelect = new System.Windows.Forms.Label();
            this.tlpSecondaireGenreSelect = new System.Windows.Forms.TableLayoutPanel();
            this.txtGenreSelect = new System.Windows.Forms.TextBox();
            this.lblGenreSelect = new System.Windows.Forms.Label();
            this.tlpSecondaireRealisateurSelect = new System.Windows.Forms.TableLayoutPanel();
            this.txtRealisateurSelect = new System.Windows.Forms.TextBox();
            this.lblRealisateurSelect = new System.Windows.Forms.Label();
            this.tlpRolesCompletsSelect = new System.Windows.Forms.TableLayoutPanel();
            this.lblRolesCompletsSelect = new System.Windows.Forms.Label();
            this.dgvRolesCompletsSelect = new System.Windows.Forms.DataGridView();
            this.picAfficheSelect = new System.Windows.Forms.PictureBox();
            this.tabUpdate = new System.Windows.Forms.TabPage();
            this.tlpPrimaireUpdate = new System.Windows.Forms.TableLayoutPanel();
            this.tlpSecondaireResumeUpdate = new System.Windows.Forms.TableLayoutPanel();
            this.txtResumeUpdate = new System.Windows.Forms.TextBox();
            this.lblResumeUpdate = new System.Windows.Forms.Label();
            this.tlpSecondaireTitreEtIdUpdate = new System.Windows.Forms.TableLayoutPanel();
            this.lblTitreUpdate = new System.Windows.Forms.Label();
            this.lblIdUpdate = new System.Windows.Forms.Label();
            this.txtTitreUpdate = new System.Windows.Forms.TextBox();
            this.cbxIdUpdate = new System.Windows.Forms.ComboBox();
            this.tlpSecondaireDateEtDureeUpdate = new System.Windows.Forms.TableLayoutPanel();
            this.lblDateUpdate = new System.Windows.Forms.Label();
            this.lblDureeUpdate = new System.Windows.Forms.Label();
            this.datDateUpdate = new System.Windows.Forms.DateTimePicker();
            this.txtDureeUpdate = new System.Windows.Forms.TextBox();
            this.lblDureeMinutesUpdate = new System.Windows.Forms.Label();
            this.tlpSecondaireGenreUpdate = new System.Windows.Forms.TableLayoutPanel();
            this.cbxGenreUpdate = new System.Windows.Forms.ComboBox();
            this.lblGenreUpdate = new System.Windows.Forms.Label();
            this.tlpSecondaireRealisateurUpdate = new System.Windows.Forms.TableLayoutPanel();
            this.cbxRealisateurUpdate = new System.Windows.Forms.ComboBox();
            this.lblRealisateurUpdate = new System.Windows.Forms.Label();
            this.tlpSecondaireRolesCompletsUpdate = new System.Windows.Forms.TableLayoutPanel();
            this.lblRolesCompletsUpdate = new System.Windows.Forms.Label();
            this.dgvRolesCompletsUpdate = new System.Windows.Forms.DataGridView();
            this.tlpSecondaireActionsUpdate = new System.Windows.Forms.TableLayoutPanel();
            this.btnModifierFilmComplet = new System.Windows.Forms.Button();
            this.btnReinitialiserUpdate = new System.Windows.Forms.Button();
            this.tabInsert = new System.Windows.Forms.TabPage();
            this.tlpPrimaireInsert = new System.Windows.Forms.TableLayoutPanel();
            this.tlpSecondaireResumeInsert = new System.Windows.Forms.TableLayoutPanel();
            this.txtResumeInsert = new System.Windows.Forms.TextBox();
            this.lblResumeInsert = new System.Windows.Forms.Label();
            this.tlpSecondaireTitreEtIdInsert = new System.Windows.Forms.TableLayoutPanel();
            this.lblTitreInsert = new System.Windows.Forms.Label();
            this.lblIdInsert = new System.Windows.Forms.Label();
            this.txtTitreInsert = new System.Windows.Forms.TextBox();
            this.txtIdInsert = new System.Windows.Forms.TextBox();
            this.tlpSecondaireDateEtDureeInsert = new System.Windows.Forms.TableLayoutPanel();
            this.lblDateInsert = new System.Windows.Forms.Label();
            this.lblDureeInsert = new System.Windows.Forms.Label();
            this.datDateInsert = new System.Windows.Forms.DateTimePicker();
            this.txtDureeInsert = new System.Windows.Forms.TextBox();
            this.lblDureeMinutesInsert = new System.Windows.Forms.Label();
            this.tlpSecondaireGenreInsert = new System.Windows.Forms.TableLayoutPanel();
            this.cbxGenreInsert = new System.Windows.Forms.ComboBox();
            this.lblGenreInsert = new System.Windows.Forms.Label();
            this.tlpSecondaireRealisateurInsert = new System.Windows.Forms.TableLayoutPanel();
            this.cbxRealisateurInsert = new System.Windows.Forms.ComboBox();
            this.lblRealisateurInsert = new System.Windows.Forms.Label();
            this.tlpSecondaireRolesCompletsInsert = new System.Windows.Forms.TableLayoutPanel();
            this.lblRolesCompletsInsert = new System.Windows.Forms.Label();
            this.dgvRolesCompletsInsert = new System.Windows.Forms.DataGridView();
            this.tlpSecondaireActionsInsert = new System.Windows.Forms.TableLayoutPanel();
            this.btnInsererFilmComplet = new System.Windows.Forms.Button();
            this.btnReinitialiserInsert = new System.Windows.Forms.Button();
            this.tabDelete = new System.Windows.Forms.TabPage();
            this.tlpPrimaireDelete = new System.Windows.Forms.TableLayoutPanel();
            this.tlpSecondaireResumeDelete = new System.Windows.Forms.TableLayoutPanel();
            this.txtResumeDelete = new System.Windows.Forms.TextBox();
            this.lblResumeDelete = new System.Windows.Forms.Label();
            this.tlpSecondaireTitreEtIdDelete = new System.Windows.Forms.TableLayoutPanel();
            this.lblTitreDelete = new System.Windows.Forms.Label();
            this.lblIdDelete = new System.Windows.Forms.Label();
            this.txtTitreDelete = new System.Windows.Forms.TextBox();
            this.cbxIdDelete = new System.Windows.Forms.ComboBox();
            this.tlpSecondaireDateEtDureeDelete = new System.Windows.Forms.TableLayoutPanel();
            this.lblDateDelete = new System.Windows.Forms.Label();
            this.lblDureeDelete = new System.Windows.Forms.Label();
            this.datDateDelete = new System.Windows.Forms.DateTimePicker();
            this.txtDureeDelete = new System.Windows.Forms.TextBox();
            this.lblDureeMinutesDelete = new System.Windows.Forms.Label();
            this.tlpSecondaireGenreDelete = new System.Windows.Forms.TableLayoutPanel();
            this.txtGenreDelete = new System.Windows.Forms.TextBox();
            this.lblGenreDelete = new System.Windows.Forms.Label();
            this.tlpSecondaireRealisateurDelete = new System.Windows.Forms.TableLayoutPanel();
            this.txtRealisateurDelete = new System.Windows.Forms.TextBox();
            this.lblRealisateurDelete = new System.Windows.Forms.Label();
            this.tlpSecondaireRolesCompletsDelete = new System.Windows.Forms.TableLayoutPanel();
            this.lblRolesCompletsDelete = new System.Windows.Forms.Label();
            this.dgvRolesCompletsDelete = new System.Windows.Forms.DataGridView();
            this.tlpSecondaireActionDelete = new System.Windows.Forms.TableLayoutPanel();
            this.btnSupprimerFilmComplet = new System.Windows.Forms.Button();
            this.tbcGestionnaire.SuspendLayout();
            this.tabAccueil.SuspendLayout();
            this.tlpPrimaireAccueil.SuspendLayout();
            this.tlpSecondaireTitresAccueil.SuspendLayout();
            this.tlpSecondaireActionsAccueil.SuspendLayout();
            this.tabSelect.SuspendLayout();
            this.tlpPrimaireSelect.SuspendLayout();
            this.tlpSecondaireResumeSelect.SuspendLayout();
            this.tlpSecondaireTitreEtIdSelect.SuspendLayout();
            this.tlpSecondaireDateEtDureeSelect.SuspendLayout();
            this.tlpSecondaireGenreSelect.SuspendLayout();
            this.tlpSecondaireRealisateurSelect.SuspendLayout();
            this.tlpRolesCompletsSelect.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRolesCompletsSelect)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAfficheSelect)).BeginInit();
            this.tabUpdate.SuspendLayout();
            this.tlpPrimaireUpdate.SuspendLayout();
            this.tlpSecondaireResumeUpdate.SuspendLayout();
            this.tlpSecondaireTitreEtIdUpdate.SuspendLayout();
            this.tlpSecondaireDateEtDureeUpdate.SuspendLayout();
            this.tlpSecondaireGenreUpdate.SuspendLayout();
            this.tlpSecondaireRealisateurUpdate.SuspendLayout();
            this.tlpSecondaireRolesCompletsUpdate.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRolesCompletsUpdate)).BeginInit();
            this.tlpSecondaireActionsUpdate.SuspendLayout();
            this.tabInsert.SuspendLayout();
            this.tlpPrimaireInsert.SuspendLayout();
            this.tlpSecondaireResumeInsert.SuspendLayout();
            this.tlpSecondaireTitreEtIdInsert.SuspendLayout();
            this.tlpSecondaireDateEtDureeInsert.SuspendLayout();
            this.tlpSecondaireGenreInsert.SuspendLayout();
            this.tlpSecondaireRealisateurInsert.SuspendLayout();
            this.tlpSecondaireRolesCompletsInsert.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRolesCompletsInsert)).BeginInit();
            this.tlpSecondaireActionsInsert.SuspendLayout();
            this.tabDelete.SuspendLayout();
            this.tlpPrimaireDelete.SuspendLayout();
            this.tlpSecondaireResumeDelete.SuspendLayout();
            this.tlpSecondaireTitreEtIdDelete.SuspendLayout();
            this.tlpSecondaireDateEtDureeDelete.SuspendLayout();
            this.tlpSecondaireGenreDelete.SuspendLayout();
            this.tlpSecondaireRealisateurDelete.SuspendLayout();
            this.tlpSecondaireRolesCompletsDelete.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRolesCompletsDelete)).BeginInit();
            this.tlpSecondaireActionDelete.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbcGestionnaire
            // 
            this.tbcGestionnaire.Controls.Add(this.tabAccueil);
            this.tbcGestionnaire.Controls.Add(this.tabSelect);
            this.tbcGestionnaire.Controls.Add(this.tabUpdate);
            this.tbcGestionnaire.Controls.Add(this.tabInsert);
            this.tbcGestionnaire.Controls.Add(this.tabDelete);
            this.tbcGestionnaire.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbcGestionnaire.Location = new System.Drawing.Point(0, 0);
            this.tbcGestionnaire.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tbcGestionnaire.Name = "tbcGestionnaire";
            this.tbcGestionnaire.SelectedIndex = 0;
            this.tbcGestionnaire.Size = new System.Drawing.Size(1004, 724);
            this.tbcGestionnaire.TabIndex = 0;
            // 
            // tabAccueil
            // 
            this.tabAccueil.BackColor = System.Drawing.SystemColors.Control;
            this.tabAccueil.Controls.Add(this.tlpPrimaireAccueil);
            this.tabAccueil.Location = new System.Drawing.Point(4, 34);
            this.tabAccueil.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabAccueil.Name = "tabAccueil";
            this.tabAccueil.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabAccueil.Size = new System.Drawing.Size(996, 686);
            this.tabAccueil.TabIndex = 0;
            this.tabAccueil.Text = "Accueil";
            // 
            // tlpPrimaireAccueil
            // 
            this.tlpPrimaireAccueil.ColumnCount = 3;
            this.tlpPrimaireAccueil.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4.453441F));
            this.tlpPrimaireAccueil.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 91.09312F));
            this.tlpPrimaireAccueil.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4.453441F));
            this.tlpPrimaireAccueil.Controls.Add(this.tlpSecondaireTitresAccueil, 1, 1);
            this.tlpPrimaireAccueil.Controls.Add(this.tlpSecondaireActionsAccueil, 1, 3);
            this.tlpPrimaireAccueil.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpPrimaireAccueil.Location = new System.Drawing.Point(4, 5);
            this.tlpPrimaireAccueil.Name = "tlpPrimaireAccueil";
            this.tlpPrimaireAccueil.RowCount = 5;
            this.tlpPrimaireAccueil.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tlpPrimaireAccueil.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 38.46154F));
            this.tlpPrimaireAccueil.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tlpPrimaireAccueil.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 38.46154F));
            this.tlpPrimaireAccueil.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tlpPrimaireAccueil.Size = new System.Drawing.Size(988, 676);
            this.tlpPrimaireAccueil.TabIndex = 0;
            // 
            // tlpSecondaireTitresAccueil
            // 
            this.tlpSecondaireTitresAccueil.ColumnCount = 1;
            this.tlpSecondaireTitresAccueil.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpSecondaireTitresAccueil.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpSecondaireTitresAccueil.Controls.Add(this.lblSousTitreAccueil, 0, 1);
            this.tlpSecondaireTitresAccueil.Controls.Add(this.lblTitreAccueil, 0, 0);
            this.tlpSecondaireTitresAccueil.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpSecondaireTitresAccueil.Location = new System.Drawing.Point(47, 54);
            this.tlpSecondaireTitresAccueil.Name = "tlpSecondaireTitresAccueil";
            this.tlpSecondaireTitresAccueil.RowCount = 2;
            this.tlpSecondaireTitresAccueil.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpSecondaireTitresAccueil.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpSecondaireTitresAccueil.Size = new System.Drawing.Size(894, 254);
            this.tlpSecondaireTitresAccueil.TabIndex = 0;
            // 
            // lblSousTitreAccueil
            // 
            this.lblSousTitreAccueil.AutoSize = true;
            this.lblSousTitreAccueil.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSousTitreAccueil.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSousTitreAccueil.ForeColor = System.Drawing.Color.DarkGray;
            this.lblSousTitreAccueil.Location = new System.Drawing.Point(3, 127);
            this.lblSousTitreAccueil.Name = "lblSousTitreAccueil";
            this.lblSousTitreAccueil.Size = new System.Drawing.Size(888, 127);
            this.lblSousTitreAccueil.TabIndex = 1;
            this.lblSousTitreAccueil.Text = "gestionnaire de base de données";
            this.lblSousTitreAccueil.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblTitreAccueil
            // 
            this.lblTitreAccueil.AutoSize = true;
            this.lblTitreAccueil.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTitreAccueil.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitreAccueil.Location = new System.Drawing.Point(3, 0);
            this.lblTitreAccueil.Name = "lblTitreAccueil";
            this.lblTitreAccueil.Size = new System.Drawing.Size(888, 127);
            this.lblTitreAccueil.TabIndex = 0;
            this.lblTitreAccueil.Text = "Les Films du Plein Pays";
            this.lblTitreAccueil.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // tlpSecondaireActionsAccueil
            // 
            this.tlpSecondaireActionsAccueil.BackColor = System.Drawing.Color.DarkGray;
            this.tlpSecondaireActionsAccueil.ColumnCount = 9;
            this.tlpSecondaireActionsAccueil.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 2.702703F));
            this.tlpSecondaireActionsAccueil.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 21.62162F));
            this.tlpSecondaireActionsAccueil.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 2.702703F));
            this.tlpSecondaireActionsAccueil.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 21.62162F));
            this.tlpSecondaireActionsAccueil.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 2.702703F));
            this.tlpSecondaireActionsAccueil.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 21.62162F));
            this.tlpSecondaireActionsAccueil.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 2.702703F));
            this.tlpSecondaireActionsAccueil.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 21.62162F));
            this.tlpSecondaireActionsAccueil.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 2.702703F));
            this.tlpSecondaireActionsAccueil.Controls.Add(this.lblActionsAccueil, 1, 1);
            this.tlpSecondaireActionsAccueil.Controls.Add(this.btnAllerAOngletSelect, 1, 2);
            this.tlpSecondaireActionsAccueil.Controls.Add(this.btnAllerAOngletUpdate, 3, 2);
            this.tlpSecondaireActionsAccueil.Controls.Add(this.btnAllerAOngletInsert, 5, 2);
            this.tlpSecondaireActionsAccueil.Controls.Add(this.btnAllerAOngletDelete, 7, 2);
            this.tlpSecondaireActionsAccueil.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpSecondaireActionsAccueil.Location = new System.Drawing.Point(47, 365);
            this.tlpSecondaireActionsAccueil.Name = "tlpSecondaireActionsAccueil";
            this.tlpSecondaireActionsAccueil.RowCount = 4;
            this.tlpSecondaireActionsAccueil.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.67742F));
            this.tlpSecondaireActionsAccueil.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 24.19355F));
            this.tlpSecondaireActionsAccueil.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 56.45161F));
            this.tlpSecondaireActionsAccueil.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.67742F));
            this.tlpSecondaireActionsAccueil.Size = new System.Drawing.Size(894, 254);
            this.tlpSecondaireActionsAccueil.TabIndex = 1;
            // 
            // lblActionsAccueil
            // 
            this.lblActionsAccueil.AutoSize = true;
            this.lblActionsAccueil.BackColor = System.Drawing.Color.Transparent;
            this.tlpSecondaireActionsAccueil.SetColumnSpan(this.lblActionsAccueil, 7);
            this.lblActionsAccueil.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblActionsAccueil.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblActionsAccueil.ForeColor = System.Drawing.Color.White;
            this.lblActionsAccueil.Location = new System.Drawing.Point(27, 24);
            this.lblActionsAccueil.Name = "lblActionsAccueil";
            this.lblActionsAccueil.Size = new System.Drawing.Size(838, 61);
            this.lblActionsAccueil.TabIndex = 5;
            this.lblActionsAccueil.Text = "Actions possibles";
            this.lblActionsAccueil.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnAllerAOngletSelect
            // 
            this.btnAllerAOngletSelect.BackColor = System.Drawing.Color.Transparent;
            this.btnAllerAOngletSelect.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAllerAOngletSelect.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAllerAOngletSelect.Location = new System.Drawing.Point(28, 90);
            this.btnAllerAOngletSelect.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnAllerAOngletSelect.Name = "btnAllerAOngletSelect";
            this.btnAllerAOngletSelect.Size = new System.Drawing.Size(185, 133);
            this.btnAllerAOngletSelect.TabIndex = 6;
            this.btnAllerAOngletSelect.Text = "Consulter";
            this.btnAllerAOngletSelect.UseVisualStyleBackColor = false;
            this.btnAllerAOngletSelect.Click += new System.EventHandler(this.btnAllerAOngletSelect_Click);
            // 
            // btnAllerAOngletUpdate
            // 
            this.btnAllerAOngletUpdate.BackColor = System.Drawing.Color.Transparent;
            this.btnAllerAOngletUpdate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAllerAOngletUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAllerAOngletUpdate.Location = new System.Drawing.Point(245, 90);
            this.btnAllerAOngletUpdate.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnAllerAOngletUpdate.Name = "btnAllerAOngletUpdate";
            this.btnAllerAOngletUpdate.Size = new System.Drawing.Size(185, 133);
            this.btnAllerAOngletUpdate.TabIndex = 7;
            this.btnAllerAOngletUpdate.Text = "Modifier";
            this.btnAllerAOngletUpdate.UseVisualStyleBackColor = false;
            this.btnAllerAOngletUpdate.Click += new System.EventHandler(this.btnAllerAOngletUpdate_Click);
            // 
            // btnAllerAOngletInsert
            // 
            this.btnAllerAOngletInsert.BackColor = System.Drawing.Color.Transparent;
            this.btnAllerAOngletInsert.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAllerAOngletInsert.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAllerAOngletInsert.Location = new System.Drawing.Point(462, 90);
            this.btnAllerAOngletInsert.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnAllerAOngletInsert.Name = "btnAllerAOngletInsert";
            this.btnAllerAOngletInsert.Size = new System.Drawing.Size(185, 133);
            this.btnAllerAOngletInsert.TabIndex = 8;
            this.btnAllerAOngletInsert.Text = "Insérer";
            this.btnAllerAOngletInsert.UseVisualStyleBackColor = false;
            this.btnAllerAOngletInsert.Click += new System.EventHandler(this.btnAllerAOngletInsert_Click);
            // 
            // btnAllerAOngletDelete
            // 
            this.btnAllerAOngletDelete.BackColor = System.Drawing.Color.Transparent;
            this.btnAllerAOngletDelete.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAllerAOngletDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAllerAOngletDelete.Location = new System.Drawing.Point(679, 90);
            this.btnAllerAOngletDelete.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnAllerAOngletDelete.Name = "btnAllerAOngletDelete";
            this.btnAllerAOngletDelete.Size = new System.Drawing.Size(185, 133);
            this.btnAllerAOngletDelete.TabIndex = 9;
            this.btnAllerAOngletDelete.Text = "Supprimer";
            this.btnAllerAOngletDelete.UseVisualStyleBackColor = false;
            this.btnAllerAOngletDelete.Click += new System.EventHandler(this.btnAllerAOngletDelete_Click);
            // 
            // tabSelect
            // 
            this.tabSelect.BackColor = System.Drawing.SystemColors.Control;
            this.tabSelect.Controls.Add(this.tlpPrimaireSelect);
            this.tabSelect.Location = new System.Drawing.Point(4, 34);
            this.tabSelect.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabSelect.Name = "tabSelect";
            this.tabSelect.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabSelect.Size = new System.Drawing.Size(996, 686);
            this.tabSelect.TabIndex = 1;
            this.tabSelect.Text = "Consulter";
            // 
            // tlpPrimaireSelect
            // 
            this.tlpPrimaireSelect.ColumnCount = 5;
            this.tlpPrimaireSelect.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4.263425F));
            this.tlpPrimaireSelect.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 43.60651F));
            this.tlpPrimaireSelect.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4.263425F));
            this.tlpPrimaireSelect.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 43.60651F));
            this.tlpPrimaireSelect.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4.260131F));
            this.tlpPrimaireSelect.Controls.Add(this.tlpSecondaireResumeSelect, 1, 5);
            this.tlpPrimaireSelect.Controls.Add(this.tlpSecondaireTitreEtIdSelect, 1, 1);
            this.tlpPrimaireSelect.Controls.Add(this.tlpSecondaireDateEtDureeSelect, 1, 3);
            this.tlpPrimaireSelect.Controls.Add(this.tlpSecondaireGenreSelect, 1, 7);
            this.tlpPrimaireSelect.Controls.Add(this.tlpSecondaireRealisateurSelect, 1, 9);
            this.tlpPrimaireSelect.Controls.Add(this.tlpRolesCompletsSelect, 1, 11);
            this.tlpPrimaireSelect.Controls.Add(this.picAfficheSelect, 3, 1);
            this.tlpPrimaireSelect.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpPrimaireSelect.Location = new System.Drawing.Point(4, 5);
            this.tlpPrimaireSelect.Name = "tlpPrimaireSelect";
            this.tlpPrimaireSelect.RowCount = 13;
            this.tlpPrimaireSelect.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.130451F));
            this.tlpPrimaireSelect.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.361671F));
            this.tlpPrimaireSelect.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 2.096811F));
            this.tlpPrimaireSelect.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.361671F));
            this.tlpPrimaireSelect.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 2.096811F));
            this.tlpPrimaireSelect.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.72334F));
            this.tlpPrimaireSelect.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 2.096811F));
            this.tlpPrimaireSelect.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.361671F));
            this.tlpPrimaireSelect.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 2.096811F));
            this.tlpPrimaireSelect.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.361671F));
            this.tlpPrimaireSelect.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 2.096811F));
            this.tlpPrimaireSelect.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.08502F));
            this.tlpPrimaireSelect.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.130451F));
            this.tlpPrimaireSelect.Size = new System.Drawing.Size(988, 676);
            this.tlpPrimaireSelect.TabIndex = 2;
            // 
            // tlpSecondaireResumeSelect
            // 
            this.tlpSecondaireResumeSelect.ColumnCount = 1;
            this.tlpSecondaireResumeSelect.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpSecondaireResumeSelect.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpSecondaireResumeSelect.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpSecondaireResumeSelect.Controls.Add(this.txtResumeSelect, 0, 1);
            this.tlpSecondaireResumeSelect.Controls.Add(this.lblResumeSelect, 0, 0);
            this.tlpSecondaireResumeSelect.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpSecondaireResumeSelect.Location = new System.Drawing.Point(45, 191);
            this.tlpSecondaireResumeSelect.Name = "tlpSecondaireResumeSelect";
            this.tlpSecondaireResumeSelect.RowCount = 2;
            this.tlpSecondaireResumeSelect.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tlpSecondaireResumeSelect.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 75F));
            this.tlpSecondaireResumeSelect.Size = new System.Drawing.Size(424, 107);
            this.tlpSecondaireResumeSelect.TabIndex = 9;
            // 
            // txtResumeSelect
            // 
            this.txtResumeSelect.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtResumeSelect.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtResumeSelect.Location = new System.Drawing.Point(3, 29);
            this.txtResumeSelect.Multiline = true;
            this.txtResumeSelect.Name = "txtResumeSelect";
            this.txtResumeSelect.ReadOnly = true;
            this.txtResumeSelect.Size = new System.Drawing.Size(418, 75);
            this.txtResumeSelect.TabIndex = 8;
            // 
            // lblResumeSelect
            // 
            this.lblResumeSelect.AutoSize = true;
            this.lblResumeSelect.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblResumeSelect.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResumeSelect.ForeColor = System.Drawing.Color.Black;
            this.lblResumeSelect.Location = new System.Drawing.Point(3, 0);
            this.lblResumeSelect.Name = "lblResumeSelect";
            this.lblResumeSelect.Size = new System.Drawing.Size(418, 26);
            this.lblResumeSelect.TabIndex = 6;
            this.lblResumeSelect.Text = "Résumé";
            this.lblResumeSelect.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tlpSecondaireTitreEtIdSelect
            // 
            this.tlpSecondaireTitreEtIdSelect.ColumnCount = 3;
            this.tlpSecondaireTitreEtIdSelect.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tlpSecondaireTitreEtIdSelect.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7F));
            this.tlpSecondaireTitreEtIdSelect.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13F));
            this.tlpSecondaireTitreEtIdSelect.Controls.Add(this.lblTitreSelect, 0, 0);
            this.tlpSecondaireTitreEtIdSelect.Controls.Add(this.lblIdSelect, 2, 0);
            this.tlpSecondaireTitreEtIdSelect.Controls.Add(this.cbxTitreSelect, 0, 1);
            this.tlpSecondaireTitreEtIdSelect.Controls.Add(this.txtIdSelect, 2, 1);
            this.tlpSecondaireTitreEtIdSelect.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpSecondaireTitreEtIdSelect.Location = new System.Drawing.Point(45, 51);
            this.tlpSecondaireTitreEtIdSelect.Name = "tlpSecondaireTitreEtIdSelect";
            this.tlpSecondaireTitreEtIdSelect.RowCount = 2;
            this.tlpSecondaireTitreEtIdSelect.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpSecondaireTitreEtIdSelect.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpSecondaireTitreEtIdSelect.Size = new System.Drawing.Size(424, 50);
            this.tlpSecondaireTitreEtIdSelect.TabIndex = 0;
            // 
            // lblTitreSelect
            // 
            this.lblTitreSelect.AutoSize = true;
            this.lblTitreSelect.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTitreSelect.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitreSelect.ForeColor = System.Drawing.Color.Black;
            this.lblTitreSelect.Location = new System.Drawing.Point(3, 0);
            this.lblTitreSelect.Name = "lblTitreSelect";
            this.lblTitreSelect.Size = new System.Drawing.Size(333, 25);
            this.lblTitreSelect.TabIndex = 5;
            this.lblTitreSelect.Text = "Titre";
            this.lblTitreSelect.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblIdSelect
            // 
            this.lblIdSelect.AutoSize = true;
            this.lblIdSelect.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblIdSelect.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIdSelect.ForeColor = System.Drawing.Color.Black;
            this.lblIdSelect.Location = new System.Drawing.Point(371, 0);
            this.lblIdSelect.Name = "lblIdSelect";
            this.lblIdSelect.Size = new System.Drawing.Size(50, 25);
            this.lblIdSelect.TabIndex = 6;
            this.lblIdSelect.Text = "Id";
            this.lblIdSelect.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cbxTitreSelect
            // 
            this.cbxTitreSelect.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cbxTitreSelect.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxTitreSelect.FormattingEnabled = true;
            this.cbxTitreSelect.Location = new System.Drawing.Point(3, 28);
            this.cbxTitreSelect.Name = "cbxTitreSelect";
            this.cbxTitreSelect.Size = new System.Drawing.Size(333, 28);
            this.cbxTitreSelect.TabIndex = 8;
            this.cbxTitreSelect.Text = "  !";
            this.cbxTitreSelect.SelectedIndexChanged += new System.EventHandler(this.cbxTitreSelect_SelectedIndexChanged);
            // 
            // txtIdSelect
            // 
            this.txtIdSelect.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtIdSelect.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIdSelect.Location = new System.Drawing.Point(371, 28);
            this.txtIdSelect.Name = "txtIdSelect";
            this.txtIdSelect.ReadOnly = true;
            this.txtIdSelect.Size = new System.Drawing.Size(50, 27);
            this.txtIdSelect.TabIndex = 9;
            // 
            // tlpSecondaireDateEtDureeSelect
            // 
            this.tlpSecondaireDateEtDureeSelect.ColumnCount = 4;
            this.tlpSecondaireDateEtDureeSelect.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 65.65656F));
            this.tlpSecondaireDateEtDureeSelect.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.070707F));
            this.tlpSecondaireDateEtDureeSelect.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.12121F));
            this.tlpSecondaireDateEtDureeSelect.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15.15152F));
            this.tlpSecondaireDateEtDureeSelect.Controls.Add(this.lblDateSelect, 0, 0);
            this.tlpSecondaireDateEtDureeSelect.Controls.Add(this.lblDureeSelect, 2, 0);
            this.tlpSecondaireDateEtDureeSelect.Controls.Add(this.datDateSelect, 0, 1);
            this.tlpSecondaireDateEtDureeSelect.Controls.Add(this.txtDureeSelect, 2, 1);
            this.tlpSecondaireDateEtDureeSelect.Controls.Add(this.lblDureeMinutesSelect, 3, 1);
            this.tlpSecondaireDateEtDureeSelect.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpSecondaireDateEtDureeSelect.Location = new System.Drawing.Point(45, 121);
            this.tlpSecondaireDateEtDureeSelect.Name = "tlpSecondaireDateEtDureeSelect";
            this.tlpSecondaireDateEtDureeSelect.RowCount = 2;
            this.tlpSecondaireDateEtDureeSelect.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpSecondaireDateEtDureeSelect.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpSecondaireDateEtDureeSelect.Size = new System.Drawing.Size(424, 50);
            this.tlpSecondaireDateEtDureeSelect.TabIndex = 1;
            // 
            // lblDateSelect
            // 
            this.lblDateSelect.AutoSize = true;
            this.lblDateSelect.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDateSelect.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDateSelect.ForeColor = System.Drawing.Color.Black;
            this.lblDateSelect.Location = new System.Drawing.Point(3, 0);
            this.lblDateSelect.Name = "lblDateSelect";
            this.lblDateSelect.Size = new System.Drawing.Size(272, 25);
            this.lblDateSelect.TabIndex = 5;
            this.lblDateSelect.Text = "Date de parution";
            this.lblDateSelect.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblDureeSelect
            // 
            this.lblDureeSelect.AutoSize = true;
            this.tlpSecondaireDateEtDureeSelect.SetColumnSpan(this.lblDureeSelect, 2);
            this.lblDureeSelect.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDureeSelect.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDureeSelect.ForeColor = System.Drawing.Color.Black;
            this.lblDureeSelect.Location = new System.Drawing.Point(310, 0);
            this.lblDureeSelect.Name = "lblDureeSelect";
            this.lblDureeSelect.Size = new System.Drawing.Size(111, 25);
            this.lblDureeSelect.TabIndex = 6;
            this.lblDureeSelect.Text = "Durée";
            this.lblDureeSelect.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // datDateSelect
            // 
            this.datDateSelect.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datDateSelect.Dock = System.Windows.Forms.DockStyle.Fill;
            this.datDateSelect.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datDateSelect.Location = new System.Drawing.Point(3, 28);
            this.datDateSelect.Name = "datDateSelect";
            this.datDateSelect.Size = new System.Drawing.Size(272, 27);
            this.datDateSelect.TabIndex = 7;
            // 
            // txtDureeSelect
            // 
            this.txtDureeSelect.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtDureeSelect.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDureeSelect.Location = new System.Drawing.Point(310, 28);
            this.txtDureeSelect.Name = "txtDureeSelect";
            this.txtDureeSelect.ReadOnly = true;
            this.txtDureeSelect.Size = new System.Drawing.Size(45, 27);
            this.txtDureeSelect.TabIndex = 8;
            // 
            // lblDureeMinutesSelect
            // 
            this.lblDureeMinutesSelect.AutoSize = true;
            this.lblDureeMinutesSelect.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDureeMinutesSelect.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDureeMinutesSelect.ForeColor = System.Drawing.Color.Black;
            this.lblDureeMinutesSelect.Location = new System.Drawing.Point(361, 25);
            this.lblDureeMinutesSelect.Name = "lblDureeMinutesSelect";
            this.lblDureeMinutesSelect.Size = new System.Drawing.Size(60, 25);
            this.lblDureeMinutesSelect.TabIndex = 9;
            this.lblDureeMinutesSelect.Text = "minutes";
            this.lblDureeMinutesSelect.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tlpSecondaireGenreSelect
            // 
            this.tlpSecondaireGenreSelect.ColumnCount = 1;
            this.tlpSecondaireGenreSelect.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpSecondaireGenreSelect.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpSecondaireGenreSelect.Controls.Add(this.txtGenreSelect, 0, 1);
            this.tlpSecondaireGenreSelect.Controls.Add(this.lblGenreSelect, 0, 0);
            this.tlpSecondaireGenreSelect.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpSecondaireGenreSelect.Location = new System.Drawing.Point(45, 318);
            this.tlpSecondaireGenreSelect.Name = "tlpSecondaireGenreSelect";
            this.tlpSecondaireGenreSelect.RowCount = 2;
            this.tlpSecondaireGenreSelect.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpSecondaireGenreSelect.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpSecondaireGenreSelect.Size = new System.Drawing.Size(424, 50);
            this.tlpSecondaireGenreSelect.TabIndex = 10;
            // 
            // txtGenreSelect
            // 
            this.txtGenreSelect.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtGenreSelect.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGenreSelect.Location = new System.Drawing.Point(3, 28);
            this.txtGenreSelect.Name = "txtGenreSelect";
            this.txtGenreSelect.ReadOnly = true;
            this.txtGenreSelect.Size = new System.Drawing.Size(418, 27);
            this.txtGenreSelect.TabIndex = 9;
            // 
            // lblGenreSelect
            // 
            this.lblGenreSelect.AutoSize = true;
            this.lblGenreSelect.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblGenreSelect.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGenreSelect.ForeColor = System.Drawing.Color.Black;
            this.lblGenreSelect.Location = new System.Drawing.Point(3, 0);
            this.lblGenreSelect.Name = "lblGenreSelect";
            this.lblGenreSelect.Size = new System.Drawing.Size(418, 25);
            this.lblGenreSelect.TabIndex = 7;
            this.lblGenreSelect.Text = "Genre";
            this.lblGenreSelect.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tlpSecondaireRealisateurSelect
            // 
            this.tlpSecondaireRealisateurSelect.ColumnCount = 1;
            this.tlpSecondaireRealisateurSelect.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpSecondaireRealisateurSelect.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpSecondaireRealisateurSelect.Controls.Add(this.txtRealisateurSelect, 0, 1);
            this.tlpSecondaireRealisateurSelect.Controls.Add(this.lblRealisateurSelect, 0, 0);
            this.tlpSecondaireRealisateurSelect.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpSecondaireRealisateurSelect.Location = new System.Drawing.Point(45, 388);
            this.tlpSecondaireRealisateurSelect.Name = "tlpSecondaireRealisateurSelect";
            this.tlpSecondaireRealisateurSelect.RowCount = 2;
            this.tlpSecondaireRealisateurSelect.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpSecondaireRealisateurSelect.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpSecondaireRealisateurSelect.Size = new System.Drawing.Size(424, 50);
            this.tlpSecondaireRealisateurSelect.TabIndex = 11;
            // 
            // txtRealisateurSelect
            // 
            this.txtRealisateurSelect.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtRealisateurSelect.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRealisateurSelect.Location = new System.Drawing.Point(3, 28);
            this.txtRealisateurSelect.Name = "txtRealisateurSelect";
            this.txtRealisateurSelect.ReadOnly = true;
            this.txtRealisateurSelect.Size = new System.Drawing.Size(418, 27);
            this.txtRealisateurSelect.TabIndex = 9;
            // 
            // lblRealisateurSelect
            // 
            this.lblRealisateurSelect.AutoSize = true;
            this.lblRealisateurSelect.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblRealisateurSelect.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRealisateurSelect.ForeColor = System.Drawing.Color.Black;
            this.lblRealisateurSelect.Location = new System.Drawing.Point(3, 0);
            this.lblRealisateurSelect.Name = "lblRealisateurSelect";
            this.lblRealisateurSelect.Size = new System.Drawing.Size(418, 25);
            this.lblRealisateurSelect.TabIndex = 7;
            this.lblRealisateurSelect.Text = "Réalisateur / Réalisatrice";
            this.lblRealisateurSelect.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tlpRolesCompletsSelect
            // 
            this.tlpRolesCompletsSelect.ColumnCount = 1;
            this.tlpRolesCompletsSelect.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpRolesCompletsSelect.Controls.Add(this.lblRolesCompletsSelect, 0, 0);
            this.tlpRolesCompletsSelect.Controls.Add(this.dgvRolesCompletsSelect, 0, 1);
            this.tlpRolesCompletsSelect.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpRolesCompletsSelect.Location = new System.Drawing.Point(45, 458);
            this.tlpRolesCompletsSelect.Name = "tlpRolesCompletsSelect";
            this.tlpRolesCompletsSelect.RowCount = 2;
            this.tlpRolesCompletsSelect.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 19.04762F));
            this.tlpRolesCompletsSelect.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80.95238F));
            this.tlpRolesCompletsSelect.Size = new System.Drawing.Size(424, 163);
            this.tlpRolesCompletsSelect.TabIndex = 12;
            // 
            // lblRolesCompletsSelect
            // 
            this.lblRolesCompletsSelect.AutoSize = true;
            this.lblRolesCompletsSelect.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblRolesCompletsSelect.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRolesCompletsSelect.ForeColor = System.Drawing.Color.Black;
            this.lblRolesCompletsSelect.Location = new System.Drawing.Point(3, 0);
            this.lblRolesCompletsSelect.Name = "lblRolesCompletsSelect";
            this.lblRolesCompletsSelect.Size = new System.Drawing.Size(418, 31);
            this.lblRolesCompletsSelect.TabIndex = 7;
            this.lblRolesCompletsSelect.Text = "Acteur(s) / Actrice(s)";
            this.lblRolesCompletsSelect.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // dgvRolesCompletsSelect
            // 
            this.dgvRolesCompletsSelect.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvRolesCompletsSelect.BackgroundColor = System.Drawing.Color.White;
            this.dgvRolesCompletsSelect.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRolesCompletsSelect.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvRolesCompletsSelect.Location = new System.Drawing.Point(3, 34);
            this.dgvRolesCompletsSelect.Name = "dgvRolesCompletsSelect";
            this.dgvRolesCompletsSelect.ReadOnly = true;
            this.dgvRolesCompletsSelect.RowHeadersWidth = 51;
            this.dgvRolesCompletsSelect.RowTemplate.Height = 24;
            this.dgvRolesCompletsSelect.Size = new System.Drawing.Size(418, 126);
            this.dgvRolesCompletsSelect.TabIndex = 8;
            // 
            // picAfficheSelect
            // 
            this.picAfficheSelect.Dock = System.Windows.Forms.DockStyle.Fill;
            this.picAfficheSelect.Location = new System.Drawing.Point(517, 51);
            this.picAfficheSelect.Name = "picAfficheSelect";
            this.tlpPrimaireSelect.SetRowSpan(this.picAfficheSelect, 11);
            this.picAfficheSelect.Size = new System.Drawing.Size(424, 570);
            this.picAfficheSelect.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picAfficheSelect.TabIndex = 13;
            this.picAfficheSelect.TabStop = false;
            // 
            // tabUpdate
            // 
            this.tabUpdate.BackColor = System.Drawing.SystemColors.Control;
            this.tabUpdate.Controls.Add(this.tlpPrimaireUpdate);
            this.tabUpdate.Location = new System.Drawing.Point(4, 34);
            this.tabUpdate.Name = "tabUpdate";
            this.tabUpdate.Size = new System.Drawing.Size(996, 686);
            this.tabUpdate.TabIndex = 2;
            this.tabUpdate.Text = "Modifier";
            // 
            // tlpPrimaireUpdate
            // 
            this.tlpPrimaireUpdate.ColumnCount = 5;
            this.tlpPrimaireUpdate.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4.263425F));
            this.tlpPrimaireUpdate.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 43.60651F));
            this.tlpPrimaireUpdate.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4.263425F));
            this.tlpPrimaireUpdate.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 43.60651F));
            this.tlpPrimaireUpdate.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4.260131F));
            this.tlpPrimaireUpdate.Controls.Add(this.tlpSecondaireResumeUpdate, 1, 5);
            this.tlpPrimaireUpdate.Controls.Add(this.tlpSecondaireTitreEtIdUpdate, 1, 1);
            this.tlpPrimaireUpdate.Controls.Add(this.tlpSecondaireDateEtDureeUpdate, 1, 3);
            this.tlpPrimaireUpdate.Controls.Add(this.tlpSecondaireGenreUpdate, 1, 7);
            this.tlpPrimaireUpdate.Controls.Add(this.tlpSecondaireRealisateurUpdate, 1, 9);
            this.tlpPrimaireUpdate.Controls.Add(this.tlpSecondaireRolesCompletsUpdate, 1, 11);
            this.tlpPrimaireUpdate.Controls.Add(this.tlpSecondaireActionsUpdate, 3, 11);
            this.tlpPrimaireUpdate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpPrimaireUpdate.Location = new System.Drawing.Point(0, 0);
            this.tlpPrimaireUpdate.Name = "tlpPrimaireUpdate";
            this.tlpPrimaireUpdate.RowCount = 13;
            this.tlpPrimaireUpdate.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.914742F));
            this.tlpPrimaireUpdate.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.208695F));
            this.tlpPrimaireUpdate.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 2.05845F));
            this.tlpPrimaireUpdate.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.208695F));
            this.tlpPrimaireUpdate.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 2.05845F));
            this.tlpPrimaireUpdate.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.41739F));
            this.tlpPrimaireUpdate.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 2.05845F));
            this.tlpPrimaireUpdate.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.208695F));
            this.tlpPrimaireUpdate.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 2.05845F));
            this.tlpPrimaireUpdate.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.208695F));
            this.tlpPrimaireUpdate.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 2.05845F));
            this.tlpPrimaireUpdate.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 24.62609F));
            this.tlpPrimaireUpdate.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.914742F));
            this.tlpPrimaireUpdate.Size = new System.Drawing.Size(996, 686);
            this.tlpPrimaireUpdate.TabIndex = 1;
            // 
            // tlpSecondaireResumeUpdate
            // 
            this.tlpSecondaireResumeUpdate.ColumnCount = 1;
            this.tlpSecondaireResumeUpdate.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpSecondaireResumeUpdate.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpSecondaireResumeUpdate.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpSecondaireResumeUpdate.Controls.Add(this.txtResumeUpdate, 0, 1);
            this.tlpSecondaireResumeUpdate.Controls.Add(this.lblResumeUpdate, 0, 0);
            this.tlpSecondaireResumeUpdate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpSecondaireResumeUpdate.Location = new System.Drawing.Point(45, 197);
            this.tlpSecondaireResumeUpdate.Name = "tlpSecondaireResumeUpdate";
            this.tlpSecondaireResumeUpdate.RowCount = 2;
            this.tlpSecondaireResumeUpdate.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tlpSecondaireResumeUpdate.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 75F));
            this.tlpSecondaireResumeUpdate.Size = new System.Drawing.Size(428, 106);
            this.tlpSecondaireResumeUpdate.TabIndex = 9;
            // 
            // txtResumeUpdate
            // 
            this.txtResumeUpdate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtResumeUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtResumeUpdate.Location = new System.Drawing.Point(3, 29);
            this.txtResumeUpdate.Multiline = true;
            this.txtResumeUpdate.Name = "txtResumeUpdate";
            this.txtResumeUpdate.Size = new System.Drawing.Size(422, 74);
            this.txtResumeUpdate.TabIndex = 8;
            this.txtResumeUpdate.Validating += new System.ComponentModel.CancelEventHandler(this.txtResumeUpdate_Validating);
            // 
            // lblResumeUpdate
            // 
            this.lblResumeUpdate.AutoSize = true;
            this.lblResumeUpdate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblResumeUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResumeUpdate.ForeColor = System.Drawing.Color.Black;
            this.lblResumeUpdate.Location = new System.Drawing.Point(3, 0);
            this.lblResumeUpdate.Name = "lblResumeUpdate";
            this.lblResumeUpdate.Size = new System.Drawing.Size(422, 26);
            this.lblResumeUpdate.TabIndex = 6;
            this.lblResumeUpdate.Text = "Résumé";
            this.lblResumeUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tlpSecondaireTitreEtIdUpdate
            // 
            this.tlpSecondaireTitreEtIdUpdate.ColumnCount = 3;
            this.tlpSecondaireTitreEtIdUpdate.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tlpSecondaireTitreEtIdUpdate.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7F));
            this.tlpSecondaireTitreEtIdUpdate.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13F));
            this.tlpSecondaireTitreEtIdUpdate.Controls.Add(this.lblTitreUpdate, 0, 0);
            this.tlpSecondaireTitreEtIdUpdate.Controls.Add(this.lblIdUpdate, 2, 0);
            this.tlpSecondaireTitreEtIdUpdate.Controls.Add(this.txtTitreUpdate, 0, 1);
            this.tlpSecondaireTitreEtIdUpdate.Controls.Add(this.cbxIdUpdate, 2, 1);
            this.tlpSecondaireTitreEtIdUpdate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpSecondaireTitreEtIdUpdate.Location = new System.Drawing.Point(45, 57);
            this.tlpSecondaireTitreEtIdUpdate.Name = "tlpSecondaireTitreEtIdUpdate";
            this.tlpSecondaireTitreEtIdUpdate.RowCount = 2;
            this.tlpSecondaireTitreEtIdUpdate.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpSecondaireTitreEtIdUpdate.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpSecondaireTitreEtIdUpdate.Size = new System.Drawing.Size(428, 50);
            this.tlpSecondaireTitreEtIdUpdate.TabIndex = 0;
            // 
            // lblTitreUpdate
            // 
            this.lblTitreUpdate.AutoSize = true;
            this.lblTitreUpdate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTitreUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitreUpdate.ForeColor = System.Drawing.Color.Black;
            this.lblTitreUpdate.Location = new System.Drawing.Point(3, 0);
            this.lblTitreUpdate.Name = "lblTitreUpdate";
            this.lblTitreUpdate.Size = new System.Drawing.Size(336, 25);
            this.lblTitreUpdate.TabIndex = 5;
            this.lblTitreUpdate.Text = "Titre";
            this.lblTitreUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblIdUpdate
            // 
            this.lblIdUpdate.AutoSize = true;
            this.lblIdUpdate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblIdUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIdUpdate.ForeColor = System.Drawing.Color.Black;
            this.lblIdUpdate.Location = new System.Drawing.Point(374, 0);
            this.lblIdUpdate.Name = "lblIdUpdate";
            this.lblIdUpdate.Size = new System.Drawing.Size(51, 25);
            this.lblIdUpdate.TabIndex = 6;
            this.lblIdUpdate.Text = "Id";
            this.lblIdUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtTitreUpdate
            // 
            this.txtTitreUpdate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtTitreUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTitreUpdate.Location = new System.Drawing.Point(3, 28);
            this.txtTitreUpdate.Name = "txtTitreUpdate";
            this.txtTitreUpdate.Size = new System.Drawing.Size(336, 27);
            this.txtTitreUpdate.TabIndex = 7;
            this.txtTitreUpdate.Validating += new System.ComponentModel.CancelEventHandler(this.txtTitreUpdate_Validating);
            // 
            // cbxIdUpdate
            // 
            this.cbxIdUpdate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cbxIdUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxIdUpdate.FormattingEnabled = true;
            this.cbxIdUpdate.Location = new System.Drawing.Point(374, 28);
            this.cbxIdUpdate.Name = "cbxIdUpdate";
            this.cbxIdUpdate.Size = new System.Drawing.Size(51, 28);
            this.cbxIdUpdate.TabIndex = 8;
            this.cbxIdUpdate.Text = "  !";
            this.cbxIdUpdate.SelectedIndexChanged += new System.EventHandler(this.cbxIdUpdate_SelectedIndexChanged);
            // 
            // tlpSecondaireDateEtDureeUpdate
            // 
            this.tlpSecondaireDateEtDureeUpdate.ColumnCount = 4;
            this.tlpSecondaireDateEtDureeUpdate.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 65.65656F));
            this.tlpSecondaireDateEtDureeUpdate.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.070707F));
            this.tlpSecondaireDateEtDureeUpdate.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.12121F));
            this.tlpSecondaireDateEtDureeUpdate.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15.15152F));
            this.tlpSecondaireDateEtDureeUpdate.Controls.Add(this.lblDateUpdate, 0, 0);
            this.tlpSecondaireDateEtDureeUpdate.Controls.Add(this.lblDureeUpdate, 2, 0);
            this.tlpSecondaireDateEtDureeUpdate.Controls.Add(this.datDateUpdate, 0, 1);
            this.tlpSecondaireDateEtDureeUpdate.Controls.Add(this.txtDureeUpdate, 2, 1);
            this.tlpSecondaireDateEtDureeUpdate.Controls.Add(this.lblDureeMinutesUpdate, 3, 1);
            this.tlpSecondaireDateEtDureeUpdate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpSecondaireDateEtDureeUpdate.Location = new System.Drawing.Point(45, 127);
            this.tlpSecondaireDateEtDureeUpdate.Name = "tlpSecondaireDateEtDureeUpdate";
            this.tlpSecondaireDateEtDureeUpdate.RowCount = 2;
            this.tlpSecondaireDateEtDureeUpdate.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpSecondaireDateEtDureeUpdate.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpSecondaireDateEtDureeUpdate.Size = new System.Drawing.Size(428, 50);
            this.tlpSecondaireDateEtDureeUpdate.TabIndex = 1;
            // 
            // lblDateUpdate
            // 
            this.lblDateUpdate.AutoSize = true;
            this.lblDateUpdate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDateUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDateUpdate.ForeColor = System.Drawing.Color.Black;
            this.lblDateUpdate.Location = new System.Drawing.Point(3, 0);
            this.lblDateUpdate.Name = "lblDateUpdate";
            this.lblDateUpdate.Size = new System.Drawing.Size(275, 25);
            this.lblDateUpdate.TabIndex = 5;
            this.lblDateUpdate.Text = "Date de parution";
            this.lblDateUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblDureeUpdate
            // 
            this.lblDureeUpdate.AutoSize = true;
            this.tlpSecondaireDateEtDureeUpdate.SetColumnSpan(this.lblDureeUpdate, 2);
            this.lblDureeUpdate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDureeUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDureeUpdate.ForeColor = System.Drawing.Color.Black;
            this.lblDureeUpdate.Location = new System.Drawing.Point(314, 0);
            this.lblDureeUpdate.Name = "lblDureeUpdate";
            this.lblDureeUpdate.Size = new System.Drawing.Size(111, 25);
            this.lblDureeUpdate.TabIndex = 6;
            this.lblDureeUpdate.Text = "Durée";
            this.lblDureeUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // datDateUpdate
            // 
            this.datDateUpdate.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datDateUpdate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.datDateUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datDateUpdate.Location = new System.Drawing.Point(3, 28);
            this.datDateUpdate.Name = "datDateUpdate";
            this.datDateUpdate.Size = new System.Drawing.Size(275, 27);
            this.datDateUpdate.TabIndex = 7;
            this.datDateUpdate.Validating += new System.ComponentModel.CancelEventHandler(this.datDateUpdate_Validating);
            // 
            // txtDureeUpdate
            // 
            this.txtDureeUpdate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtDureeUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDureeUpdate.Location = new System.Drawing.Point(314, 28);
            this.txtDureeUpdate.Name = "txtDureeUpdate";
            this.txtDureeUpdate.Size = new System.Drawing.Size(45, 27);
            this.txtDureeUpdate.TabIndex = 8;
            this.txtDureeUpdate.Validating += new System.ComponentModel.CancelEventHandler(this.txtDureeUpdate_Validating);
            // 
            // lblDureeMinutesUpdate
            // 
            this.lblDureeMinutesUpdate.AutoSize = true;
            this.lblDureeMinutesUpdate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDureeMinutesUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDureeMinutesUpdate.ForeColor = System.Drawing.Color.Black;
            this.lblDureeMinutesUpdate.Location = new System.Drawing.Point(365, 25);
            this.lblDureeMinutesUpdate.Name = "lblDureeMinutesUpdate";
            this.lblDureeMinutesUpdate.Size = new System.Drawing.Size(60, 25);
            this.lblDureeMinutesUpdate.TabIndex = 9;
            this.lblDureeMinutesUpdate.Text = "minutes";
            this.lblDureeMinutesUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tlpSecondaireGenreUpdate
            // 
            this.tlpSecondaireGenreUpdate.ColumnCount = 2;
            this.tlpSecondaireGenreUpdate.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 93F));
            this.tlpSecondaireGenreUpdate.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7F));
            this.tlpSecondaireGenreUpdate.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpSecondaireGenreUpdate.Controls.Add(this.cbxGenreUpdate, 0, 1);
            this.tlpSecondaireGenreUpdate.Controls.Add(this.lblGenreUpdate, 0, 0);
            this.tlpSecondaireGenreUpdate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpSecondaireGenreUpdate.Location = new System.Drawing.Point(45, 323);
            this.tlpSecondaireGenreUpdate.Name = "tlpSecondaireGenreUpdate";
            this.tlpSecondaireGenreUpdate.RowCount = 2;
            this.tlpSecondaireGenreUpdate.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpSecondaireGenreUpdate.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpSecondaireGenreUpdate.Size = new System.Drawing.Size(428, 50);
            this.tlpSecondaireGenreUpdate.TabIndex = 10;
            // 
            // cbxGenreUpdate
            // 
            this.cbxGenreUpdate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cbxGenreUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxGenreUpdate.FormattingEnabled = true;
            this.cbxGenreUpdate.Location = new System.Drawing.Point(3, 28);
            this.cbxGenreUpdate.Name = "cbxGenreUpdate";
            this.cbxGenreUpdate.Size = new System.Drawing.Size(392, 28);
            this.cbxGenreUpdate.TabIndex = 9;
            this.cbxGenreUpdate.Validating += new System.ComponentModel.CancelEventHandler(this.cbxGenreUpdate_Validating);
            // 
            // lblGenreUpdate
            // 
            this.lblGenreUpdate.AutoSize = true;
            this.lblGenreUpdate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblGenreUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGenreUpdate.ForeColor = System.Drawing.Color.Black;
            this.lblGenreUpdate.Location = new System.Drawing.Point(3, 0);
            this.lblGenreUpdate.Name = "lblGenreUpdate";
            this.lblGenreUpdate.Size = new System.Drawing.Size(392, 25);
            this.lblGenreUpdate.TabIndex = 6;
            this.lblGenreUpdate.Text = "Genre";
            this.lblGenreUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tlpSecondaireRealisateurUpdate
            // 
            this.tlpSecondaireRealisateurUpdate.ColumnCount = 2;
            this.tlpSecondaireRealisateurUpdate.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 93F));
            this.tlpSecondaireRealisateurUpdate.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7F));
            this.tlpSecondaireRealisateurUpdate.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpSecondaireRealisateurUpdate.Controls.Add(this.cbxRealisateurUpdate, 0, 1);
            this.tlpSecondaireRealisateurUpdate.Controls.Add(this.lblRealisateurUpdate, 0, 0);
            this.tlpSecondaireRealisateurUpdate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpSecondaireRealisateurUpdate.Location = new System.Drawing.Point(45, 393);
            this.tlpSecondaireRealisateurUpdate.Name = "tlpSecondaireRealisateurUpdate";
            this.tlpSecondaireRealisateurUpdate.RowCount = 2;
            this.tlpSecondaireRealisateurUpdate.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpSecondaireRealisateurUpdate.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpSecondaireRealisateurUpdate.Size = new System.Drawing.Size(428, 50);
            this.tlpSecondaireRealisateurUpdate.TabIndex = 11;
            // 
            // cbxRealisateurUpdate
            // 
            this.cbxRealisateurUpdate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cbxRealisateurUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxRealisateurUpdate.FormattingEnabled = true;
            this.cbxRealisateurUpdate.Location = new System.Drawing.Point(3, 28);
            this.cbxRealisateurUpdate.Name = "cbxRealisateurUpdate";
            this.cbxRealisateurUpdate.Size = new System.Drawing.Size(392, 28);
            this.cbxRealisateurUpdate.TabIndex = 9;
            this.cbxRealisateurUpdate.Validating += new System.ComponentModel.CancelEventHandler(this.cbxRealisateurUpdate_Validating);
            // 
            // lblRealisateurUpdate
            // 
            this.lblRealisateurUpdate.AutoSize = true;
            this.lblRealisateurUpdate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblRealisateurUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRealisateurUpdate.ForeColor = System.Drawing.Color.Black;
            this.lblRealisateurUpdate.Location = new System.Drawing.Point(3, 0);
            this.lblRealisateurUpdate.Name = "lblRealisateurUpdate";
            this.lblRealisateurUpdate.Size = new System.Drawing.Size(392, 25);
            this.lblRealisateurUpdate.TabIndex = 6;
            this.lblRealisateurUpdate.Text = "Réalisateur / Réalisatrice";
            this.lblRealisateurUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tlpSecondaireRolesCompletsUpdate
            // 
            this.tlpSecondaireRolesCompletsUpdate.ColumnCount = 1;
            this.tlpSecondaireRolesCompletsUpdate.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpSecondaireRolesCompletsUpdate.Controls.Add(this.lblRolesCompletsUpdate, 0, 0);
            this.tlpSecondaireRolesCompletsUpdate.Controls.Add(this.dgvRolesCompletsUpdate, 0, 1);
            this.tlpSecondaireRolesCompletsUpdate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpSecondaireRolesCompletsUpdate.Location = new System.Drawing.Point(45, 463);
            this.tlpSecondaireRolesCompletsUpdate.Name = "tlpSecondaireRolesCompletsUpdate";
            this.tlpSecondaireRolesCompletsUpdate.RowCount = 2;
            this.tlpSecondaireRolesCompletsUpdate.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 19.04762F));
            this.tlpSecondaireRolesCompletsUpdate.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80.95238F));
            this.tlpSecondaireRolesCompletsUpdate.Size = new System.Drawing.Size(428, 162);
            this.tlpSecondaireRolesCompletsUpdate.TabIndex = 12;
            // 
            // lblRolesCompletsUpdate
            // 
            this.lblRolesCompletsUpdate.AutoSize = true;
            this.lblRolesCompletsUpdate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblRolesCompletsUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRolesCompletsUpdate.ForeColor = System.Drawing.Color.Black;
            this.lblRolesCompletsUpdate.Location = new System.Drawing.Point(3, 0);
            this.lblRolesCompletsUpdate.Name = "lblRolesCompletsUpdate";
            this.lblRolesCompletsUpdate.Size = new System.Drawing.Size(422, 30);
            this.lblRolesCompletsUpdate.TabIndex = 7;
            this.lblRolesCompletsUpdate.Text = "Acteur(s) / Actrice(s)";
            this.lblRolesCompletsUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // dgvRolesCompletsUpdate
            // 
            this.dgvRolesCompletsUpdate.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvRolesCompletsUpdate.BackgroundColor = System.Drawing.Color.White;
            this.dgvRolesCompletsUpdate.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRolesCompletsUpdate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvRolesCompletsUpdate.Location = new System.Drawing.Point(3, 33);
            this.dgvRolesCompletsUpdate.Name = "dgvRolesCompletsUpdate";
            this.dgvRolesCompletsUpdate.ReadOnly = true;
            this.dgvRolesCompletsUpdate.RowHeadersWidth = 51;
            this.dgvRolesCompletsUpdate.RowTemplate.Height = 24;
            this.dgvRolesCompletsUpdate.Size = new System.Drawing.Size(422, 126);
            this.dgvRolesCompletsUpdate.TabIndex = 8;
            // 
            // tlpSecondaireActionsUpdate
            // 
            this.tlpSecondaireActionsUpdate.BackColor = System.Drawing.Color.DarkGray;
            this.tlpSecondaireActionsUpdate.ColumnCount = 5;
            this.tlpSecondaireActionsUpdate.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.02762F));
            this.tlpSecondaireActionsUpdate.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.45939F));
            this.tlpSecondaireActionsUpdate.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.02762F));
            this.tlpSecondaireActionsUpdate.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.45775F));
            this.tlpSecondaireActionsUpdate.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.02762F));
            this.tlpSecondaireActionsUpdate.Controls.Add(this.btnModifierFilmComplet, 1, 1);
            this.tlpSecondaireActionsUpdate.Controls.Add(this.btnReinitialiserUpdate, 3, 1);
            this.tlpSecondaireActionsUpdate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpSecondaireActionsUpdate.Location = new System.Drawing.Point(521, 463);
            this.tlpSecondaireActionsUpdate.Name = "tlpSecondaireActionsUpdate";
            this.tlpSecondaireActionsUpdate.RowCount = 3;
            this.tlpSecondaireActionsUpdate.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 22.82609F));
            this.tlpSecondaireActionsUpdate.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 54.34783F));
            this.tlpSecondaireActionsUpdate.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 22.82609F));
            this.tlpSecondaireActionsUpdate.Size = new System.Drawing.Size(428, 162);
            this.tlpSecondaireActionsUpdate.TabIndex = 15;
            // 
            // btnModifierFilmComplet
            // 
            this.btnModifierFilmComplet.BackColor = System.Drawing.Color.Transparent;
            this.btnModifierFilmComplet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnModifierFilmComplet.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnModifierFilmComplet.Location = new System.Drawing.Point(34, 41);
            this.btnModifierFilmComplet.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnModifierFilmComplet.Name = "btnModifierFilmComplet";
            this.btnModifierFilmComplet.Size = new System.Drawing.Size(160, 78);
            this.btnModifierFilmComplet.TabIndex = 11;
            this.btnModifierFilmComplet.Text = "Modifier";
            this.btnModifierFilmComplet.UseVisualStyleBackColor = false;
            this.btnModifierFilmComplet.Click += new System.EventHandler(this.btnModifierFilmComplet_Click);
            // 
            // btnReinitialiserUpdate
            // 
            this.btnReinitialiserUpdate.BackColor = System.Drawing.Color.Transparent;
            this.btnReinitialiserUpdate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnReinitialiserUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReinitialiserUpdate.Location = new System.Drawing.Point(232, 41);
            this.btnReinitialiserUpdate.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnReinitialiserUpdate.Name = "btnReinitialiserUpdate";
            this.btnReinitialiserUpdate.Size = new System.Drawing.Size(160, 78);
            this.btnReinitialiserUpdate.TabIndex = 12;
            this.btnReinitialiserUpdate.Text = "Réinitialiser";
            this.btnReinitialiserUpdate.UseVisualStyleBackColor = false;
            this.btnReinitialiserUpdate.Click += new System.EventHandler(this.btnReinitialiserUpdate_Click);
            // 
            // tabInsert
            // 
            this.tabInsert.BackColor = System.Drawing.SystemColors.Control;
            this.tabInsert.Controls.Add(this.tlpPrimaireInsert);
            this.tabInsert.Location = new System.Drawing.Point(4, 34);
            this.tabInsert.Name = "tabInsert";
            this.tabInsert.Size = new System.Drawing.Size(996, 686);
            this.tabInsert.TabIndex = 3;
            this.tabInsert.Text = "Insérer";
            // 
            // tlpPrimaireInsert
            // 
            this.tlpPrimaireInsert.ColumnCount = 5;
            this.tlpPrimaireInsert.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4.263425F));
            this.tlpPrimaireInsert.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 43.60651F));
            this.tlpPrimaireInsert.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4.263425F));
            this.tlpPrimaireInsert.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 43.60651F));
            this.tlpPrimaireInsert.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4.260131F));
            this.tlpPrimaireInsert.Controls.Add(this.tlpSecondaireResumeInsert, 1, 5);
            this.tlpPrimaireInsert.Controls.Add(this.tlpSecondaireTitreEtIdInsert, 1, 1);
            this.tlpPrimaireInsert.Controls.Add(this.tlpSecondaireDateEtDureeInsert, 1, 3);
            this.tlpPrimaireInsert.Controls.Add(this.tlpSecondaireGenreInsert, 1, 7);
            this.tlpPrimaireInsert.Controls.Add(this.tlpSecondaireRealisateurInsert, 1, 9);
            this.tlpPrimaireInsert.Controls.Add(this.tlpSecondaireRolesCompletsInsert, 1, 11);
            this.tlpPrimaireInsert.Controls.Add(this.tlpSecondaireActionsInsert, 3, 11);
            this.tlpPrimaireInsert.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpPrimaireInsert.Location = new System.Drawing.Point(0, 0);
            this.tlpPrimaireInsert.Name = "tlpPrimaireInsert";
            this.tlpPrimaireInsert.RowCount = 13;
            this.tlpPrimaireInsert.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.914742F));
            this.tlpPrimaireInsert.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.208695F));
            this.tlpPrimaireInsert.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 2.05845F));
            this.tlpPrimaireInsert.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.208695F));
            this.tlpPrimaireInsert.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 2.05845F));
            this.tlpPrimaireInsert.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.41739F));
            this.tlpPrimaireInsert.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 2.05845F));
            this.tlpPrimaireInsert.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.208695F));
            this.tlpPrimaireInsert.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 2.05845F));
            this.tlpPrimaireInsert.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.208695F));
            this.tlpPrimaireInsert.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 2.05845F));
            this.tlpPrimaireInsert.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 24.62609F));
            this.tlpPrimaireInsert.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.914742F));
            this.tlpPrimaireInsert.Size = new System.Drawing.Size(996, 686);
            this.tlpPrimaireInsert.TabIndex = 2;
            // 
            // tlpSecondaireResumeInsert
            // 
            this.tlpSecondaireResumeInsert.ColumnCount = 1;
            this.tlpSecondaireResumeInsert.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpSecondaireResumeInsert.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpSecondaireResumeInsert.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpSecondaireResumeInsert.Controls.Add(this.txtResumeInsert, 0, 1);
            this.tlpSecondaireResumeInsert.Controls.Add(this.lblResumeInsert, 0, 0);
            this.tlpSecondaireResumeInsert.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpSecondaireResumeInsert.Location = new System.Drawing.Point(45, 197);
            this.tlpSecondaireResumeInsert.Name = "tlpSecondaireResumeInsert";
            this.tlpSecondaireResumeInsert.RowCount = 2;
            this.tlpSecondaireResumeInsert.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tlpSecondaireResumeInsert.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 75F));
            this.tlpSecondaireResumeInsert.Size = new System.Drawing.Size(428, 106);
            this.tlpSecondaireResumeInsert.TabIndex = 9;
            // 
            // txtResumeInsert
            // 
            this.txtResumeInsert.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtResumeInsert.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtResumeInsert.Location = new System.Drawing.Point(3, 29);
            this.txtResumeInsert.Multiline = true;
            this.txtResumeInsert.Name = "txtResumeInsert";
            this.txtResumeInsert.Size = new System.Drawing.Size(422, 74);
            this.txtResumeInsert.TabIndex = 8;
            this.txtResumeInsert.Validating += new System.ComponentModel.CancelEventHandler(this.txtResumeInsert_Validating);
            // 
            // lblResumeInsert
            // 
            this.lblResumeInsert.AutoSize = true;
            this.lblResumeInsert.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblResumeInsert.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResumeInsert.ForeColor = System.Drawing.Color.Black;
            this.lblResumeInsert.Location = new System.Drawing.Point(3, 0);
            this.lblResumeInsert.Name = "lblResumeInsert";
            this.lblResumeInsert.Size = new System.Drawing.Size(422, 26);
            this.lblResumeInsert.TabIndex = 6;
            this.lblResumeInsert.Text = "Résumé";
            this.lblResumeInsert.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tlpSecondaireTitreEtIdInsert
            // 
            this.tlpSecondaireTitreEtIdInsert.ColumnCount = 3;
            this.tlpSecondaireTitreEtIdInsert.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tlpSecondaireTitreEtIdInsert.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7F));
            this.tlpSecondaireTitreEtIdInsert.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13F));
            this.tlpSecondaireTitreEtIdInsert.Controls.Add(this.lblTitreInsert, 0, 0);
            this.tlpSecondaireTitreEtIdInsert.Controls.Add(this.lblIdInsert, 2, 0);
            this.tlpSecondaireTitreEtIdInsert.Controls.Add(this.txtTitreInsert, 0, 1);
            this.tlpSecondaireTitreEtIdInsert.Controls.Add(this.txtIdInsert, 2, 1);
            this.tlpSecondaireTitreEtIdInsert.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpSecondaireTitreEtIdInsert.Location = new System.Drawing.Point(45, 57);
            this.tlpSecondaireTitreEtIdInsert.Name = "tlpSecondaireTitreEtIdInsert";
            this.tlpSecondaireTitreEtIdInsert.RowCount = 2;
            this.tlpSecondaireTitreEtIdInsert.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpSecondaireTitreEtIdInsert.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpSecondaireTitreEtIdInsert.Size = new System.Drawing.Size(428, 50);
            this.tlpSecondaireTitreEtIdInsert.TabIndex = 0;
            // 
            // lblTitreInsert
            // 
            this.lblTitreInsert.AutoSize = true;
            this.lblTitreInsert.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTitreInsert.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitreInsert.ForeColor = System.Drawing.Color.Black;
            this.lblTitreInsert.Location = new System.Drawing.Point(3, 0);
            this.lblTitreInsert.Name = "lblTitreInsert";
            this.lblTitreInsert.Size = new System.Drawing.Size(336, 25);
            this.lblTitreInsert.TabIndex = 5;
            this.lblTitreInsert.Text = "Titre";
            this.lblTitreInsert.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblIdInsert
            // 
            this.lblIdInsert.AutoSize = true;
            this.lblIdInsert.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblIdInsert.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIdInsert.ForeColor = System.Drawing.Color.Black;
            this.lblIdInsert.Location = new System.Drawing.Point(374, 0);
            this.lblIdInsert.Name = "lblIdInsert";
            this.lblIdInsert.Size = new System.Drawing.Size(51, 25);
            this.lblIdInsert.TabIndex = 6;
            this.lblIdInsert.Text = "Id";
            this.lblIdInsert.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtTitreInsert
            // 
            this.txtTitreInsert.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtTitreInsert.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTitreInsert.Location = new System.Drawing.Point(3, 28);
            this.txtTitreInsert.Name = "txtTitreInsert";
            this.txtTitreInsert.Size = new System.Drawing.Size(336, 27);
            this.txtTitreInsert.TabIndex = 7;
            this.txtTitreInsert.Validating += new System.ComponentModel.CancelEventHandler(this.txtTitreInsert_Validating);
            // 
            // txtIdInsert
            // 
            this.txtIdInsert.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtIdInsert.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIdInsert.Location = new System.Drawing.Point(374, 28);
            this.txtIdInsert.Name = "txtIdInsert";
            this.txtIdInsert.ReadOnly = true;
            this.txtIdInsert.Size = new System.Drawing.Size(51, 27);
            this.txtIdInsert.TabIndex = 8;
            // 
            // tlpSecondaireDateEtDureeInsert
            // 
            this.tlpSecondaireDateEtDureeInsert.ColumnCount = 4;
            this.tlpSecondaireDateEtDureeInsert.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 65.65656F));
            this.tlpSecondaireDateEtDureeInsert.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.070707F));
            this.tlpSecondaireDateEtDureeInsert.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.12121F));
            this.tlpSecondaireDateEtDureeInsert.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15.15152F));
            this.tlpSecondaireDateEtDureeInsert.Controls.Add(this.lblDateInsert, 0, 0);
            this.tlpSecondaireDateEtDureeInsert.Controls.Add(this.lblDureeInsert, 2, 0);
            this.tlpSecondaireDateEtDureeInsert.Controls.Add(this.datDateInsert, 0, 1);
            this.tlpSecondaireDateEtDureeInsert.Controls.Add(this.txtDureeInsert, 2, 1);
            this.tlpSecondaireDateEtDureeInsert.Controls.Add(this.lblDureeMinutesInsert, 3, 1);
            this.tlpSecondaireDateEtDureeInsert.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpSecondaireDateEtDureeInsert.Location = new System.Drawing.Point(45, 127);
            this.tlpSecondaireDateEtDureeInsert.Name = "tlpSecondaireDateEtDureeInsert";
            this.tlpSecondaireDateEtDureeInsert.RowCount = 2;
            this.tlpSecondaireDateEtDureeInsert.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpSecondaireDateEtDureeInsert.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpSecondaireDateEtDureeInsert.Size = new System.Drawing.Size(428, 50);
            this.tlpSecondaireDateEtDureeInsert.TabIndex = 1;
            // 
            // lblDateInsert
            // 
            this.lblDateInsert.AutoSize = true;
            this.lblDateInsert.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDateInsert.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDateInsert.ForeColor = System.Drawing.Color.Black;
            this.lblDateInsert.Location = new System.Drawing.Point(3, 0);
            this.lblDateInsert.Name = "lblDateInsert";
            this.lblDateInsert.Size = new System.Drawing.Size(275, 25);
            this.lblDateInsert.TabIndex = 5;
            this.lblDateInsert.Text = "Date de parution";
            this.lblDateInsert.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblDureeInsert
            // 
            this.lblDureeInsert.AutoSize = true;
            this.tlpSecondaireDateEtDureeInsert.SetColumnSpan(this.lblDureeInsert, 2);
            this.lblDureeInsert.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDureeInsert.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDureeInsert.ForeColor = System.Drawing.Color.Black;
            this.lblDureeInsert.Location = new System.Drawing.Point(314, 0);
            this.lblDureeInsert.Name = "lblDureeInsert";
            this.lblDureeInsert.Size = new System.Drawing.Size(111, 25);
            this.lblDureeInsert.TabIndex = 6;
            this.lblDureeInsert.Text = "Durée";
            this.lblDureeInsert.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // datDateInsert
            // 
            this.datDateInsert.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datDateInsert.Dock = System.Windows.Forms.DockStyle.Fill;
            this.datDateInsert.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datDateInsert.Location = new System.Drawing.Point(3, 28);
            this.datDateInsert.Name = "datDateInsert";
            this.datDateInsert.Size = new System.Drawing.Size(275, 27);
            this.datDateInsert.TabIndex = 7;
            // 
            // txtDureeInsert
            // 
            this.txtDureeInsert.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtDureeInsert.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDureeInsert.Location = new System.Drawing.Point(314, 28);
            this.txtDureeInsert.Name = "txtDureeInsert";
            this.txtDureeInsert.Size = new System.Drawing.Size(45, 27);
            this.txtDureeInsert.TabIndex = 8;
            this.txtDureeInsert.Validating += new System.ComponentModel.CancelEventHandler(this.txtDureeInsert_Validating);
            // 
            // lblDureeMinutesInsert
            // 
            this.lblDureeMinutesInsert.AutoSize = true;
            this.lblDureeMinutesInsert.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDureeMinutesInsert.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDureeMinutesInsert.ForeColor = System.Drawing.Color.Black;
            this.lblDureeMinutesInsert.Location = new System.Drawing.Point(365, 25);
            this.lblDureeMinutesInsert.Name = "lblDureeMinutesInsert";
            this.lblDureeMinutesInsert.Size = new System.Drawing.Size(60, 25);
            this.lblDureeMinutesInsert.TabIndex = 9;
            this.lblDureeMinutesInsert.Text = "minutes";
            this.lblDureeMinutesInsert.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tlpSecondaireGenreInsert
            // 
            this.tlpSecondaireGenreInsert.ColumnCount = 2;
            this.tlpSecondaireGenreInsert.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 93F));
            this.tlpSecondaireGenreInsert.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7F));
            this.tlpSecondaireGenreInsert.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpSecondaireGenreInsert.Controls.Add(this.cbxGenreInsert, 0, 1);
            this.tlpSecondaireGenreInsert.Controls.Add(this.lblGenreInsert, 0, 0);
            this.tlpSecondaireGenreInsert.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpSecondaireGenreInsert.Location = new System.Drawing.Point(45, 323);
            this.tlpSecondaireGenreInsert.Name = "tlpSecondaireGenreInsert";
            this.tlpSecondaireGenreInsert.RowCount = 2;
            this.tlpSecondaireGenreInsert.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpSecondaireGenreInsert.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpSecondaireGenreInsert.Size = new System.Drawing.Size(428, 50);
            this.tlpSecondaireGenreInsert.TabIndex = 10;
            // 
            // cbxGenreInsert
            // 
            this.cbxGenreInsert.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cbxGenreInsert.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxGenreInsert.FormattingEnabled = true;
            this.cbxGenreInsert.Location = new System.Drawing.Point(3, 28);
            this.cbxGenreInsert.Name = "cbxGenreInsert";
            this.cbxGenreInsert.Size = new System.Drawing.Size(392, 28);
            this.cbxGenreInsert.TabIndex = 9;
            this.cbxGenreInsert.Validating += new System.ComponentModel.CancelEventHandler(this.cbxGenreInsert_Validating);
            // 
            // lblGenreInsert
            // 
            this.lblGenreInsert.AutoSize = true;
            this.lblGenreInsert.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblGenreInsert.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGenreInsert.ForeColor = System.Drawing.Color.Black;
            this.lblGenreInsert.Location = new System.Drawing.Point(3, 0);
            this.lblGenreInsert.Name = "lblGenreInsert";
            this.lblGenreInsert.Size = new System.Drawing.Size(392, 25);
            this.lblGenreInsert.TabIndex = 6;
            this.lblGenreInsert.Text = "Genre";
            this.lblGenreInsert.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tlpSecondaireRealisateurInsert
            // 
            this.tlpSecondaireRealisateurInsert.ColumnCount = 2;
            this.tlpSecondaireRealisateurInsert.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 93F));
            this.tlpSecondaireRealisateurInsert.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7F));
            this.tlpSecondaireRealisateurInsert.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpSecondaireRealisateurInsert.Controls.Add(this.cbxRealisateurInsert, 0, 1);
            this.tlpSecondaireRealisateurInsert.Controls.Add(this.lblRealisateurInsert, 0, 0);
            this.tlpSecondaireRealisateurInsert.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpSecondaireRealisateurInsert.Location = new System.Drawing.Point(45, 393);
            this.tlpSecondaireRealisateurInsert.Name = "tlpSecondaireRealisateurInsert";
            this.tlpSecondaireRealisateurInsert.RowCount = 2;
            this.tlpSecondaireRealisateurInsert.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpSecondaireRealisateurInsert.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpSecondaireRealisateurInsert.Size = new System.Drawing.Size(428, 50);
            this.tlpSecondaireRealisateurInsert.TabIndex = 11;
            // 
            // cbxRealisateurInsert
            // 
            this.cbxRealisateurInsert.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cbxRealisateurInsert.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxRealisateurInsert.FormattingEnabled = true;
            this.cbxRealisateurInsert.Location = new System.Drawing.Point(3, 28);
            this.cbxRealisateurInsert.Name = "cbxRealisateurInsert";
            this.cbxRealisateurInsert.Size = new System.Drawing.Size(392, 28);
            this.cbxRealisateurInsert.TabIndex = 9;
            this.cbxRealisateurInsert.Validating += new System.ComponentModel.CancelEventHandler(this.cbxRealisateurInsert_Validating);
            // 
            // lblRealisateurInsert
            // 
            this.lblRealisateurInsert.AutoSize = true;
            this.lblRealisateurInsert.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblRealisateurInsert.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRealisateurInsert.ForeColor = System.Drawing.Color.Black;
            this.lblRealisateurInsert.Location = new System.Drawing.Point(3, 0);
            this.lblRealisateurInsert.Name = "lblRealisateurInsert";
            this.lblRealisateurInsert.Size = new System.Drawing.Size(392, 25);
            this.lblRealisateurInsert.TabIndex = 6;
            this.lblRealisateurInsert.Text = "Réalisateur / Réalisatrice";
            this.lblRealisateurInsert.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tlpSecondaireRolesCompletsInsert
            // 
            this.tlpSecondaireRolesCompletsInsert.ColumnCount = 1;
            this.tlpSecondaireRolesCompletsInsert.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpSecondaireRolesCompletsInsert.Controls.Add(this.lblRolesCompletsInsert, 0, 0);
            this.tlpSecondaireRolesCompletsInsert.Controls.Add(this.dgvRolesCompletsInsert, 0, 1);
            this.tlpSecondaireRolesCompletsInsert.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpSecondaireRolesCompletsInsert.Location = new System.Drawing.Point(45, 463);
            this.tlpSecondaireRolesCompletsInsert.Name = "tlpSecondaireRolesCompletsInsert";
            this.tlpSecondaireRolesCompletsInsert.RowCount = 2;
            this.tlpSecondaireRolesCompletsInsert.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 19.04762F));
            this.tlpSecondaireRolesCompletsInsert.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80.95238F));
            this.tlpSecondaireRolesCompletsInsert.Size = new System.Drawing.Size(428, 162);
            this.tlpSecondaireRolesCompletsInsert.TabIndex = 12;
            // 
            // lblRolesCompletsInsert
            // 
            this.lblRolesCompletsInsert.AutoSize = true;
            this.lblRolesCompletsInsert.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblRolesCompletsInsert.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRolesCompletsInsert.ForeColor = System.Drawing.Color.Black;
            this.lblRolesCompletsInsert.Location = new System.Drawing.Point(3, 0);
            this.lblRolesCompletsInsert.Name = "lblRolesCompletsInsert";
            this.lblRolesCompletsInsert.Size = new System.Drawing.Size(422, 30);
            this.lblRolesCompletsInsert.TabIndex = 7;
            this.lblRolesCompletsInsert.Text = "Acteur(s) / Actrice(s)";
            this.lblRolesCompletsInsert.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // dgvRolesCompletsInsert
            // 
            this.dgvRolesCompletsInsert.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvRolesCompletsInsert.BackgroundColor = System.Drawing.Color.White;
            this.dgvRolesCompletsInsert.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRolesCompletsInsert.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvRolesCompletsInsert.Location = new System.Drawing.Point(3, 33);
            this.dgvRolesCompletsInsert.Name = "dgvRolesCompletsInsert";
            this.dgvRolesCompletsInsert.ReadOnly = true;
            this.dgvRolesCompletsInsert.RowHeadersWidth = 51;
            this.dgvRolesCompletsInsert.RowTemplate.Height = 24;
            this.dgvRolesCompletsInsert.Size = new System.Drawing.Size(422, 126);
            this.dgvRolesCompletsInsert.TabIndex = 8;
            // 
            // tlpSecondaireActionsInsert
            // 
            this.tlpSecondaireActionsInsert.BackColor = System.Drawing.Color.DarkGray;
            this.tlpSecondaireActionsInsert.ColumnCount = 5;
            this.tlpSecondaireActionsInsert.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.02762F));
            this.tlpSecondaireActionsInsert.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.45939F));
            this.tlpSecondaireActionsInsert.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.02762F));
            this.tlpSecondaireActionsInsert.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.45775F));
            this.tlpSecondaireActionsInsert.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.02762F));
            this.tlpSecondaireActionsInsert.Controls.Add(this.btnInsererFilmComplet, 1, 1);
            this.tlpSecondaireActionsInsert.Controls.Add(this.btnReinitialiserInsert, 3, 1);
            this.tlpSecondaireActionsInsert.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpSecondaireActionsInsert.Location = new System.Drawing.Point(521, 463);
            this.tlpSecondaireActionsInsert.Name = "tlpSecondaireActionsInsert";
            this.tlpSecondaireActionsInsert.RowCount = 3;
            this.tlpSecondaireActionsInsert.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 22.82609F));
            this.tlpSecondaireActionsInsert.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 54.34783F));
            this.tlpSecondaireActionsInsert.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 22.82609F));
            this.tlpSecondaireActionsInsert.Size = new System.Drawing.Size(428, 162);
            this.tlpSecondaireActionsInsert.TabIndex = 14;
            // 
            // btnInsererFilmComplet
            // 
            this.btnInsererFilmComplet.BackColor = System.Drawing.Color.Transparent;
            this.btnInsererFilmComplet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnInsererFilmComplet.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInsererFilmComplet.Location = new System.Drawing.Point(34, 41);
            this.btnInsererFilmComplet.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnInsererFilmComplet.Name = "btnInsererFilmComplet";
            this.btnInsererFilmComplet.Size = new System.Drawing.Size(160, 78);
            this.btnInsererFilmComplet.TabIndex = 11;
            this.btnInsererFilmComplet.Text = "Insérer";
            this.btnInsererFilmComplet.UseVisualStyleBackColor = false;
            this.btnInsererFilmComplet.Click += new System.EventHandler(this.btnInsererFilmComplet_Click);
            // 
            // btnReinitialiserInsert
            // 
            this.btnReinitialiserInsert.BackColor = System.Drawing.Color.Transparent;
            this.btnReinitialiserInsert.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnReinitialiserInsert.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReinitialiserInsert.Location = new System.Drawing.Point(232, 41);
            this.btnReinitialiserInsert.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnReinitialiserInsert.Name = "btnReinitialiserInsert";
            this.btnReinitialiserInsert.Size = new System.Drawing.Size(160, 78);
            this.btnReinitialiserInsert.TabIndex = 12;
            this.btnReinitialiserInsert.Text = "Réinitialiser";
            this.btnReinitialiserInsert.UseVisualStyleBackColor = false;
            this.btnReinitialiserInsert.Click += new System.EventHandler(this.btnReinitialiserInsert_Click);
            // 
            // tabDelete
            // 
            this.tabDelete.BackColor = System.Drawing.SystemColors.Control;
            this.tabDelete.Controls.Add(this.tlpPrimaireDelete);
            this.tabDelete.Location = new System.Drawing.Point(4, 34);
            this.tabDelete.Name = "tabDelete";
            this.tabDelete.Size = new System.Drawing.Size(996, 686);
            this.tabDelete.TabIndex = 4;
            this.tabDelete.Text = "Supprimer";
            // 
            // tlpPrimaireDelete
            // 
            this.tlpPrimaireDelete.ColumnCount = 5;
            this.tlpPrimaireDelete.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4.263425F));
            this.tlpPrimaireDelete.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 43.60651F));
            this.tlpPrimaireDelete.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4.263425F));
            this.tlpPrimaireDelete.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 43.60651F));
            this.tlpPrimaireDelete.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4.260131F));
            this.tlpPrimaireDelete.Controls.Add(this.tlpSecondaireResumeDelete, 1, 5);
            this.tlpPrimaireDelete.Controls.Add(this.tlpSecondaireTitreEtIdDelete, 1, 1);
            this.tlpPrimaireDelete.Controls.Add(this.tlpSecondaireDateEtDureeDelete, 1, 3);
            this.tlpPrimaireDelete.Controls.Add(this.tlpSecondaireGenreDelete, 1, 7);
            this.tlpPrimaireDelete.Controls.Add(this.tlpSecondaireRealisateurDelete, 1, 9);
            this.tlpPrimaireDelete.Controls.Add(this.tlpSecondaireRolesCompletsDelete, 1, 11);
            this.tlpPrimaireDelete.Controls.Add(this.tlpSecondaireActionDelete, 3, 11);
            this.tlpPrimaireDelete.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpPrimaireDelete.Location = new System.Drawing.Point(0, 0);
            this.tlpPrimaireDelete.Name = "tlpPrimaireDelete";
            this.tlpPrimaireDelete.RowCount = 13;
            this.tlpPrimaireDelete.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.914742F));
            this.tlpPrimaireDelete.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.208695F));
            this.tlpPrimaireDelete.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 2.05845F));
            this.tlpPrimaireDelete.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.208695F));
            this.tlpPrimaireDelete.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 2.05845F));
            this.tlpPrimaireDelete.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.41739F));
            this.tlpPrimaireDelete.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 2.05845F));
            this.tlpPrimaireDelete.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.208695F));
            this.tlpPrimaireDelete.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 2.05845F));
            this.tlpPrimaireDelete.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.208695F));
            this.tlpPrimaireDelete.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 2.05845F));
            this.tlpPrimaireDelete.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 24.62609F));
            this.tlpPrimaireDelete.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.914742F));
            this.tlpPrimaireDelete.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpPrimaireDelete.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpPrimaireDelete.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpPrimaireDelete.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpPrimaireDelete.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpPrimaireDelete.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpPrimaireDelete.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpPrimaireDelete.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpPrimaireDelete.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpPrimaireDelete.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpPrimaireDelete.Size = new System.Drawing.Size(996, 686);
            this.tlpPrimaireDelete.TabIndex = 2;
            // 
            // tlpSecondaireResumeDelete
            // 
            this.tlpSecondaireResumeDelete.ColumnCount = 1;
            this.tlpSecondaireResumeDelete.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpSecondaireResumeDelete.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpSecondaireResumeDelete.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpSecondaireResumeDelete.Controls.Add(this.txtResumeDelete, 0, 1);
            this.tlpSecondaireResumeDelete.Controls.Add(this.lblResumeDelete, 0, 0);
            this.tlpSecondaireResumeDelete.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpSecondaireResumeDelete.Location = new System.Drawing.Point(45, 197);
            this.tlpSecondaireResumeDelete.Name = "tlpSecondaireResumeDelete";
            this.tlpSecondaireResumeDelete.RowCount = 2;
            this.tlpSecondaireResumeDelete.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tlpSecondaireResumeDelete.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 75F));
            this.tlpSecondaireResumeDelete.Size = new System.Drawing.Size(428, 106);
            this.tlpSecondaireResumeDelete.TabIndex = 9;
            // 
            // txtResumeDelete
            // 
            this.txtResumeDelete.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtResumeDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtResumeDelete.Location = new System.Drawing.Point(3, 29);
            this.txtResumeDelete.Multiline = true;
            this.txtResumeDelete.Name = "txtResumeDelete";
            this.txtResumeDelete.ReadOnly = true;
            this.txtResumeDelete.Size = new System.Drawing.Size(422, 74);
            this.txtResumeDelete.TabIndex = 8;
            // 
            // lblResumeDelete
            // 
            this.lblResumeDelete.AutoSize = true;
            this.lblResumeDelete.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblResumeDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResumeDelete.ForeColor = System.Drawing.Color.Black;
            this.lblResumeDelete.Location = new System.Drawing.Point(3, 0);
            this.lblResumeDelete.Name = "lblResumeDelete";
            this.lblResumeDelete.Size = new System.Drawing.Size(422, 26);
            this.lblResumeDelete.TabIndex = 6;
            this.lblResumeDelete.Text = "Résumé";
            this.lblResumeDelete.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tlpSecondaireTitreEtIdDelete
            // 
            this.tlpSecondaireTitreEtIdDelete.ColumnCount = 3;
            this.tlpSecondaireTitreEtIdDelete.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tlpSecondaireTitreEtIdDelete.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7F));
            this.tlpSecondaireTitreEtIdDelete.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13F));
            this.tlpSecondaireTitreEtIdDelete.Controls.Add(this.lblTitreDelete, 0, 0);
            this.tlpSecondaireTitreEtIdDelete.Controls.Add(this.lblIdDelete, 2, 0);
            this.tlpSecondaireTitreEtIdDelete.Controls.Add(this.txtTitreDelete, 0, 1);
            this.tlpSecondaireTitreEtIdDelete.Controls.Add(this.cbxIdDelete, 2, 1);
            this.tlpSecondaireTitreEtIdDelete.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpSecondaireTitreEtIdDelete.Location = new System.Drawing.Point(45, 57);
            this.tlpSecondaireTitreEtIdDelete.Name = "tlpSecondaireTitreEtIdDelete";
            this.tlpSecondaireTitreEtIdDelete.RowCount = 2;
            this.tlpSecondaireTitreEtIdDelete.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpSecondaireTitreEtIdDelete.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpSecondaireTitreEtIdDelete.Size = new System.Drawing.Size(428, 50);
            this.tlpSecondaireTitreEtIdDelete.TabIndex = 0;
            // 
            // lblTitreDelete
            // 
            this.lblTitreDelete.AutoSize = true;
            this.lblTitreDelete.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTitreDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitreDelete.ForeColor = System.Drawing.Color.Black;
            this.lblTitreDelete.Location = new System.Drawing.Point(3, 0);
            this.lblTitreDelete.Name = "lblTitreDelete";
            this.lblTitreDelete.Size = new System.Drawing.Size(336, 25);
            this.lblTitreDelete.TabIndex = 5;
            this.lblTitreDelete.Text = "Titre";
            this.lblTitreDelete.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblIdDelete
            // 
            this.lblIdDelete.AutoSize = true;
            this.lblIdDelete.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblIdDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIdDelete.ForeColor = System.Drawing.Color.Black;
            this.lblIdDelete.Location = new System.Drawing.Point(374, 0);
            this.lblIdDelete.Name = "lblIdDelete";
            this.lblIdDelete.Size = new System.Drawing.Size(51, 25);
            this.lblIdDelete.TabIndex = 6;
            this.lblIdDelete.Text = "Id";
            this.lblIdDelete.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtTitreDelete
            // 
            this.txtTitreDelete.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtTitreDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTitreDelete.Location = new System.Drawing.Point(3, 28);
            this.txtTitreDelete.Name = "txtTitreDelete";
            this.txtTitreDelete.ReadOnly = true;
            this.txtTitreDelete.Size = new System.Drawing.Size(336, 27);
            this.txtTitreDelete.TabIndex = 7;
            // 
            // cbxIdDelete
            // 
            this.cbxIdDelete.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cbxIdDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxIdDelete.FormattingEnabled = true;
            this.cbxIdDelete.Location = new System.Drawing.Point(374, 28);
            this.cbxIdDelete.Name = "cbxIdDelete";
            this.cbxIdDelete.Size = new System.Drawing.Size(51, 28);
            this.cbxIdDelete.TabIndex = 8;
            this.cbxIdDelete.Text = "  !";
            this.cbxIdDelete.SelectedIndexChanged += new System.EventHandler(this.cbxIdDelete_SelectedIndexChanged);
            // 
            // tlpSecondaireDateEtDureeDelete
            // 
            this.tlpSecondaireDateEtDureeDelete.ColumnCount = 4;
            this.tlpSecondaireDateEtDureeDelete.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 65.65656F));
            this.tlpSecondaireDateEtDureeDelete.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.070707F));
            this.tlpSecondaireDateEtDureeDelete.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.12121F));
            this.tlpSecondaireDateEtDureeDelete.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15.15152F));
            this.tlpSecondaireDateEtDureeDelete.Controls.Add(this.lblDateDelete, 0, 0);
            this.tlpSecondaireDateEtDureeDelete.Controls.Add(this.lblDureeDelete, 2, 0);
            this.tlpSecondaireDateEtDureeDelete.Controls.Add(this.datDateDelete, 0, 1);
            this.tlpSecondaireDateEtDureeDelete.Controls.Add(this.txtDureeDelete, 2, 1);
            this.tlpSecondaireDateEtDureeDelete.Controls.Add(this.lblDureeMinutesDelete, 3, 1);
            this.tlpSecondaireDateEtDureeDelete.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpSecondaireDateEtDureeDelete.Location = new System.Drawing.Point(45, 127);
            this.tlpSecondaireDateEtDureeDelete.Name = "tlpSecondaireDateEtDureeDelete";
            this.tlpSecondaireDateEtDureeDelete.RowCount = 2;
            this.tlpSecondaireDateEtDureeDelete.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpSecondaireDateEtDureeDelete.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpSecondaireDateEtDureeDelete.Size = new System.Drawing.Size(428, 50);
            this.tlpSecondaireDateEtDureeDelete.TabIndex = 1;
            // 
            // lblDateDelete
            // 
            this.lblDateDelete.AutoSize = true;
            this.lblDateDelete.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDateDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDateDelete.ForeColor = System.Drawing.Color.Black;
            this.lblDateDelete.Location = new System.Drawing.Point(3, 0);
            this.lblDateDelete.Name = "lblDateDelete";
            this.lblDateDelete.Size = new System.Drawing.Size(275, 25);
            this.lblDateDelete.TabIndex = 5;
            this.lblDateDelete.Text = "Date de parution";
            this.lblDateDelete.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblDureeDelete
            // 
            this.lblDureeDelete.AutoSize = true;
            this.tlpSecondaireDateEtDureeDelete.SetColumnSpan(this.lblDureeDelete, 2);
            this.lblDureeDelete.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDureeDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDureeDelete.ForeColor = System.Drawing.Color.Black;
            this.lblDureeDelete.Location = new System.Drawing.Point(314, 0);
            this.lblDureeDelete.Name = "lblDureeDelete";
            this.lblDureeDelete.Size = new System.Drawing.Size(111, 25);
            this.lblDureeDelete.TabIndex = 6;
            this.lblDureeDelete.Text = "Durée";
            this.lblDureeDelete.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // datDateDelete
            // 
            this.datDateDelete.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datDateDelete.Dock = System.Windows.Forms.DockStyle.Fill;
            this.datDateDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datDateDelete.Location = new System.Drawing.Point(3, 28);
            this.datDateDelete.Name = "datDateDelete";
            this.datDateDelete.Size = new System.Drawing.Size(275, 27);
            this.datDateDelete.TabIndex = 7;
            // 
            // txtDureeDelete
            // 
            this.txtDureeDelete.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtDureeDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDureeDelete.Location = new System.Drawing.Point(314, 28);
            this.txtDureeDelete.Name = "txtDureeDelete";
            this.txtDureeDelete.ReadOnly = true;
            this.txtDureeDelete.Size = new System.Drawing.Size(45, 27);
            this.txtDureeDelete.TabIndex = 8;
            // 
            // lblDureeMinutesDelete
            // 
            this.lblDureeMinutesDelete.AutoSize = true;
            this.lblDureeMinutesDelete.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblDureeMinutesDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDureeMinutesDelete.ForeColor = System.Drawing.Color.Black;
            this.lblDureeMinutesDelete.Location = new System.Drawing.Point(365, 25);
            this.lblDureeMinutesDelete.Name = "lblDureeMinutesDelete";
            this.lblDureeMinutesDelete.Size = new System.Drawing.Size(60, 25);
            this.lblDureeMinutesDelete.TabIndex = 9;
            this.lblDureeMinutesDelete.Text = "minutes";
            this.lblDureeMinutesDelete.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tlpSecondaireGenreDelete
            // 
            this.tlpSecondaireGenreDelete.ColumnCount = 1;
            this.tlpSecondaireGenreDelete.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpSecondaireGenreDelete.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpSecondaireGenreDelete.Controls.Add(this.txtGenreDelete, 0, 1);
            this.tlpSecondaireGenreDelete.Controls.Add(this.lblGenreDelete, 0, 0);
            this.tlpSecondaireGenreDelete.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpSecondaireGenreDelete.Location = new System.Drawing.Point(45, 323);
            this.tlpSecondaireGenreDelete.Name = "tlpSecondaireGenreDelete";
            this.tlpSecondaireGenreDelete.RowCount = 2;
            this.tlpSecondaireGenreDelete.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpSecondaireGenreDelete.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpSecondaireGenreDelete.Size = new System.Drawing.Size(428, 50);
            this.tlpSecondaireGenreDelete.TabIndex = 10;
            // 
            // txtGenreDelete
            // 
            this.txtGenreDelete.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtGenreDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGenreDelete.Location = new System.Drawing.Point(3, 28);
            this.txtGenreDelete.Name = "txtGenreDelete";
            this.txtGenreDelete.ReadOnly = true;
            this.txtGenreDelete.Size = new System.Drawing.Size(422, 27);
            this.txtGenreDelete.TabIndex = 8;
            // 
            // lblGenreDelete
            // 
            this.lblGenreDelete.AutoSize = true;
            this.lblGenreDelete.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblGenreDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGenreDelete.ForeColor = System.Drawing.Color.Black;
            this.lblGenreDelete.Location = new System.Drawing.Point(3, 0);
            this.lblGenreDelete.Name = "lblGenreDelete";
            this.lblGenreDelete.Size = new System.Drawing.Size(422, 25);
            this.lblGenreDelete.TabIndex = 7;
            this.lblGenreDelete.Text = "Genre";
            this.lblGenreDelete.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tlpSecondaireRealisateurDelete
            // 
            this.tlpSecondaireRealisateurDelete.ColumnCount = 1;
            this.tlpSecondaireRealisateurDelete.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpSecondaireRealisateurDelete.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpSecondaireRealisateurDelete.Controls.Add(this.txtRealisateurDelete, 0, 1);
            this.tlpSecondaireRealisateurDelete.Controls.Add(this.lblRealisateurDelete, 0, 0);
            this.tlpSecondaireRealisateurDelete.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpSecondaireRealisateurDelete.Location = new System.Drawing.Point(45, 393);
            this.tlpSecondaireRealisateurDelete.Name = "tlpSecondaireRealisateurDelete";
            this.tlpSecondaireRealisateurDelete.RowCount = 2;
            this.tlpSecondaireRealisateurDelete.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpSecondaireRealisateurDelete.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tlpSecondaireRealisateurDelete.Size = new System.Drawing.Size(428, 50);
            this.tlpSecondaireRealisateurDelete.TabIndex = 11;
            // 
            // txtRealisateurDelete
            // 
            this.txtRealisateurDelete.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtRealisateurDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRealisateurDelete.Location = new System.Drawing.Point(3, 28);
            this.txtRealisateurDelete.Name = "txtRealisateurDelete";
            this.txtRealisateurDelete.ReadOnly = true;
            this.txtRealisateurDelete.Size = new System.Drawing.Size(422, 27);
            this.txtRealisateurDelete.TabIndex = 9;
            // 
            // lblRealisateurDelete
            // 
            this.lblRealisateurDelete.AutoSize = true;
            this.lblRealisateurDelete.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblRealisateurDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRealisateurDelete.ForeColor = System.Drawing.Color.Black;
            this.lblRealisateurDelete.Location = new System.Drawing.Point(3, 0);
            this.lblRealisateurDelete.Name = "lblRealisateurDelete";
            this.lblRealisateurDelete.Size = new System.Drawing.Size(422, 25);
            this.lblRealisateurDelete.TabIndex = 7;
            this.lblRealisateurDelete.Text = "Réalisateur / Réalisatrice";
            this.lblRealisateurDelete.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tlpSecondaireRolesCompletsDelete
            // 
            this.tlpSecondaireRolesCompletsDelete.ColumnCount = 1;
            this.tlpSecondaireRolesCompletsDelete.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpSecondaireRolesCompletsDelete.Controls.Add(this.lblRolesCompletsDelete, 0, 0);
            this.tlpSecondaireRolesCompletsDelete.Controls.Add(this.dgvRolesCompletsDelete, 0, 1);
            this.tlpSecondaireRolesCompletsDelete.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpSecondaireRolesCompletsDelete.Location = new System.Drawing.Point(45, 463);
            this.tlpSecondaireRolesCompletsDelete.Name = "tlpSecondaireRolesCompletsDelete";
            this.tlpSecondaireRolesCompletsDelete.RowCount = 2;
            this.tlpSecondaireRolesCompletsDelete.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 19.04762F));
            this.tlpSecondaireRolesCompletsDelete.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80.95238F));
            this.tlpSecondaireRolesCompletsDelete.Size = new System.Drawing.Size(428, 162);
            this.tlpSecondaireRolesCompletsDelete.TabIndex = 12;
            // 
            // lblRolesCompletsDelete
            // 
            this.lblRolesCompletsDelete.AutoSize = true;
            this.lblRolesCompletsDelete.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblRolesCompletsDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRolesCompletsDelete.ForeColor = System.Drawing.Color.Black;
            this.lblRolesCompletsDelete.Location = new System.Drawing.Point(3, 0);
            this.lblRolesCompletsDelete.Name = "lblRolesCompletsDelete";
            this.lblRolesCompletsDelete.Size = new System.Drawing.Size(422, 30);
            this.lblRolesCompletsDelete.TabIndex = 7;
            this.lblRolesCompletsDelete.Text = "Acteur(s) / Actrice(s)";
            this.lblRolesCompletsDelete.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // dgvRolesCompletsDelete
            // 
            this.dgvRolesCompletsDelete.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvRolesCompletsDelete.BackgroundColor = System.Drawing.Color.White;
            this.dgvRolesCompletsDelete.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRolesCompletsDelete.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvRolesCompletsDelete.Location = new System.Drawing.Point(3, 33);
            this.dgvRolesCompletsDelete.Name = "dgvRolesCompletsDelete";
            this.dgvRolesCompletsDelete.ReadOnly = true;
            this.dgvRolesCompletsDelete.RowHeadersWidth = 51;
            this.dgvRolesCompletsDelete.RowTemplate.Height = 24;
            this.dgvRolesCompletsDelete.Size = new System.Drawing.Size(422, 126);
            this.dgvRolesCompletsDelete.TabIndex = 8;
            // 
            // tlpSecondaireActionDelete
            // 
            this.tlpSecondaireActionDelete.BackColor = System.Drawing.Color.DarkGray;
            this.tlpSecondaireActionDelete.ColumnCount = 3;
            this.tlpSecondaireActionDelete.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.88825F));
            this.tlpSecondaireActionDelete.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 84.2235F));
            this.tlpSecondaireActionDelete.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.88825F));
            this.tlpSecondaireActionDelete.Controls.Add(this.btnSupprimerFilmComplet, 1, 1);
            this.tlpSecondaireActionDelete.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpSecondaireActionDelete.Location = new System.Drawing.Point(521, 463);
            this.tlpSecondaireActionDelete.Name = "tlpSecondaireActionDelete";
            this.tlpSecondaireActionDelete.RowCount = 3;
            this.tlpSecondaireActionDelete.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 22.82609F));
            this.tlpSecondaireActionDelete.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 54.34783F));
            this.tlpSecondaireActionDelete.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 22.82609F));
            this.tlpSecondaireActionDelete.Size = new System.Drawing.Size(428, 162);
            this.tlpSecondaireActionDelete.TabIndex = 13;
            // 
            // btnSupprimerFilmComplet
            // 
            this.btnSupprimerFilmComplet.BackColor = System.Drawing.Color.Transparent;
            this.btnSupprimerFilmComplet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnSupprimerFilmComplet.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSupprimerFilmComplet.Location = new System.Drawing.Point(37, 41);
            this.btnSupprimerFilmComplet.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnSupprimerFilmComplet.Name = "btnSupprimerFilmComplet";
            this.btnSupprimerFilmComplet.Size = new System.Drawing.Size(352, 78);
            this.btnSupprimerFilmComplet.TabIndex = 10;
            this.btnSupprimerFilmComplet.Text = "Supprimer";
            this.btnSupprimerFilmComplet.UseVisualStyleBackColor = false;
            this.btnSupprimerFilmComplet.Click += new System.EventHandler(this.btnSupprimerFilmComplet_Click);
            // 
            // frmGestionnaire
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1004, 724);
            this.Controls.Add(this.tbcGestionnaire);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "frmGestionnaire";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Les Films du Plein Pays";
            this.Load += new System.EventHandler(this.frmGestionnaire_Load);
            this.tbcGestionnaire.ResumeLayout(false);
            this.tabAccueil.ResumeLayout(false);
            this.tlpPrimaireAccueil.ResumeLayout(false);
            this.tlpSecondaireTitresAccueil.ResumeLayout(false);
            this.tlpSecondaireTitresAccueil.PerformLayout();
            this.tlpSecondaireActionsAccueil.ResumeLayout(false);
            this.tlpSecondaireActionsAccueil.PerformLayout();
            this.tabSelect.ResumeLayout(false);
            this.tlpPrimaireSelect.ResumeLayout(false);
            this.tlpSecondaireResumeSelect.ResumeLayout(false);
            this.tlpSecondaireResumeSelect.PerformLayout();
            this.tlpSecondaireTitreEtIdSelect.ResumeLayout(false);
            this.tlpSecondaireTitreEtIdSelect.PerformLayout();
            this.tlpSecondaireDateEtDureeSelect.ResumeLayout(false);
            this.tlpSecondaireDateEtDureeSelect.PerformLayout();
            this.tlpSecondaireGenreSelect.ResumeLayout(false);
            this.tlpSecondaireGenreSelect.PerformLayout();
            this.tlpSecondaireRealisateurSelect.ResumeLayout(false);
            this.tlpSecondaireRealisateurSelect.PerformLayout();
            this.tlpRolesCompletsSelect.ResumeLayout(false);
            this.tlpRolesCompletsSelect.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRolesCompletsSelect)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAfficheSelect)).EndInit();
            this.tabUpdate.ResumeLayout(false);
            this.tlpPrimaireUpdate.ResumeLayout(false);
            this.tlpSecondaireResumeUpdate.ResumeLayout(false);
            this.tlpSecondaireResumeUpdate.PerformLayout();
            this.tlpSecondaireTitreEtIdUpdate.ResumeLayout(false);
            this.tlpSecondaireTitreEtIdUpdate.PerformLayout();
            this.tlpSecondaireDateEtDureeUpdate.ResumeLayout(false);
            this.tlpSecondaireDateEtDureeUpdate.PerformLayout();
            this.tlpSecondaireGenreUpdate.ResumeLayout(false);
            this.tlpSecondaireGenreUpdate.PerformLayout();
            this.tlpSecondaireRealisateurUpdate.ResumeLayout(false);
            this.tlpSecondaireRealisateurUpdate.PerformLayout();
            this.tlpSecondaireRolesCompletsUpdate.ResumeLayout(false);
            this.tlpSecondaireRolesCompletsUpdate.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRolesCompletsUpdate)).EndInit();
            this.tlpSecondaireActionsUpdate.ResumeLayout(false);
            this.tabInsert.ResumeLayout(false);
            this.tlpPrimaireInsert.ResumeLayout(false);
            this.tlpSecondaireResumeInsert.ResumeLayout(false);
            this.tlpSecondaireResumeInsert.PerformLayout();
            this.tlpSecondaireTitreEtIdInsert.ResumeLayout(false);
            this.tlpSecondaireTitreEtIdInsert.PerformLayout();
            this.tlpSecondaireDateEtDureeInsert.ResumeLayout(false);
            this.tlpSecondaireDateEtDureeInsert.PerformLayout();
            this.tlpSecondaireGenreInsert.ResumeLayout(false);
            this.tlpSecondaireGenreInsert.PerformLayout();
            this.tlpSecondaireRealisateurInsert.ResumeLayout(false);
            this.tlpSecondaireRealisateurInsert.PerformLayout();
            this.tlpSecondaireRolesCompletsInsert.ResumeLayout(false);
            this.tlpSecondaireRolesCompletsInsert.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRolesCompletsInsert)).EndInit();
            this.tlpSecondaireActionsInsert.ResumeLayout(false);
            this.tabDelete.ResumeLayout(false);
            this.tlpPrimaireDelete.ResumeLayout(false);
            this.tlpSecondaireResumeDelete.ResumeLayout(false);
            this.tlpSecondaireResumeDelete.PerformLayout();
            this.tlpSecondaireTitreEtIdDelete.ResumeLayout(false);
            this.tlpSecondaireTitreEtIdDelete.PerformLayout();
            this.tlpSecondaireDateEtDureeDelete.ResumeLayout(false);
            this.tlpSecondaireDateEtDureeDelete.PerformLayout();
            this.tlpSecondaireGenreDelete.ResumeLayout(false);
            this.tlpSecondaireGenreDelete.PerformLayout();
            this.tlpSecondaireRealisateurDelete.ResumeLayout(false);
            this.tlpSecondaireRealisateurDelete.PerformLayout();
            this.tlpSecondaireRolesCompletsDelete.ResumeLayout(false);
            this.tlpSecondaireRolesCompletsDelete.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRolesCompletsDelete)).EndInit();
            this.tlpSecondaireActionDelete.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tbcGestionnaire;
        private System.Windows.Forms.TabPage tabAccueil;
        private System.Windows.Forms.TableLayoutPanel tlpPrimaireAccueil;
        private System.Windows.Forms.TabPage tabSelect;
        private System.Windows.Forms.TabPage tabUpdate;
        private System.Windows.Forms.TabPage tabInsert;
        private System.Windows.Forms.TabPage tabDelete;
        private System.Windows.Forms.TableLayoutPanel tlpSecondaireTitresAccueil;
        private System.Windows.Forms.Label lblSousTitreAccueil;
        private System.Windows.Forms.Label lblTitreAccueil;
        private System.Windows.Forms.TableLayoutPanel tlpSecondaireActionsAccueil;
        private System.Windows.Forms.Label lblActionsAccueil;
        private System.Windows.Forms.Button btnAllerAOngletSelect;
        private System.Windows.Forms.Button btnAllerAOngletUpdate;
        private System.Windows.Forms.Button btnAllerAOngletInsert;
        private System.Windows.Forms.Button btnAllerAOngletDelete;
        private System.Windows.Forms.TableLayoutPanel tlpPrimaireUpdate;
        private System.Windows.Forms.TableLayoutPanel tlpSecondaireTitreEtIdUpdate;
        private System.Windows.Forms.Label lblTitreUpdate;
        private System.Windows.Forms.Label lblIdUpdate;
        private System.Windows.Forms.TextBox txtTitreUpdate;
        private System.Windows.Forms.ComboBox cbxIdUpdate;
        private System.Windows.Forms.TableLayoutPanel tlpSecondaireResumeUpdate;
        private System.Windows.Forms.TableLayoutPanel tlpSecondaireDateEtDureeUpdate;
        private System.Windows.Forms.Label lblDateUpdate;
        private System.Windows.Forms.Label lblDureeUpdate;
        private System.Windows.Forms.DateTimePicker datDateUpdate;
        private System.Windows.Forms.TextBox txtDureeUpdate;
        private System.Windows.Forms.Label lblDureeMinutesUpdate;
        private System.Windows.Forms.TextBox txtResumeUpdate;
        private System.Windows.Forms.Label lblResumeUpdate;
        private System.Windows.Forms.TableLayoutPanel tlpSecondaireGenreUpdate;
        private System.Windows.Forms.ComboBox cbxGenreUpdate;
        private System.Windows.Forms.Label lblGenreUpdate;
        private System.Windows.Forms.TableLayoutPanel tlpSecondaireRealisateurUpdate;
        private System.Windows.Forms.ComboBox cbxRealisateurUpdate;
        private System.Windows.Forms.Label lblRealisateurUpdate;
        private System.Windows.Forms.TableLayoutPanel tlpSecondaireRolesCompletsUpdate;
        private System.Windows.Forms.Label lblRolesCompletsUpdate;
        private System.Windows.Forms.DataGridView dgvRolesCompletsUpdate;
        private System.Windows.Forms.TableLayoutPanel tlpPrimaireSelect;
        private System.Windows.Forms.TableLayoutPanel tlpSecondaireResumeSelect;
        private System.Windows.Forms.TextBox txtResumeSelect;
        private System.Windows.Forms.Label lblResumeSelect;
        private System.Windows.Forms.TableLayoutPanel tlpSecondaireTitreEtIdSelect;
        private System.Windows.Forms.Label lblTitreSelect;
        private System.Windows.Forms.Label lblIdSelect;
        private System.Windows.Forms.ComboBox cbxTitreSelect;
        private System.Windows.Forms.TextBox txtIdSelect;
        private System.Windows.Forms.TableLayoutPanel tlpSecondaireDateEtDureeSelect;
        private System.Windows.Forms.Label lblDateSelect;
        private System.Windows.Forms.Label lblDureeSelect;
        private System.Windows.Forms.DateTimePicker datDateSelect;
        private System.Windows.Forms.TextBox txtDureeSelect;
        private System.Windows.Forms.Label lblDureeMinutesSelect;
        private System.Windows.Forms.TableLayoutPanel tlpSecondaireGenreSelect;
        private System.Windows.Forms.TextBox txtGenreSelect;
        private System.Windows.Forms.Label lblGenreSelect;
        private System.Windows.Forms.TableLayoutPanel tlpSecondaireRealisateurSelect;
        private System.Windows.Forms.TextBox txtRealisateurSelect;
        private System.Windows.Forms.Label lblRealisateurSelect;
        private System.Windows.Forms.TableLayoutPanel tlpRolesCompletsSelect;
        private System.Windows.Forms.Label lblRolesCompletsSelect;
        private System.Windows.Forms.DataGridView dgvRolesCompletsSelect;
        private System.Windows.Forms.TableLayoutPanel tlpPrimaireInsert;
        private System.Windows.Forms.TableLayoutPanel tlpSecondaireResumeInsert;
        private System.Windows.Forms.TextBox txtResumeInsert;
        private System.Windows.Forms.Label lblResumeInsert;
        private System.Windows.Forms.TableLayoutPanel tlpSecondaireTitreEtIdInsert;
        private System.Windows.Forms.Label lblTitreInsert;
        private System.Windows.Forms.Label lblIdInsert;
        private System.Windows.Forms.TextBox txtTitreInsert;
        private System.Windows.Forms.TextBox txtIdInsert;
        private System.Windows.Forms.TableLayoutPanel tlpSecondaireDateEtDureeInsert;
        private System.Windows.Forms.Label lblDateInsert;
        private System.Windows.Forms.Label lblDureeInsert;
        private System.Windows.Forms.DateTimePicker datDateInsert;
        private System.Windows.Forms.TextBox txtDureeInsert;
        private System.Windows.Forms.Label lblDureeMinutesInsert;
        private System.Windows.Forms.TableLayoutPanel tlpSecondaireGenreInsert;
        private System.Windows.Forms.ComboBox cbxGenreInsert;
        private System.Windows.Forms.Label lblGenreInsert;
        private System.Windows.Forms.TableLayoutPanel tlpSecondaireRealisateurInsert;
        private System.Windows.Forms.ComboBox cbxRealisateurInsert;
        private System.Windows.Forms.Label lblRealisateurInsert;
        private System.Windows.Forms.TableLayoutPanel tlpSecondaireRolesCompletsInsert;
        private System.Windows.Forms.Label lblRolesCompletsInsert;
        private System.Windows.Forms.DataGridView dgvRolesCompletsInsert;
        private System.Windows.Forms.TableLayoutPanel tlpPrimaireDelete;
        private System.Windows.Forms.TableLayoutPanel tlpSecondaireResumeDelete;
        private System.Windows.Forms.TextBox txtResumeDelete;
        private System.Windows.Forms.Label lblResumeDelete;
        private System.Windows.Forms.TableLayoutPanel tlpSecondaireTitreEtIdDelete;
        private System.Windows.Forms.Label lblTitreDelete;
        private System.Windows.Forms.Label lblIdDelete;
        private System.Windows.Forms.TextBox txtTitreDelete;
        private System.Windows.Forms.ComboBox cbxIdDelete;
        private System.Windows.Forms.TableLayoutPanel tlpSecondaireDateEtDureeDelete;
        private System.Windows.Forms.Label lblDateDelete;
        private System.Windows.Forms.Label lblDureeDelete;
        private System.Windows.Forms.DateTimePicker datDateDelete;
        private System.Windows.Forms.TextBox txtDureeDelete;
        private System.Windows.Forms.Label lblDureeMinutesDelete;
        private System.Windows.Forms.TableLayoutPanel tlpSecondaireGenreDelete;
        private System.Windows.Forms.TableLayoutPanel tlpSecondaireRealisateurDelete;
        private System.Windows.Forms.TableLayoutPanel tlpSecondaireRolesCompletsDelete;
        private System.Windows.Forms.Label lblRolesCompletsDelete;
        private System.Windows.Forms.DataGridView dgvRolesCompletsDelete;
        private System.Windows.Forms.TextBox txtGenreDelete;
        private System.Windows.Forms.Label lblGenreDelete;
        private System.Windows.Forms.TextBox txtRealisateurDelete;
        private System.Windows.Forms.Label lblRealisateurDelete;
        private System.Windows.Forms.TableLayoutPanel tlpSecondaireActionDelete;
        private System.Windows.Forms.Button btnSupprimerFilmComplet;
        private System.Windows.Forms.TableLayoutPanel tlpSecondaireActionsInsert;
        private System.Windows.Forms.Button btnInsererFilmComplet;
        private System.Windows.Forms.Button btnReinitialiserInsert;
        private System.Windows.Forms.TableLayoutPanel tlpSecondaireActionsUpdate;
        private System.Windows.Forms.Button btnModifierFilmComplet;
        private System.Windows.Forms.Button btnReinitialiserUpdate;
        private System.Windows.Forms.PictureBox picAfficheSelect;
    }
}