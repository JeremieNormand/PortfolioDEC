﻿namespace LabSem6h2020
{
    partial class frmExerMethode
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnTestMethodes = new System.Windows.Forms.Button();
            this.btnTest = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.txtR = new System.Windows.Forms.TextBox();
            this.txtX1 = new System.Windows.Forms.TextBox();
            this.txtX2 = new System.Windows.Forms.TextBox();
            this.txtY1 = new System.Windows.Forms.TextBox();
            this.txtY2 = new System.Windows.Forms.TextBox();
            this.btnTest5x5 = new System.Windows.Forms.Button();
            this.btnInit5x5 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtLargeur = new System.Windows.Forms.TextBox();
            this.txtLongueur = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtAn = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(55, 30);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(428, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "PREMIÈRE PARTIE -----------------------------------------------------------------" +
    "-------<";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(55, 226);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(427, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "DEUXIÈME PARTIE -----------------------------------------------------------------" +
    "-------<";
            // 
            // btnTestMethodes
            // 
            this.btnTestMethodes.Location = new System.Drawing.Point(59, 89);
            this.btnTestMethodes.Margin = new System.Windows.Forms.Padding(4);
            this.btnTestMethodes.Name = "btnTestMethodes";
            this.btnTestMethodes.Size = new System.Drawing.Size(111, 28);
            this.btnTestMethodes.TabIndex = 2;
            this.btnTestMethodes.Text = "TestMéthodes";
            this.btnTestMethodes.UseVisualStyleBackColor = true;
            this.btnTestMethodes.Click += new System.EventHandler(this.btnTestMethodes_Click);
            // 
            // btnTest
            // 
            this.btnTest.Location = new System.Drawing.Point(58, 271);
            this.btnTest.Margin = new System.Windows.Forms.Padding(4);
            this.btnTest.Name = "btnTest";
            this.btnTest.Size = new System.Drawing.Size(112, 28);
            this.btnTest.TabIndex = 3;
            this.btnTest.Text = "TEST 25";
            this.btnTest.UseVisualStyleBackColor = true;
            this.btnTest.Click += new System.EventHandler(this.btnTest25_Click);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(190, 271);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(111, 28);
            this.btnReset.TabIndex = 4;
            this.btnReset.Text = "RESET";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // txtR
            // 
            this.txtR.Location = new System.Drawing.Point(109, 146);
            this.txtR.Name = "txtR";
            this.txtR.Size = new System.Drawing.Size(61, 22);
            this.txtR.TabIndex = 5;
            // 
            // txtX1
            // 
            this.txtX1.Location = new System.Drawing.Point(208, 89);
            this.txtX1.Name = "txtX1";
            this.txtX1.Size = new System.Drawing.Size(54, 22);
            this.txtX1.TabIndex = 6;
            // 
            // txtX2
            // 
            this.txtX2.Location = new System.Drawing.Point(282, 89);
            this.txtX2.Name = "txtX2";
            this.txtX2.Size = new System.Drawing.Size(54, 22);
            this.txtX2.TabIndex = 7;
            // 
            // txtY1
            // 
            this.txtY1.Location = new System.Drawing.Point(354, 89);
            this.txtY1.Name = "txtY1";
            this.txtY1.Size = new System.Drawing.Size(54, 22);
            this.txtY1.TabIndex = 8;
            // 
            // txtY2
            // 
            this.txtY2.Location = new System.Drawing.Point(429, 89);
            this.txtY2.Name = "txtY2";
            this.txtY2.Size = new System.Drawing.Size(54, 22);
            this.txtY2.TabIndex = 9;
            // 
            // btnTest5x5
            // 
            this.btnTest5x5.Location = new System.Drawing.Point(331, 319);
            this.btnTest5x5.Margin = new System.Windows.Forms.Padding(4);
            this.btnTest5x5.Name = "btnTest5x5";
            this.btnTest5x5.Size = new System.Drawing.Size(112, 28);
            this.btnTest5x5.TabIndex = 10;
            this.btnTest5x5.Text = "TEST 5x5";
            this.btnTest5x5.UseVisualStyleBackColor = true;
            this.btnTest5x5.Click += new System.EventHandler(this.btnTest5x5_Click);
            // 
            // btnInit5x5
            // 
            this.btnInit5x5.Location = new System.Drawing.Point(189, 319);
            this.btnInit5x5.Margin = new System.Windows.Forms.Padding(4);
            this.btnInit5x5.Name = "btnInit5x5";
            this.btnInit5x5.Size = new System.Drawing.Size(112, 28);
            this.btnInit5x5.TabIndex = 11;
            this.btnInit5x5.Text = "INIT 5x5";
            this.btnInit5x5.UseVisualStyleBackColor = true;
            this.btnInit5x5.Click += new System.EventHandler(this.btnInit5x5_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(57, 149);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(12, 16);
            this.label3.TabIndex = 12;
            this.label3.Text = "r";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(211, 73);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(23, 16);
            this.label4.TabIndex = 13;
            this.label4.Text = "X1";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(281, 73);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(23, 16);
            this.label5.TabIndex = 14;
            this.label5.Text = "X2";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(351, 73);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(24, 16);
            this.label6.TabIndex = 15;
            this.label6.Text = "Y1";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(426, 73);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(24, 16);
            this.label7.TabIndex = 16;
            this.label7.Text = "Y2";
            // 
            // txtLargeur
            // 
            this.txtLargeur.Location = new System.Drawing.Point(429, 146);
            this.txtLargeur.Name = "txtLargeur";
            this.txtLargeur.Size = new System.Drawing.Size(54, 22);
            this.txtLargeur.TabIndex = 18;
            // 
            // txtLongueur
            // 
            this.txtLongueur.Location = new System.Drawing.Point(282, 146);
            this.txtLongueur.Name = "txtLongueur";
            this.txtLongueur.Size = new System.Drawing.Size(54, 22);
            this.txtLongueur.TabIndex = 17;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(358, 149);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(50, 16);
            this.label8.TabIndex = 20;
            this.label8.Text = "largeur";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(205, 149);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(60, 16);
            this.label9.TabIndex = 19;
            this.label9.Text = "longueur";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(57, 189);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(46, 16);
            this.label10.TabIndex = 22;
            this.label10.Text = "année";
            // 
            // txtAn
            // 
            this.txtAn.Location = new System.Drawing.Point(109, 186);
            this.txtAn.Name = "txtAn";
            this.txtAn.Size = new System.Drawing.Size(61, 22);
            this.txtAn.TabIndex = 21;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(591, 381);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txtAn);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtLargeur);
            this.Controls.Add(this.txtLongueur);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnInit5x5);
            this.Controls.Add(this.btnTest5x5);
            this.Controls.Add(this.txtY2);
            this.Controls.Add(this.txtY1);
            this.Controls.Add(this.txtX2);
            this.Controls.Add(this.txtX1);
            this.Controls.Add(this.txtR);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnTest);
            this.Controls.Add(this.btnTestMethodes);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnTestMethodes;
        private System.Windows.Forms.Button btnTest;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.TextBox txtR;
        private System.Windows.Forms.TextBox txtX1;
        private System.Windows.Forms.TextBox txtX2;
        private System.Windows.Forms.TextBox txtY1;
        private System.Windows.Forms.TextBox txtY2;
        private System.Windows.Forms.Button btnTest5x5;
        private System.Windows.Forms.Button btnInit5x5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtLargeur;
        private System.Windows.Forms.TextBox txtLongueur;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtAn;
    }
}

