﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab9Classe.Classes
{
    class AutoPublic
    {
        public Color m_couleurAuto;
        public Color m_couleurRoue;

        public AutoPublic()
        {
            m_couleurAuto = Color.Coral;
            m_couleurRoue = Color.Chocolate; 
        }
    }
}
