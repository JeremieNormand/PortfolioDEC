﻿using System.Drawing;

namespace Lab9Classe.Classes
{
    class SoleilPublic
    {
        public int m_rayon;
        public Color m_couleur;

        public SoleilPublic()
        {
            m_rayon = 25;
            m_couleur = Color.Yellow;
        }
    }
}
