﻿
namespace TypesEtCalculsElementaires
{
    partial class TypesEtCalculs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tblEntreesBtnsEtSorties = new System.Windows.Forms.TableLayoutPanel();
            this.lblEntreeA = new System.Windows.Forms.Label();
            this.lblEntreeB = new System.Windows.Forms.Label();
            this.txtEntreeA = new System.Windows.Forms.TextBox();
            this.txtEntreeB = new System.Windows.Forms.TextBox();
            this.btnEvaluerExpression1 = new System.Windows.Forms.Button();
            this.btnEvaluerExpression2 = new System.Windows.Forms.Button();
            this.btnEvaluerExpression3 = new System.Windows.Forms.Button();
            this.btnEvaluerExpression4 = new System.Windows.Forms.Button();
            this.btnEvaluerExpression5 = new System.Windows.Forms.Button();
            this.btnEvaluerExpression6 = new System.Windows.Forms.Button();
            this.btnEvaluerExpression7 = new System.Windows.Forms.Button();
            this.lblSortieC = new System.Windows.Forms.Label();
            this.txtSortieC = new System.Windows.Forms.TextBox();
            this.lblCommentaire = new System.Windows.Forms.Label();
            this.tblEntreesBtnsEtSorties.SuspendLayout();
            this.SuspendLayout();
            // 
            // tblEntreesBtnsEtSorties
            // 
            this.tblEntreesBtnsEtSorties.ColumnCount = 5;
            this.tblEntreesBtnsEtSorties.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tblEntreesBtnsEtSorties.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tblEntreesBtnsEtSorties.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tblEntreesBtnsEtSorties.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tblEntreesBtnsEtSorties.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tblEntreesBtnsEtSorties.Controls.Add(this.lblEntreeA, 1, 1);
            this.tblEntreesBtnsEtSorties.Controls.Add(this.lblEntreeB, 3, 1);
            this.tblEntreesBtnsEtSorties.Controls.Add(this.txtEntreeA, 1, 2);
            this.tblEntreesBtnsEtSorties.Controls.Add(this.txtEntreeB, 3, 2);
            this.tblEntreesBtnsEtSorties.Controls.Add(this.btnEvaluerExpression1, 1, 4);
            this.tblEntreesBtnsEtSorties.Controls.Add(this.btnEvaluerExpression2, 1, 5);
            this.tblEntreesBtnsEtSorties.Controls.Add(this.btnEvaluerExpression3, 1, 6);
            this.tblEntreesBtnsEtSorties.Controls.Add(this.btnEvaluerExpression4, 1, 7);
            this.tblEntreesBtnsEtSorties.Controls.Add(this.btnEvaluerExpression5, 1, 8);
            this.tblEntreesBtnsEtSorties.Controls.Add(this.btnEvaluerExpression6, 1, 9);
            this.tblEntreesBtnsEtSorties.Controls.Add(this.btnEvaluerExpression7, 1, 10);
            this.tblEntreesBtnsEtSorties.Controls.Add(this.lblSortieC, 1, 12);
            this.tblEntreesBtnsEtSorties.Controls.Add(this.txtSortieC, 2, 12);
            this.tblEntreesBtnsEtSorties.Controls.Add(this.lblCommentaire, 3, 12);
            this.tblEntreesBtnsEtSorties.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblEntreesBtnsEtSorties.Location = new System.Drawing.Point(0, 0);
            this.tblEntreesBtnsEtSorties.Name = "tblEntreesBtnsEtSorties";
            this.tblEntreesBtnsEtSorties.RowCount = 14;
            this.tblEntreesBtnsEtSorties.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.838866F));
            this.tblEntreesBtnsEtSorties.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.064775F));
            this.tblEntreesBtnsEtSorties.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.064775F));
            this.tblEntreesBtnsEtSorties.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.838866F));
            this.tblEntreesBtnsEtSorties.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.064775F));
            this.tblEntreesBtnsEtSorties.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.064775F));
            this.tblEntreesBtnsEtSorties.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.064775F));
            this.tblEntreesBtnsEtSorties.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.064775F));
            this.tblEntreesBtnsEtSorties.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.064775F));
            this.tblEntreesBtnsEtSorties.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.064775F));
            this.tblEntreesBtnsEtSorties.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.064775F));
            this.tblEntreesBtnsEtSorties.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.838866F));
            this.tblEntreesBtnsEtSorties.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.06155F));
            this.tblEntreesBtnsEtSorties.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.838866F));
            this.tblEntreesBtnsEtSorties.Size = new System.Drawing.Size(875, 614);
            this.tblEntreesBtnsEtSorties.TabIndex = 0;
            // 
            // lblEntreeA
            // 
            this.lblEntreeA.AutoSize = true;
            this.lblEntreeA.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblEntreeA.Location = new System.Drawing.Point(112, 61);
            this.lblEntreeA.Name = "lblEntreeA";
            this.lblEntreeA.Size = new System.Drawing.Size(212, 17);
            this.lblEntreeA.TabIndex = 0;
            this.lblEntreeA.Text = "A";
            this.lblEntreeA.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblEntreeB
            // 
            this.lblEntreeB.AutoSize = true;
            this.lblEntreeB.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblEntreeB.Location = new System.Drawing.Point(548, 61);
            this.lblEntreeB.Name = "lblEntreeB";
            this.lblEntreeB.Size = new System.Drawing.Size(212, 17);
            this.lblEntreeB.TabIndex = 1;
            this.lblEntreeB.Text = "B";
            this.lblEntreeB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtEntreeA
            // 
            this.txtEntreeA.Dock = System.Windows.Forms.DockStyle.Top;
            this.txtEntreeA.Location = new System.Drawing.Point(112, 81);
            this.txtEntreeA.Name = "txtEntreeA";
            this.txtEntreeA.Size = new System.Drawing.Size(212, 22);
            this.txtEntreeA.TabIndex = 2;
            this.txtEntreeA.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtEntreeB
            // 
            this.txtEntreeB.Dock = System.Windows.Forms.DockStyle.Top;
            this.txtEntreeB.Location = new System.Drawing.Point(548, 81);
            this.txtEntreeB.Name = "txtEntreeB";
            this.txtEntreeB.Size = new System.Drawing.Size(212, 22);
            this.txtEntreeB.TabIndex = 3;
            this.txtEntreeB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnEvaluerExpression1
            // 
            this.tblEntreesBtnsEtSorties.SetColumnSpan(this.btnEvaluerExpression1, 3);
            this.btnEvaluerExpression1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnEvaluerExpression1.Location = new System.Drawing.Point(112, 159);
            this.btnEvaluerExpression1.Name = "btnEvaluerExpression1";
            this.btnEvaluerExpression1.Size = new System.Drawing.Size(648, 43);
            this.btnEvaluerExpression1.TabIndex = 4;
            this.btnEvaluerExpression1.Text = "(A + B) / (A - B)";
            this.btnEvaluerExpression1.UseVisualStyleBackColor = true;
            this.btnEvaluerExpression1.Click += new System.EventHandler(this.btnEvaluerExpression1_Click);
            // 
            // btnEvaluerExpression2
            // 
            this.tblEntreesBtnsEtSorties.SetColumnSpan(this.btnEvaluerExpression2, 3);
            this.btnEvaluerExpression2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnEvaluerExpression2.Location = new System.Drawing.Point(112, 208);
            this.btnEvaluerExpression2.Name = "btnEvaluerExpression2";
            this.btnEvaluerExpression2.Size = new System.Drawing.Size(648, 43);
            this.btnEvaluerExpression2.TabIndex = 5;
            this.btnEvaluerExpression2.Text = "(A^2 + 2*B^3) / (2*(A + B))";
            this.btnEvaluerExpression2.UseVisualStyleBackColor = true;
            this.btnEvaluerExpression2.Click += new System.EventHandler(this.btnEvaluerExpression2_Click);
            // 
            // btnEvaluerExpression3
            // 
            this.tblEntreesBtnsEtSorties.SetColumnSpan(this.btnEvaluerExpression3, 3);
            this.btnEvaluerExpression3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnEvaluerExpression3.Location = new System.Drawing.Point(112, 257);
            this.btnEvaluerExpression3.Name = "btnEvaluerExpression3";
            this.btnEvaluerExpression3.Size = new System.Drawing.Size(648, 43);
            this.btnEvaluerExpression3.TabIndex = 6;
            this.btnEvaluerExpression3.Text = "2*A*B + (A + B) / (2*(A - B)) + A^2 * B^3 / (A + B)^23";
            this.btnEvaluerExpression3.UseVisualStyleBackColor = true;
            this.btnEvaluerExpression3.Click += new System.EventHandler(this.btnEvaluerExpression3_Click);
            // 
            // btnEvaluerExpression4
            // 
            this.tblEntreesBtnsEtSorties.SetColumnSpan(this.btnEvaluerExpression4, 3);
            this.btnEvaluerExpression4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnEvaluerExpression4.Location = new System.Drawing.Point(112, 306);
            this.btnEvaluerExpression4.Name = "btnEvaluerExpression4";
            this.btnEvaluerExpression4.Size = new System.Drawing.Size(648, 43);
            this.btnEvaluerExpression4.TabIndex = 7;
            this.btnEvaluerExpression4.Text = "((A + B) / (A - B))^(1/2)";
            this.btnEvaluerExpression4.UseVisualStyleBackColor = true;
            this.btnEvaluerExpression4.Click += new System.EventHandler(this.btnEvaluerExpression4_Click);
            // 
            // btnEvaluerExpression5
            // 
            this.tblEntreesBtnsEtSorties.SetColumnSpan(this.btnEvaluerExpression5, 3);
            this.btnEvaluerExpression5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnEvaluerExpression5.Location = new System.Drawing.Point(112, 355);
            this.btnEvaluerExpression5.Name = "btnEvaluerExpression5";
            this.btnEvaluerExpression5.Size = new System.Drawing.Size(648, 43);
            this.btnEvaluerExpression5.TabIndex = 8;
            this.btnEvaluerExpression5.Text = "((A^2 - B^2) / (A - B)^2)^(1/3)";
            this.btnEvaluerExpression5.UseVisualStyleBackColor = true;
            this.btnEvaluerExpression5.Click += new System.EventHandler(this.btnEvaluerExpression5_Click);
            // 
            // btnEvaluerExpression6
            // 
            this.tblEntreesBtnsEtSorties.SetColumnSpan(this.btnEvaluerExpression6, 3);
            this.btnEvaluerExpression6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnEvaluerExpression6.Location = new System.Drawing.Point(112, 404);
            this.btnEvaluerExpression6.Name = "btnEvaluerExpression6";
            this.btnEvaluerExpression6.Size = new System.Drawing.Size(648, 43);
            this.btnEvaluerExpression6.TabIndex = 9;
            this.btnEvaluerExpression6.Text = "(A / 15 / 2 + B / 25 / 2) * 100";
            this.btnEvaluerExpression6.UseVisualStyleBackColor = true;
            this.btnEvaluerExpression6.Click += new System.EventHandler(this.btnEvaluerExpression6_Click);
            // 
            // btnEvaluerExpression7
            // 
            this.tblEntreesBtnsEtSorties.SetColumnSpan(this.btnEvaluerExpression7, 3);
            this.btnEvaluerExpression7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnEvaluerExpression7.Location = new System.Drawing.Point(112, 453);
            this.btnEvaluerExpression7.Name = "btnEvaluerExpression7";
            this.btnEvaluerExpression7.Size = new System.Drawing.Size(648, 43);
            this.btnEvaluerExpression7.TabIndex = 10;
            this.btnEvaluerExpression7.Text = "A / (A + B) * 100";
            this.btnEvaluerExpression7.UseVisualStyleBackColor = true;
            this.btnEvaluerExpression7.Click += new System.EventHandler(this.btnEvaluerExpression7_Click);
            // 
            // lblSortieC
            // 
            this.lblSortieC.AutoSize = true;
            this.lblSortieC.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblSortieC.Location = new System.Drawing.Point(112, 528);
            this.lblSortieC.Name = "lblSortieC";
            this.lblSortieC.Size = new System.Drawing.Size(212, 17);
            this.lblSortieC.TabIndex = 11;
            this.lblSortieC.Text = "C";
            this.lblSortieC.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtSortieC
            // 
            this.txtSortieC.Dock = System.Windows.Forms.DockStyle.Top;
            this.txtSortieC.Location = new System.Drawing.Point(330, 531);
            this.txtSortieC.Name = "txtSortieC";
            this.txtSortieC.Size = new System.Drawing.Size(212, 22);
            this.txtSortieC.TabIndex = 12;
            this.txtSortieC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblCommentaire
            // 
            this.lblCommentaire.AutoSize = true;
            this.lblCommentaire.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblCommentaire.Location = new System.Drawing.Point(548, 528);
            this.lblCommentaire.Name = "lblCommentaire";
            this.lblCommentaire.Size = new System.Drawing.Size(212, 17);
            this.lblCommentaire.TabIndex = 13;
            this.lblCommentaire.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TypesEtCalculs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(875, 614);
            this.Controls.Add(this.tblEntreesBtnsEtSorties);
            this.Name = "TypesEtCalculs";
            this.Text = "Types et Calculs Élémentaire - Jérémie Normand";
            this.tblEntreesBtnsEtSorties.ResumeLayout(false);
            this.tblEntreesBtnsEtSorties.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tblEntreesBtnsEtSorties;
        private System.Windows.Forms.Label lblEntreeA;
        private System.Windows.Forms.Label lblEntreeB;
        private System.Windows.Forms.TextBox txtEntreeA;
        private System.Windows.Forms.TextBox txtEntreeB;
        private System.Windows.Forms.Button btnEvaluerExpression1;
        private System.Windows.Forms.Button btnEvaluerExpression2;
        private System.Windows.Forms.Button btnEvaluerExpression3;
        private System.Windows.Forms.Button btnEvaluerExpression4;
        private System.Windows.Forms.Button btnEvaluerExpression5;
        private System.Windows.Forms.Button btnEvaluerExpression6;
        private System.Windows.Forms.Button btnEvaluerExpression7;
        private System.Windows.Forms.Label lblSortieC;
        private System.Windows.Forms.TextBox txtSortieC;
        private System.Windows.Forms.Label lblCommentaire;
    }
}

