﻿namespace TP7
{
    partial class frmTP7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tblPrincipal = new System.Windows.Forms.TableLayoutPanel();
            this.lblCodeCesar = new System.Windows.Forms.Label();
            this.txtCodeCesar = new System.Windows.Forms.TextBox();
            this.lblAlphabetTitle = new System.Windows.Forms.Label();
            this.btnAfficherAlphabetEncode = new System.Windows.Forms.Button();
            this.lblAlphabet = new System.Windows.Forms.Label();
            this.lblAlphabetEncodeTitle = new System.Windows.Forms.Label();
            this.lblAlphabetEncode = new System.Windows.Forms.Label();
            this.lblPhraseAEncoder = new System.Windows.Forms.Label();
            this.txtPhraseAEncoder = new System.Windows.Forms.TextBox();
            this.btnAfficherPhraseEncodee = new System.Windows.Forms.Button();
            this.lblPhraseEncodee = new System.Windows.Forms.Label();
            this.txtPhraseEncodee = new System.Windows.Forms.TextBox();
            this.lblPhraseCodee = new System.Windows.Forms.Label();
            this.txtPhraseCodee = new System.Windows.Forms.TextBox();
            this.btnAfficherPhraseDecodee = new System.Windows.Forms.Button();
            this.lblPhraseDecodee = new System.Windows.Forms.Label();
            this.txtPhraseDecodee = new System.Windows.Forms.TextBox();
            this.tblPrincipal.SuspendLayout();
            this.SuspendLayout();
            // 
            // tblPrincipal
            // 
            this.tblPrincipal.ColumnCount = 5;
            this.tblPrincipal.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.038235F));
            this.tblPrincipal.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 29.97451F));
            this.tblPrincipal.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 29.97451F));
            this.tblPrincipal.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 29.97451F));
            this.tblPrincipal.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.038235F));
            this.tblPrincipal.Controls.Add(this.lblCodeCesar, 1, 1);
            this.tblPrincipal.Controls.Add(this.txtCodeCesar, 2, 1);
            this.tblPrincipal.Controls.Add(this.lblAlphabetTitle, 1, 3);
            this.tblPrincipal.Controls.Add(this.btnAfficherAlphabetEncode, 1, 5);
            this.tblPrincipal.Controls.Add(this.lblAlphabet, 1, 4);
            this.tblPrincipal.Controls.Add(this.lblAlphabetEncodeTitle, 1, 6);
            this.tblPrincipal.Controls.Add(this.lblAlphabetEncode, 1, 7);
            this.tblPrincipal.Controls.Add(this.lblPhraseAEncoder, 1, 9);
            this.tblPrincipal.Controls.Add(this.txtPhraseAEncoder, 2, 9);
            this.tblPrincipal.Controls.Add(this.btnAfficherPhraseEncodee, 1, 10);
            this.tblPrincipal.Controls.Add(this.lblPhraseEncodee, 1, 11);
            this.tblPrincipal.Controls.Add(this.txtPhraseEncodee, 2, 11);
            this.tblPrincipal.Controls.Add(this.lblPhraseCodee, 1, 13);
            this.tblPrincipal.Controls.Add(this.txtPhraseCodee, 2, 13);
            this.tblPrincipal.Controls.Add(this.btnAfficherPhraseDecodee, 1, 14);
            this.tblPrincipal.Controls.Add(this.lblPhraseDecodee, 1, 15);
            this.tblPrincipal.Controls.Add(this.txtPhraseDecodee, 2, 15);
            this.tblPrincipal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblPrincipal.Font = new System.Drawing.Font("Monotype Corsiva", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tblPrincipal.Location = new System.Drawing.Point(0, 0);
            this.tblPrincipal.Name = "tblPrincipal";
            this.tblPrincipal.RowCount = 17;
            this.tblPrincipal.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.882351F));
            this.tblPrincipal.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.882352F));
            this.tblPrincipal.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.882352F));
            this.tblPrincipal.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.882352F));
            this.tblPrincipal.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.882352F));
            this.tblPrincipal.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.882352F));
            this.tblPrincipal.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.882352F));
            this.tblPrincipal.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.882352F));
            this.tblPrincipal.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.882352F));
            this.tblPrincipal.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.882352F));
            this.tblPrincipal.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.882352F));
            this.tblPrincipal.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.882352F));
            this.tblPrincipal.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.882352F));
            this.tblPrincipal.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.882352F));
            this.tblPrincipal.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.882352F));
            this.tblPrincipal.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.882352F));
            this.tblPrincipal.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.882352F));
            this.tblPrincipal.Size = new System.Drawing.Size(732, 803);
            this.tblPrincipal.TabIndex = 0;
            // 
            // lblCodeCesar
            // 
            this.lblCodeCesar.AutoSize = true;
            this.lblCodeCesar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblCodeCesar.Font = new System.Drawing.Font("Monotype Corsiva", 13.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCodeCesar.Location = new System.Drawing.Point(39, 47);
            this.lblCodeCesar.Name = "lblCodeCesar";
            this.lblCodeCesar.Size = new System.Drawing.Size(213, 47);
            this.lblCodeCesar.TabIndex = 0;
            this.lblCodeCesar.Text = "Code César";
            // 
            // txtCodeCesar
            // 
            this.txtCodeCesar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtCodeCesar.Font = new System.Drawing.Font("Felix Titling", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodeCesar.Location = new System.Drawing.Point(258, 50);
            this.txtCodeCesar.Name = "txtCodeCesar";
            this.txtCodeCesar.Size = new System.Drawing.Size(213, 31);
            this.txtCodeCesar.TabIndex = 1;
            this.txtCodeCesar.Text = "0";
            this.txtCodeCesar.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblAlphabetTitle
            // 
            this.lblAlphabetTitle.AutoSize = true;
            this.tblPrincipal.SetColumnSpan(this.lblAlphabetTitle, 3);
            this.lblAlphabetTitle.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblAlphabetTitle.Font = new System.Drawing.Font("Monotype Corsiva", 13.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlphabetTitle.Location = new System.Drawing.Point(39, 141);
            this.lblAlphabetTitle.Name = "lblAlphabetTitle";
            this.lblAlphabetTitle.Size = new System.Drawing.Size(651, 47);
            this.lblAlphabetTitle.TabIndex = 2;
            this.lblAlphabetTitle.Text = "Alphabet";
            this.lblAlphabetTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnAfficherAlphabetEncode
            // 
            this.btnAfficherAlphabetEncode.BackColor = System.Drawing.Color.Peru;
            this.btnAfficherAlphabetEncode.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tblPrincipal.SetColumnSpan(this.btnAfficherAlphabetEncode, 3);
            this.btnAfficherAlphabetEncode.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAfficherAlphabetEncode.Font = new System.Drawing.Font("Monotype Corsiva", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAfficherAlphabetEncode.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnAfficherAlphabetEncode.Location = new System.Drawing.Point(39, 238);
            this.btnAfficherAlphabetEncode.Name = "btnAfficherAlphabetEncode";
            this.btnAfficherAlphabetEncode.Size = new System.Drawing.Size(651, 41);
            this.btnAfficherAlphabetEncode.TabIndex = 3;
            this.btnAfficherAlphabetEncode.Text = "Encoder alphabet";
            this.btnAfficherAlphabetEncode.UseVisualStyleBackColor = false;
            this.btnAfficherAlphabetEncode.Click += new System.EventHandler(this.btnAfficherAlphabetEncode_Click);
            // 
            // lblAlphabet
            // 
            this.lblAlphabet.AutoSize = true;
            this.tblPrincipal.SetColumnSpan(this.lblAlphabet, 3);
            this.lblAlphabet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblAlphabet.Font = new System.Drawing.Font("Felix Titling", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlphabet.Location = new System.Drawing.Point(39, 188);
            this.lblAlphabet.Name = "lblAlphabet";
            this.lblAlphabet.Size = new System.Drawing.Size(651, 47);
            this.lblAlphabet.TabIndex = 4;
            this.lblAlphabet.Text = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            this.lblAlphabet.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblAlphabetEncodeTitle
            // 
            this.lblAlphabetEncodeTitle.AutoSize = true;
            this.tblPrincipal.SetColumnSpan(this.lblAlphabetEncodeTitle, 3);
            this.lblAlphabetEncodeTitle.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblAlphabetEncodeTitle.Font = new System.Drawing.Font("Monotype Corsiva", 13.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlphabetEncodeTitle.Location = new System.Drawing.Point(39, 282);
            this.lblAlphabetEncodeTitle.Name = "lblAlphabetEncodeTitle";
            this.lblAlphabetEncodeTitle.Size = new System.Drawing.Size(651, 47);
            this.lblAlphabetEncodeTitle.TabIndex = 5;
            this.lblAlphabetEncodeTitle.Text = "Alphabet encodé";
            this.lblAlphabetEncodeTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblAlphabetEncode
            // 
            this.lblAlphabetEncode.AutoSize = true;
            this.tblPrincipal.SetColumnSpan(this.lblAlphabetEncode, 3);
            this.lblAlphabetEncode.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblAlphabetEncode.Font = new System.Drawing.Font("Felix Titling", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlphabetEncode.Location = new System.Drawing.Point(39, 329);
            this.lblAlphabetEncode.Name = "lblAlphabetEncode";
            this.lblAlphabetEncode.Size = new System.Drawing.Size(651, 47);
            this.lblAlphabetEncode.TabIndex = 6;
            this.lblAlphabetEncode.Text = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            this.lblAlphabetEncode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPhraseAEncoder
            // 
            this.lblPhraseAEncoder.AutoSize = true;
            this.lblPhraseAEncoder.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPhraseAEncoder.Font = new System.Drawing.Font("Monotype Corsiva", 13.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhraseAEncoder.Location = new System.Drawing.Point(39, 423);
            this.lblPhraseAEncoder.Name = "lblPhraseAEncoder";
            this.lblPhraseAEncoder.Size = new System.Drawing.Size(213, 47);
            this.lblPhraseAEncoder.TabIndex = 7;
            this.lblPhraseAEncoder.Text = "Phrase à encoder";
            // 
            // txtPhraseAEncoder
            // 
            this.tblPrincipal.SetColumnSpan(this.txtPhraseAEncoder, 2);
            this.txtPhraseAEncoder.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtPhraseAEncoder.Font = new System.Drawing.Font("Felix Titling", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPhraseAEncoder.Location = new System.Drawing.Point(258, 426);
            this.txtPhraseAEncoder.Name = "txtPhraseAEncoder";
            this.txtPhraseAEncoder.Size = new System.Drawing.Size(432, 31);
            this.txtPhraseAEncoder.TabIndex = 8;
            this.txtPhraseAEncoder.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnAfficherPhraseEncodee
            // 
            this.btnAfficherPhraseEncodee.BackColor = System.Drawing.Color.Peru;
            this.btnAfficherPhraseEncodee.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tblPrincipal.SetColumnSpan(this.btnAfficherPhraseEncodee, 3);
            this.btnAfficherPhraseEncodee.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAfficherPhraseEncodee.Font = new System.Drawing.Font("Monotype Corsiva", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAfficherPhraseEncodee.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnAfficherPhraseEncodee.Location = new System.Drawing.Point(39, 473);
            this.btnAfficherPhraseEncodee.Name = "btnAfficherPhraseEncodee";
            this.btnAfficherPhraseEncodee.Size = new System.Drawing.Size(651, 41);
            this.btnAfficherPhraseEncodee.TabIndex = 9;
            this.btnAfficherPhraseEncodee.Text = "Encoder";
            this.btnAfficherPhraseEncodee.UseVisualStyleBackColor = false;
            this.btnAfficherPhraseEncodee.Click += new System.EventHandler(this.btnAfficherPhraseEncodee_Click);
            // 
            // lblPhraseEncodee
            // 
            this.lblPhraseEncodee.AutoSize = true;
            this.lblPhraseEncodee.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPhraseEncodee.Font = new System.Drawing.Font("Monotype Corsiva", 13.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhraseEncodee.Location = new System.Drawing.Point(39, 517);
            this.lblPhraseEncodee.Name = "lblPhraseEncodee";
            this.lblPhraseEncodee.Size = new System.Drawing.Size(213, 47);
            this.lblPhraseEncodee.TabIndex = 10;
            this.lblPhraseEncodee.Text = "Phrase encodée";
            // 
            // txtPhraseEncodee
            // 
            this.tblPrincipal.SetColumnSpan(this.txtPhraseEncodee, 2);
            this.txtPhraseEncodee.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtPhraseEncodee.Font = new System.Drawing.Font("Felix Titling", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPhraseEncodee.Location = new System.Drawing.Point(258, 520);
            this.txtPhraseEncodee.Name = "txtPhraseEncodee";
            this.txtPhraseEncodee.ReadOnly = true;
            this.txtPhraseEncodee.Size = new System.Drawing.Size(432, 31);
            this.txtPhraseEncodee.TabIndex = 11;
            this.txtPhraseEncodee.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblPhraseCodee
            // 
            this.lblPhraseCodee.AutoSize = true;
            this.lblPhraseCodee.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPhraseCodee.Font = new System.Drawing.Font("Monotype Corsiva", 13.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhraseCodee.Location = new System.Drawing.Point(39, 611);
            this.lblPhraseCodee.Name = "lblPhraseCodee";
            this.lblPhraseCodee.Size = new System.Drawing.Size(213, 47);
            this.lblPhraseCodee.TabIndex = 12;
            this.lblPhraseCodee.Text = "Phrase codée";
            // 
            // txtPhraseCodee
            // 
            this.tblPrincipal.SetColumnSpan(this.txtPhraseCodee, 2);
            this.txtPhraseCodee.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtPhraseCodee.Font = new System.Drawing.Font("Felix Titling", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPhraseCodee.Location = new System.Drawing.Point(258, 614);
            this.txtPhraseCodee.Name = "txtPhraseCodee";
            this.txtPhraseCodee.Size = new System.Drawing.Size(432, 31);
            this.txtPhraseCodee.TabIndex = 13;
            this.txtPhraseCodee.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnAfficherPhraseDecodee
            // 
            this.btnAfficherPhraseDecodee.BackColor = System.Drawing.Color.Peru;
            this.btnAfficherPhraseDecodee.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tblPrincipal.SetColumnSpan(this.btnAfficherPhraseDecodee, 3);
            this.btnAfficherPhraseDecodee.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAfficherPhraseDecodee.Font = new System.Drawing.Font("Monotype Corsiva", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAfficherPhraseDecodee.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnAfficherPhraseDecodee.Location = new System.Drawing.Point(39, 661);
            this.btnAfficherPhraseDecodee.Name = "btnAfficherPhraseDecodee";
            this.btnAfficherPhraseDecodee.Size = new System.Drawing.Size(651, 41);
            this.btnAfficherPhraseDecodee.TabIndex = 14;
            this.btnAfficherPhraseDecodee.Text = "Décoder";
            this.btnAfficherPhraseDecodee.UseVisualStyleBackColor = false;
            this.btnAfficherPhraseDecodee.Click += new System.EventHandler(this.btnAfficherPhraseDecodee_Click);
            // 
            // lblPhraseDecodee
            // 
            this.lblPhraseDecodee.AutoSize = true;
            this.lblPhraseDecodee.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPhraseDecodee.Font = new System.Drawing.Font("Monotype Corsiva", 13.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhraseDecodee.Location = new System.Drawing.Point(39, 705);
            this.lblPhraseDecodee.Name = "lblPhraseDecodee";
            this.lblPhraseDecodee.Size = new System.Drawing.Size(213, 47);
            this.lblPhraseDecodee.TabIndex = 15;
            this.lblPhraseDecodee.Text = "Phrase décodée";
            // 
            // txtPhraseDecodee
            // 
            this.tblPrincipal.SetColumnSpan(this.txtPhraseDecodee, 2);
            this.txtPhraseDecodee.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtPhraseDecodee.Font = new System.Drawing.Font("Felix Titling", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPhraseDecodee.Location = new System.Drawing.Point(258, 708);
            this.txtPhraseDecodee.Name = "txtPhraseDecodee";
            this.txtPhraseDecodee.ReadOnly = true;
            this.txtPhraseDecodee.Size = new System.Drawing.Size(432, 31);
            this.txtPhraseDecodee.TabIndex = 16;
            this.txtPhraseDecodee.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // frmTP7
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(249)))), ((int)(((byte)(239)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(732, 803);
            this.Controls.Add(this.tblPrincipal);
            this.MaximumSize = new System.Drawing.Size(750, 850);
            this.MinimumSize = new System.Drawing.Size(750, 850);
            this.Name = "frmTP7";
            this.Text = "Code de César";
            this.tblPrincipal.ResumeLayout(false);
            this.tblPrincipal.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tblPrincipal;
        private System.Windows.Forms.Label lblCodeCesar;
        private System.Windows.Forms.TextBox txtCodeCesar;
        private System.Windows.Forms.Label lblAlphabetTitle;
        private System.Windows.Forms.Button btnAfficherAlphabetEncode;
        private System.Windows.Forms.Label lblAlphabet;
        private System.Windows.Forms.Label lblAlphabetEncodeTitle;
        private System.Windows.Forms.Label lblAlphabetEncode;
        private System.Windows.Forms.Label lblPhraseAEncoder;
        private System.Windows.Forms.TextBox txtPhraseAEncoder;
        private System.Windows.Forms.Button btnAfficherPhraseEncodee;
        private System.Windows.Forms.Label lblPhraseEncodee;
        private System.Windows.Forms.TextBox txtPhraseEncodee;
        private System.Windows.Forms.Label lblPhraseCodee;
        private System.Windows.Forms.TextBox txtPhraseCodee;
        private System.Windows.Forms.Button btnAfficherPhraseDecodee;
        private System.Windows.Forms.Label lblPhraseDecodee;
        private System.Windows.Forms.TextBox txtPhraseDecodee;
    }
}

