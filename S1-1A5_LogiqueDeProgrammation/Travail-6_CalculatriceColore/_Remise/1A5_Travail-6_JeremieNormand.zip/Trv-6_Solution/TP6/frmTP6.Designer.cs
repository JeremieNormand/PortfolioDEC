﻿namespace TP6
{
    partial class frmTP6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tblPrincipal = new System.Windows.Forms.TableLayoutPanel();
            this.btnAfficherSommeDeUnACent = new System.Windows.Forms.Button();
            this.lblNombreDeDepartSomme = new System.Windows.Forms.Label();
            this.txtNombreDeDepartSomme = new System.Windows.Forms.TextBox();
            this.lblNombreDeFinSomme = new System.Windows.Forms.Label();
            this.txtNombreDeFinSomme = new System.Windows.Forms.TextBox();
            this.btnAfficherSommeDeXaY = new System.Windows.Forms.Button();
            this.lblBase = new System.Windows.Forms.Label();
            this.txtBase = new System.Windows.Forms.TextBox();
            this.lblPuissance = new System.Windows.Forms.Label();
            this.txtPuissance = new System.Windows.Forms.TextBox();
            this.btnAfficherPuissance = new System.Windows.Forms.Button();
            this.lblNombreX = new System.Windows.Forms.Label();
            this.txtNombreX = new System.Windows.Forms.TextBox();
            this.lblNombreY = new System.Windows.Forms.Label();
            this.txtNombreY = new System.Windows.Forms.TextBox();
            this.btnAfficherDecompte = new System.Windows.Forms.Button();
            this.lstDecompte = new System.Windows.Forms.ListBox();
            this.btnAjouterLigneEtEtoile = new System.Windows.Forms.Button();
            this.lstLignesEtEtoiles = new System.Windows.Forms.ListBox();
            this.lblNombreARepeter = new System.Windows.Forms.Label();
            this.txtNombreARepeter = new System.Windows.Forms.TextBox();
            this.lblNombreDeRepetitions = new System.Windows.Forms.Label();
            this.txtNombreDeRepetitions = new System.Windows.Forms.TextBox();
            this.btnAfficherRepetitionsNombre = new System.Windows.Forms.Button();
            this.txtRepetitionsNombre = new System.Windows.Forms.TextBox();
            this.lblNombreAInverser = new System.Windows.Forms.Label();
            this.txtNombreAInverser = new System.Windows.Forms.TextBox();
            this.btnAfficherInverseDeNombre = new System.Windows.Forms.Button();
            this.lblInverseDeNombre = new System.Windows.Forms.Label();
            this.tblPrincipal.SuspendLayout();
            this.SuspendLayout();
            // 
            // tblPrincipal
            // 
            this.tblPrincipal.ColumnCount = 7;
            this.tblPrincipal.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tblPrincipal.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.5F));
            this.tblPrincipal.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.5F));
            this.tblPrincipal.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tblPrincipal.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.5F));
            this.tblPrincipal.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.5F));
            this.tblPrincipal.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tblPrincipal.Controls.Add(this.btnAfficherSommeDeUnACent, 1, 1);
            this.tblPrincipal.Controls.Add(this.lblNombreDeDepartSomme, 1, 3);
            this.tblPrincipal.Controls.Add(this.txtNombreDeDepartSomme, 2, 3);
            this.tblPrincipal.Controls.Add(this.lblNombreDeFinSomme, 1, 4);
            this.tblPrincipal.Controls.Add(this.txtNombreDeFinSomme, 2, 4);
            this.tblPrincipal.Controls.Add(this.btnAfficherSommeDeXaY, 1, 5);
            this.tblPrincipal.Controls.Add(this.lblBase, 1, 7);
            this.tblPrincipal.Controls.Add(this.txtBase, 2, 7);
            this.tblPrincipal.Controls.Add(this.lblPuissance, 1, 8);
            this.tblPrincipal.Controls.Add(this.txtPuissance, 2, 8);
            this.tblPrincipal.Controls.Add(this.btnAfficherPuissance, 1, 9);
            this.tblPrincipal.Controls.Add(this.lblNombreX, 1, 11);
            this.tblPrincipal.Controls.Add(this.txtNombreX, 2, 11);
            this.tblPrincipal.Controls.Add(this.lblNombreY, 1, 12);
            this.tblPrincipal.Controls.Add(this.txtNombreY, 2, 12);
            this.tblPrincipal.Controls.Add(this.btnAfficherDecompte, 1, 13);
            this.tblPrincipal.Controls.Add(this.lstDecompte, 1, 14);
            this.tblPrincipal.Controls.Add(this.btnAjouterLigneEtEtoile, 4, 1);
            this.tblPrincipal.Controls.Add(this.lstLignesEtEtoiles, 4, 2);
            this.tblPrincipal.Controls.Add(this.lblNombreARepeter, 4, 5);
            this.tblPrincipal.Controls.Add(this.txtNombreARepeter, 5, 5);
            this.tblPrincipal.Controls.Add(this.lblNombreDeRepetitions, 4, 6);
            this.tblPrincipal.Controls.Add(this.txtNombreDeRepetitions, 5, 6);
            this.tblPrincipal.Controls.Add(this.btnAfficherRepetitionsNombre, 4, 7);
            this.tblPrincipal.Controls.Add(this.txtRepetitionsNombre, 4, 8);
            this.tblPrincipal.Controls.Add(this.lblNombreAInverser, 4, 10);
            this.tblPrincipal.Controls.Add(this.txtNombreAInverser, 5, 10);
            this.tblPrincipal.Controls.Add(this.btnAfficherInverseDeNombre, 4, 11);
            this.tblPrincipal.Controls.Add(this.lblInverseDeNombre, 4, 12);
            this.tblPrincipal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblPrincipal.Location = new System.Drawing.Point(0, 0);
            this.tblPrincipal.Name = "tblPrincipal";
            this.tblPrincipal.RowCount = 17;
            this.tblPrincipal.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.882352F));
            this.tblPrincipal.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.882352F));
            this.tblPrincipal.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.882352F));
            this.tblPrincipal.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.882352F));
            this.tblPrincipal.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.882352F));
            this.tblPrincipal.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.882352F));
            this.tblPrincipal.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.882352F));
            this.tblPrincipal.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.882352F));
            this.tblPrincipal.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.882352F));
            this.tblPrincipal.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.882352F));
            this.tblPrincipal.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.882352F));
            this.tblPrincipal.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.882352F));
            this.tblPrincipal.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.882352F));
            this.tblPrincipal.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.882352F));
            this.tblPrincipal.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.882352F));
            this.tblPrincipal.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.882352F));
            this.tblPrincipal.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.882352F));
            this.tblPrincipal.Size = new System.Drawing.Size(882, 603);
            this.tblPrincipal.TabIndex = 0;
            // 
            // btnAfficherSommeDeUnACent
            // 
            this.btnAfficherSommeDeUnACent.BackColor = System.Drawing.Color.MistyRose;
            this.tblPrincipal.SetColumnSpan(this.btnAfficherSommeDeUnACent, 2);
            this.btnAfficherSommeDeUnACent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAfficherSommeDeUnACent.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnAfficherSommeDeUnACent.Location = new System.Drawing.Point(91, 38);
            this.btnAfficherSommeDeUnACent.Name = "btnAfficherSommeDeUnACent";
            this.btnAfficherSommeDeUnACent.Size = new System.Drawing.Size(302, 29);
            this.btnAfficherSommeDeUnACent.TabIndex = 0;
            this.btnAfficherSommeDeUnACent.Text = "Somme 1 ... 100";
            this.btnAfficherSommeDeUnACent.UseVisualStyleBackColor = false;
            this.btnAfficherSommeDeUnACent.Click += new System.EventHandler(this.btnAfficherSommeDeUnACent_Click);
            // 
            // lblNombreDeDepartSomme
            // 
            this.lblNombreDeDepartSomme.AutoSize = true;
            this.lblNombreDeDepartSomme.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNombreDeDepartSomme.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblNombreDeDepartSomme.Location = new System.Drawing.Point(91, 105);
            this.lblNombreDeDepartSomme.Name = "lblNombreDeDepartSomme";
            this.lblNombreDeDepartSomme.Size = new System.Drawing.Size(148, 35);
            this.lblNombreDeDepartSomme.TabIndex = 1;
            this.lblNombreDeDepartSomme.Text = "Nombre de départ (X)";
            // 
            // txtNombreDeDepartSomme
            // 
            this.txtNombreDeDepartSomme.BackColor = System.Drawing.Color.White;
            this.txtNombreDeDepartSomme.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtNombreDeDepartSomme.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtNombreDeDepartSomme.Location = new System.Drawing.Point(245, 108);
            this.txtNombreDeDepartSomme.Name = "txtNombreDeDepartSomme";
            this.txtNombreDeDepartSomme.Size = new System.Drawing.Size(148, 22);
            this.txtNombreDeDepartSomme.TabIndex = 2;
            this.txtNombreDeDepartSomme.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblNombreDeFinSomme
            // 
            this.lblNombreDeFinSomme.AutoSize = true;
            this.lblNombreDeFinSomme.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNombreDeFinSomme.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblNombreDeFinSomme.Location = new System.Drawing.Point(91, 140);
            this.lblNombreDeFinSomme.Name = "lblNombreDeFinSomme";
            this.lblNombreDeFinSomme.Size = new System.Drawing.Size(148, 35);
            this.lblNombreDeFinSomme.TabIndex = 3;
            this.lblNombreDeFinSomme.Text = "Nombre de fin (Y)";
            // 
            // txtNombreDeFinSomme
            // 
            this.txtNombreDeFinSomme.BackColor = System.Drawing.Color.White;
            this.txtNombreDeFinSomme.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtNombreDeFinSomme.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtNombreDeFinSomme.Location = new System.Drawing.Point(245, 143);
            this.txtNombreDeFinSomme.Name = "txtNombreDeFinSomme";
            this.txtNombreDeFinSomme.Size = new System.Drawing.Size(148, 22);
            this.txtNombreDeFinSomme.TabIndex = 4;
            this.txtNombreDeFinSomme.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnAfficherSommeDeXaY
            // 
            this.btnAfficherSommeDeXaY.BackColor = System.Drawing.Color.LightBlue;
            this.tblPrincipal.SetColumnSpan(this.btnAfficherSommeDeXaY, 2);
            this.btnAfficherSommeDeXaY.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAfficherSommeDeXaY.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnAfficherSommeDeXaY.Location = new System.Drawing.Point(91, 178);
            this.btnAfficherSommeDeXaY.Name = "btnAfficherSommeDeXaY";
            this.btnAfficherSommeDeXaY.Size = new System.Drawing.Size(302, 29);
            this.btnAfficherSommeDeXaY.TabIndex = 5;
            this.btnAfficherSommeDeXaY.Text = "Somme X ... Y";
            this.btnAfficherSommeDeXaY.UseVisualStyleBackColor = false;
            this.btnAfficherSommeDeXaY.Click += new System.EventHandler(this.btnAfficherSommeDeXaY_Click);
            // 
            // lblBase
            // 
            this.lblBase.AutoSize = true;
            this.lblBase.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblBase.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.lblBase.Location = new System.Drawing.Point(91, 245);
            this.lblBase.Name = "lblBase";
            this.lblBase.Size = new System.Drawing.Size(148, 35);
            this.lblBase.TabIndex = 6;
            this.lblBase.Text = "Base";
            // 
            // txtBase
            // 
            this.txtBase.BackColor = System.Drawing.Color.White;
            this.txtBase.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtBase.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.txtBase.Location = new System.Drawing.Point(245, 248);
            this.txtBase.Name = "txtBase";
            this.txtBase.Size = new System.Drawing.Size(148, 22);
            this.txtBase.TabIndex = 7;
            this.txtBase.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblPuissance
            // 
            this.lblPuissance.AutoSize = true;
            this.lblPuissance.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPuissance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.lblPuissance.Location = new System.Drawing.Point(91, 280);
            this.lblPuissance.Name = "lblPuissance";
            this.lblPuissance.Size = new System.Drawing.Size(148, 35);
            this.lblPuissance.TabIndex = 8;
            this.lblPuissance.Text = "Puissance";
            // 
            // txtPuissance
            // 
            this.txtPuissance.BackColor = System.Drawing.Color.White;
            this.txtPuissance.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtPuissance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.txtPuissance.Location = new System.Drawing.Point(245, 283);
            this.txtPuissance.Name = "txtPuissance";
            this.txtPuissance.Size = new System.Drawing.Size(148, 22);
            this.txtPuissance.TabIndex = 9;
            this.txtPuissance.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnAfficherPuissance
            // 
            this.btnAfficherPuissance.BackColor = System.Drawing.Color.Bisque;
            this.tblPrincipal.SetColumnSpan(this.btnAfficherPuissance, 2);
            this.btnAfficherPuissance.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAfficherPuissance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnAfficherPuissance.Location = new System.Drawing.Point(91, 318);
            this.btnAfficherPuissance.Name = "btnAfficherPuissance";
            this.btnAfficherPuissance.Size = new System.Drawing.Size(302, 29);
            this.btnAfficherPuissance.TabIndex = 10;
            this.btnAfficherPuissance.Text = "Puissance";
            this.btnAfficherPuissance.UseVisualStyleBackColor = false;
            this.btnAfficherPuissance.Click += new System.EventHandler(this.btnAfficherPuissance_Click);
            // 
            // lblNombreX
            // 
            this.lblNombreX.AutoSize = true;
            this.lblNombreX.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNombreX.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.lblNombreX.Location = new System.Drawing.Point(91, 385);
            this.lblNombreX.Name = "lblNombreX";
            this.lblNombreX.Size = new System.Drawing.Size(148, 35);
            this.lblNombreX.TabIndex = 11;
            this.lblNombreX.Text = "Premier nombre (X)";
            // 
            // txtNombreX
            // 
            this.txtNombreX.BackColor = System.Drawing.Color.White;
            this.txtNombreX.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtNombreX.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.txtNombreX.Location = new System.Drawing.Point(245, 388);
            this.txtNombreX.Name = "txtNombreX";
            this.txtNombreX.Size = new System.Drawing.Size(148, 22);
            this.txtNombreX.TabIndex = 12;
            this.txtNombreX.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblNombreY
            // 
            this.lblNombreY.AutoSize = true;
            this.lblNombreY.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNombreY.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.lblNombreY.Location = new System.Drawing.Point(91, 420);
            this.lblNombreY.Name = "lblNombreY";
            this.lblNombreY.Size = new System.Drawing.Size(148, 35);
            this.lblNombreY.TabIndex = 13;
            this.lblNombreY.Text = "Deuxième nombre (Y)";
            // 
            // txtNombreY
            // 
            this.txtNombreY.BackColor = System.Drawing.Color.White;
            this.txtNombreY.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtNombreY.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.txtNombreY.Location = new System.Drawing.Point(245, 423);
            this.txtNombreY.Name = "txtNombreY";
            this.txtNombreY.Size = new System.Drawing.Size(148, 22);
            this.txtNombreY.TabIndex = 14;
            this.txtNombreY.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnAfficherDecompte
            // 
            this.btnAfficherDecompte.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tblPrincipal.SetColumnSpan(this.btnAfficherDecompte, 2);
            this.btnAfficherDecompte.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAfficherDecompte.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnAfficherDecompte.Location = new System.Drawing.Point(91, 458);
            this.btnAfficherDecompte.Name = "btnAfficherDecompte";
            this.btnAfficherDecompte.Size = new System.Drawing.Size(302, 29);
            this.btnAfficherDecompte.TabIndex = 15;
            this.btnAfficherDecompte.Text = "Décompte";
            this.btnAfficherDecompte.UseVisualStyleBackColor = false;
            this.btnAfficherDecompte.Click += new System.EventHandler(this.btnAfficherDecompte_Click);
            // 
            // lstDecompte
            // 
            this.tblPrincipal.SetColumnSpan(this.lstDecompte, 2);
            this.lstDecompte.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lstDecompte.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.lstDecompte.FormattingEnabled = true;
            this.lstDecompte.ItemHeight = 16;
            this.lstDecompte.Location = new System.Drawing.Point(91, 493);
            this.lstDecompte.Name = "lstDecompte";
            this.tblPrincipal.SetRowSpan(this.lstDecompte, 2);
            this.lstDecompte.Size = new System.Drawing.Size(302, 64);
            this.lstDecompte.TabIndex = 16;
            // 
            // btnAjouterLigneEtEtoile
            // 
            this.btnAjouterLigneEtEtoile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.tblPrincipal.SetColumnSpan(this.btnAjouterLigneEtEtoile, 2);
            this.btnAjouterLigneEtEtoile.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAjouterLigneEtEtoile.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnAjouterLigneEtEtoile.Location = new System.Drawing.Point(487, 38);
            this.btnAjouterLigneEtEtoile.Name = "btnAjouterLigneEtEtoile";
            this.btnAjouterLigneEtEtoile.Size = new System.Drawing.Size(302, 29);
            this.btnAjouterLigneEtEtoile.TabIndex = 17;
            this.btnAjouterLigneEtEtoile.Text = "Ajouter une ligne d\'étoiles";
            this.btnAjouterLigneEtEtoile.UseVisualStyleBackColor = false;
            this.btnAjouterLigneEtEtoile.Click += new System.EventHandler(this.btnAjouterLigneEtEtoile_Click);
            // 
            // lstLignesEtEtoiles
            // 
            this.tblPrincipal.SetColumnSpan(this.lstLignesEtEtoiles, 2);
            this.lstLignesEtEtoiles.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lstLignesEtEtoiles.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lstLignesEtEtoiles.FormattingEnabled = true;
            this.lstLignesEtEtoiles.ItemHeight = 16;
            this.lstLignesEtEtoiles.Location = new System.Drawing.Point(487, 73);
            this.lstLignesEtEtoiles.Name = "lstLignesEtEtoiles";
            this.tblPrincipal.SetRowSpan(this.lstLignesEtEtoiles, 2);
            this.lstLignesEtEtoiles.Size = new System.Drawing.Size(302, 64);
            this.lstLignesEtEtoiles.TabIndex = 18;
            // 
            // lblNombreARepeter
            // 
            this.lblNombreARepeter.AutoSize = true;
            this.lblNombreARepeter.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNombreARepeter.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.lblNombreARepeter.Location = new System.Drawing.Point(487, 175);
            this.lblNombreARepeter.Name = "lblNombreARepeter";
            this.lblNombreARepeter.Size = new System.Drawing.Size(148, 35);
            this.lblNombreARepeter.TabIndex = 19;
            this.lblNombreARepeter.Text = "Nombre à répéter";
            // 
            // txtNombreARepeter
            // 
            this.txtNombreARepeter.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtNombreARepeter.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.txtNombreARepeter.Location = new System.Drawing.Point(641, 178);
            this.txtNombreARepeter.Name = "txtNombreARepeter";
            this.txtNombreARepeter.Size = new System.Drawing.Size(148, 22);
            this.txtNombreARepeter.TabIndex = 20;
            this.txtNombreARepeter.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblNombreDeRepetitions
            // 
            this.lblNombreDeRepetitions.AutoSize = true;
            this.lblNombreDeRepetitions.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.lblNombreDeRepetitions.Location = new System.Drawing.Point(487, 210);
            this.lblNombreDeRepetitions.Name = "lblNombreDeRepetitions";
            this.lblNombreDeRepetitions.Size = new System.Drawing.Size(148, 17);
            this.lblNombreDeRepetitions.TabIndex = 21;
            this.lblNombreDeRepetitions.Text = "Nombre de répétitions";
            // 
            // txtNombreDeRepetitions
            // 
            this.txtNombreDeRepetitions.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtNombreDeRepetitions.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.txtNombreDeRepetitions.Location = new System.Drawing.Point(641, 213);
            this.txtNombreDeRepetitions.Name = "txtNombreDeRepetitions";
            this.txtNombreDeRepetitions.Size = new System.Drawing.Size(148, 22);
            this.txtNombreDeRepetitions.TabIndex = 22;
            this.txtNombreDeRepetitions.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnAfficherRepetitionsNombre
            // 
            this.btnAfficherRepetitionsNombre.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tblPrincipal.SetColumnSpan(this.btnAfficherRepetitionsNombre, 2);
            this.btnAfficherRepetitionsNombre.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAfficherRepetitionsNombre.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnAfficherRepetitionsNombre.Location = new System.Drawing.Point(487, 248);
            this.btnAfficherRepetitionsNombre.Name = "btnAfficherRepetitionsNombre";
            this.btnAfficherRepetitionsNombre.Size = new System.Drawing.Size(302, 29);
            this.btnAfficherRepetitionsNombre.TabIndex = 23;
            this.btnAfficherRepetitionsNombre.Text = "Répéter nombre";
            this.btnAfficherRepetitionsNombre.UseVisualStyleBackColor = false;
            this.btnAfficherRepetitionsNombre.Click += new System.EventHandler(this.btnAfficherRepetitionsNombre_Click);
            // 
            // txtRepetitionsNombre
            // 
            this.tblPrincipal.SetColumnSpan(this.txtRepetitionsNombre, 2);
            this.txtRepetitionsNombre.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtRepetitionsNombre.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.txtRepetitionsNombre.Location = new System.Drawing.Point(487, 283);
            this.txtRepetitionsNombre.Name = "txtRepetitionsNombre";
            this.txtRepetitionsNombre.ReadOnly = true;
            this.txtRepetitionsNombre.Size = new System.Drawing.Size(302, 22);
            this.txtRepetitionsNombre.TabIndex = 24;
            this.txtRepetitionsNombre.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblNombreAInverser
            // 
            this.lblNombreAInverser.AutoSize = true;
            this.lblNombreAInverser.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNombreAInverser.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblNombreAInverser.Location = new System.Drawing.Point(487, 350);
            this.lblNombreAInverser.Name = "lblNombreAInverser";
            this.lblNombreAInverser.Size = new System.Drawing.Size(148, 35);
            this.lblNombreAInverser.TabIndex = 25;
            this.lblNombreAInverser.Text = "Nombre à inverser";
            // 
            // txtNombreAInverser
            // 
            this.txtNombreAInverser.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtNombreAInverser.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtNombreAInverser.Location = new System.Drawing.Point(641, 353);
            this.txtNombreAInverser.Name = "txtNombreAInverser";
            this.txtNombreAInverser.Size = new System.Drawing.Size(148, 22);
            this.txtNombreAInverser.TabIndex = 26;
            this.txtNombreAInverser.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnAfficherInverseDeNombre
            // 
            this.btnAfficherInverseDeNombre.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.tblPrincipal.SetColumnSpan(this.btnAfficherInverseDeNombre, 2);
            this.btnAfficherInverseDeNombre.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAfficherInverseDeNombre.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnAfficherInverseDeNombre.Location = new System.Drawing.Point(487, 388);
            this.btnAfficherInverseDeNombre.Name = "btnAfficherInverseDeNombre";
            this.btnAfficherInverseDeNombre.Size = new System.Drawing.Size(302, 29);
            this.btnAfficherInverseDeNombre.TabIndex = 27;
            this.btnAfficherInverseDeNombre.Text = "Inverser";
            this.btnAfficherInverseDeNombre.UseVisualStyleBackColor = false;
            this.btnAfficherInverseDeNombre.Click += new System.EventHandler(this.btnAfficherInverseDeNombre_Click);
            // 
            // lblInverseDeNombre
            // 
            this.lblInverseDeNombre.AutoSize = true;
            this.tblPrincipal.SetColumnSpan(this.lblInverseDeNombre, 2);
            this.lblInverseDeNombre.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblInverseDeNombre.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblInverseDeNombre.Location = new System.Drawing.Point(487, 420);
            this.lblInverseDeNombre.Name = "lblInverseDeNombre";
            this.lblInverseDeNombre.Size = new System.Drawing.Size(302, 35);
            this.lblInverseDeNombre.TabIndex = 28;
            this.lblInverseDeNombre.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // frmTP6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(882, 603);
            this.Controls.Add(this.tblPrincipal);
            this.MaximumSize = new System.Drawing.Size(900, 650);
            this.MinimumSize = new System.Drawing.Size(900, 650);
            this.Name = "frmTP6";
            this.Text = "Boucles";
            this.tblPrincipal.ResumeLayout(false);
            this.tblPrincipal.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tblPrincipal;
        private System.Windows.Forms.Button btnAfficherSommeDeUnACent;
        private System.Windows.Forms.Label lblNombreDeDepartSomme;
        private System.Windows.Forms.TextBox txtNombreDeDepartSomme;
        private System.Windows.Forms.Label lblNombreDeFinSomme;
        private System.Windows.Forms.TextBox txtNombreDeFinSomme;
        private System.Windows.Forms.Button btnAfficherSommeDeXaY;
        private System.Windows.Forms.Label lblBase;
        private System.Windows.Forms.TextBox txtBase;
        private System.Windows.Forms.Label lblPuissance;
        private System.Windows.Forms.TextBox txtPuissance;
        private System.Windows.Forms.Button btnAfficherPuissance;
        private System.Windows.Forms.Label lblNombreX;
        private System.Windows.Forms.TextBox txtNombreX;
        private System.Windows.Forms.Label lblNombreY;
        private System.Windows.Forms.TextBox txtNombreY;
        private System.Windows.Forms.Button btnAfficherDecompte;
        private System.Windows.Forms.ListBox lstDecompte;
        private System.Windows.Forms.Button btnAjouterLigneEtEtoile;
        private System.Windows.Forms.ListBox lstLignesEtEtoiles;
        private System.Windows.Forms.Label lblNombreARepeter;
        private System.Windows.Forms.TextBox txtNombreARepeter;
        private System.Windows.Forms.Label lblNombreDeRepetitions;
        private System.Windows.Forms.TextBox txtNombreDeRepetitions;
        private System.Windows.Forms.Button btnAfficherRepetitionsNombre;
        private System.Windows.Forms.TextBox txtRepetitionsNombre;
        private System.Windows.Forms.Label lblNombreAInverser;
        private System.Windows.Forms.TextBox txtNombreAInverser;
        private System.Windows.Forms.Button btnAfficherInverseDeNombre;
        private System.Windows.Forms.Label lblInverseDeNombre;
    }
}

