﻿namespace TP3
{
    partial class frmTP3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tblPrincipal = new System.Windows.Forms.TableLayoutPanel();
            this.lblNoteTravail4 = new System.Windows.Forms.Label();
            this.txtNoteTravail3 = new System.Windows.Forms.TextBox();
            this.lblNoteTravail3 = new System.Windows.Forms.Label();
            this.txtNoteExamen3 = new System.Windows.Forms.TextBox();
            this.lblNoteExamen3 = new System.Windows.Forms.Label();
            this.txtNoteTravail2 = new System.Windows.Forms.TextBox();
            this.lblNoteTravail2 = new System.Windows.Forms.Label();
            this.txtNoteExamen2 = new System.Windows.Forms.TextBox();
            this.lblNoteExamen2 = new System.Windows.Forms.Label();
            this.txtNoteTravail1 = new System.Windows.Forms.TextBox();
            this.lblNoteTravail1 = new System.Windows.Forms.Label();
            this.txtNoteExamen1 = new System.Windows.Forms.TextBox();
            this.lblNoteExamen1 = new System.Windows.Forms.Label();
            this.txtMatricule = new System.Windows.Forms.TextBox();
            this.lblMatricule = new System.Windows.Forms.Label();
            this.lblPrenomNom = new System.Windows.Forms.Label();
            this.txtPrenomNom = new System.Windows.Forms.TextBox();
            this.lblNoteFinale = new System.Windows.Forms.Label();
            this.txtNoteTravail4 = new System.Windows.Forms.TextBox();
            this.txtNoteFinale = new System.Windows.Forms.TextBox();
            this.lblMention = new System.Windows.Forms.Label();
            this.txtMention = new System.Windows.Forms.TextBox();
            this.btnCalculerNoteFinale = new System.Windows.Forms.Button();
            this.tblPrincipal.SuspendLayout();
            this.SuspendLayout();
            // 
            // tblPrincipal
            // 
            this.tblPrincipal.ColumnCount = 4;
            this.tblPrincipal.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tblPrincipal.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tblPrincipal.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tblPrincipal.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tblPrincipal.Controls.Add(this.lblNoteTravail4, 2, 4);
            this.tblPrincipal.Controls.Add(this.txtNoteTravail3, 3, 3);
            this.tblPrincipal.Controls.Add(this.lblNoteTravail3, 2, 3);
            this.tblPrincipal.Controls.Add(this.txtNoteExamen3, 1, 3);
            this.tblPrincipal.Controls.Add(this.lblNoteExamen3, 0, 3);
            this.tblPrincipal.Controls.Add(this.txtNoteTravail2, 3, 2);
            this.tblPrincipal.Controls.Add(this.lblNoteTravail2, 2, 2);
            this.tblPrincipal.Controls.Add(this.txtNoteExamen2, 1, 2);
            this.tblPrincipal.Controls.Add(this.lblNoteExamen2, 0, 2);
            this.tblPrincipal.Controls.Add(this.txtNoteTravail1, 3, 1);
            this.tblPrincipal.Controls.Add(this.lblNoteTravail1, 2, 1);
            this.tblPrincipal.Controls.Add(this.txtNoteExamen1, 1, 1);
            this.tblPrincipal.Controls.Add(this.lblNoteExamen1, 0, 1);
            this.tblPrincipal.Controls.Add(this.txtMatricule, 3, 0);
            this.tblPrincipal.Controls.Add(this.lblMatricule, 2, 0);
            this.tblPrincipal.Controls.Add(this.lblPrenomNom, 0, 0);
            this.tblPrincipal.Controls.Add(this.txtPrenomNom, 1, 0);
            this.tblPrincipal.Controls.Add(this.lblNoteFinale, 0, 6);
            this.tblPrincipal.Controls.Add(this.txtNoteTravail4, 3, 4);
            this.tblPrincipal.Controls.Add(this.txtNoteFinale, 1, 6);
            this.tblPrincipal.Controls.Add(this.lblMention, 2, 6);
            this.tblPrincipal.Controls.Add(this.txtMention, 3, 6);
            this.tblPrincipal.Controls.Add(this.btnCalculerNoteFinale, 0, 5);
            this.tblPrincipal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblPrincipal.Location = new System.Drawing.Point(0, 0);
            this.tblPrincipal.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
            this.tblPrincipal.Name = "tblPrincipal";
            this.tblPrincipal.Padding = new System.Windows.Forms.Padding(17, 16, 17, 16);
            this.tblPrincipal.RowCount = 7;
            this.tblPrincipal.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tblPrincipal.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tblPrincipal.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tblPrincipal.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tblPrincipal.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tblPrincipal.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tblPrincipal.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tblPrincipal.Size = new System.Drawing.Size(556, 235);
            this.tblPrincipal.TabIndex = 0;
            // 
            // lblNoteTravail4
            // 
            this.lblNoteTravail4.AutoSize = true;
            this.lblNoteTravail4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNoteTravail4.Location = new System.Drawing.Point(279, 128);
            this.lblNoteTravail4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNoteTravail4.Name = "lblNoteTravail4";
            this.lblNoteTravail4.Size = new System.Drawing.Size(126, 28);
            this.lblNoteTravail4.TabIndex = 0;
            this.lblNoteTravail4.Text = "Note travail 4";
            this.lblNoteTravail4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtNoteTravail3
            // 
            this.txtNoteTravail3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtNoteTravail3.Location = new System.Drawing.Point(409, 102);
            this.txtNoteTravail3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtNoteTravail3.Name = "txtNoteTravail3";
            this.txtNoteTravail3.Size = new System.Drawing.Size(128, 20);
            this.txtNoteTravail3.TabIndex = 8;
            // 
            // lblNoteTravail3
            // 
            this.lblNoteTravail3.AutoSize = true;
            this.lblNoteTravail3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNoteTravail3.Location = new System.Drawing.Point(279, 100);
            this.lblNoteTravail3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNoteTravail3.Name = "lblNoteTravail3";
            this.lblNoteTravail3.Size = new System.Drawing.Size(126, 28);
            this.lblNoteTravail3.TabIndex = 0;
            this.lblNoteTravail3.Text = "Note travail 3";
            this.lblNoteTravail3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtNoteExamen3
            // 
            this.txtNoteExamen3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtNoteExamen3.Location = new System.Drawing.Point(149, 102);
            this.txtNoteExamen3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtNoteExamen3.Name = "txtNoteExamen3";
            this.txtNoteExamen3.Size = new System.Drawing.Size(126, 20);
            this.txtNoteExamen3.TabIndex = 5;
            // 
            // lblNoteExamen3
            // 
            this.lblNoteExamen3.AutoSize = true;
            this.lblNoteExamen3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNoteExamen3.Location = new System.Drawing.Point(19, 100);
            this.lblNoteExamen3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNoteExamen3.Name = "lblNoteExamen3";
            this.lblNoteExamen3.Size = new System.Drawing.Size(126, 28);
            this.lblNoteExamen3.TabIndex = 0;
            this.lblNoteExamen3.Text = "Note examen 3";
            this.lblNoteExamen3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtNoteTravail2
            // 
            this.txtNoteTravail2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtNoteTravail2.Location = new System.Drawing.Point(409, 74);
            this.txtNoteTravail2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtNoteTravail2.Name = "txtNoteTravail2";
            this.txtNoteTravail2.Size = new System.Drawing.Size(128, 20);
            this.txtNoteTravail2.TabIndex = 7;
            // 
            // lblNoteTravail2
            // 
            this.lblNoteTravail2.AutoSize = true;
            this.lblNoteTravail2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNoteTravail2.Location = new System.Drawing.Point(279, 72);
            this.lblNoteTravail2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNoteTravail2.Name = "lblNoteTravail2";
            this.lblNoteTravail2.Size = new System.Drawing.Size(126, 28);
            this.lblNoteTravail2.TabIndex = 0;
            this.lblNoteTravail2.Text = "Note travail 2";
            this.lblNoteTravail2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtNoteExamen2
            // 
            this.txtNoteExamen2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtNoteExamen2.Location = new System.Drawing.Point(149, 74);
            this.txtNoteExamen2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtNoteExamen2.Name = "txtNoteExamen2";
            this.txtNoteExamen2.Size = new System.Drawing.Size(126, 20);
            this.txtNoteExamen2.TabIndex = 4;
            // 
            // lblNoteExamen2
            // 
            this.lblNoteExamen2.AutoSize = true;
            this.lblNoteExamen2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNoteExamen2.Location = new System.Drawing.Point(19, 72);
            this.lblNoteExamen2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNoteExamen2.Name = "lblNoteExamen2";
            this.lblNoteExamen2.Size = new System.Drawing.Size(126, 28);
            this.lblNoteExamen2.TabIndex = 0;
            this.lblNoteExamen2.Text = "Note examen 2";
            this.lblNoteExamen2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtNoteTravail1
            // 
            this.txtNoteTravail1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtNoteTravail1.Location = new System.Drawing.Point(409, 46);
            this.txtNoteTravail1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtNoteTravail1.Name = "txtNoteTravail1";
            this.txtNoteTravail1.Size = new System.Drawing.Size(128, 20);
            this.txtNoteTravail1.TabIndex = 6;
            // 
            // lblNoteTravail1
            // 
            this.lblNoteTravail1.AutoSize = true;
            this.lblNoteTravail1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNoteTravail1.Location = new System.Drawing.Point(279, 44);
            this.lblNoteTravail1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNoteTravail1.Name = "lblNoteTravail1";
            this.lblNoteTravail1.Size = new System.Drawing.Size(126, 28);
            this.lblNoteTravail1.TabIndex = 0;
            this.lblNoteTravail1.Text = "Note travail 1";
            this.lblNoteTravail1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtNoteExamen1
            // 
            this.txtNoteExamen1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtNoteExamen1.Location = new System.Drawing.Point(149, 46);
            this.txtNoteExamen1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtNoteExamen1.Name = "txtNoteExamen1";
            this.txtNoteExamen1.Size = new System.Drawing.Size(126, 20);
            this.txtNoteExamen1.TabIndex = 3;
            // 
            // lblNoteExamen1
            // 
            this.lblNoteExamen1.AutoSize = true;
            this.lblNoteExamen1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNoteExamen1.Location = new System.Drawing.Point(19, 44);
            this.lblNoteExamen1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNoteExamen1.Name = "lblNoteExamen1";
            this.lblNoteExamen1.Size = new System.Drawing.Size(126, 28);
            this.lblNoteExamen1.TabIndex = 0;
            this.lblNoteExamen1.Text = "Note examen 1";
            this.lblNoteExamen1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtMatricule
            // 
            this.txtMatricule.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtMatricule.Location = new System.Drawing.Point(409, 18);
            this.txtMatricule.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtMatricule.Name = "txtMatricule";
            this.txtMatricule.Size = new System.Drawing.Size(128, 20);
            this.txtMatricule.TabIndex = 2;
            // 
            // lblMatricule
            // 
            this.lblMatricule.AutoSize = true;
            this.lblMatricule.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblMatricule.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblMatricule.Location = new System.Drawing.Point(279, 16);
            this.lblMatricule.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblMatricule.Name = "lblMatricule";
            this.lblMatricule.Size = new System.Drawing.Size(126, 28);
            this.lblMatricule.TabIndex = 0;
            this.lblMatricule.Text = "Matricule";
            this.lblMatricule.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblPrenomNom
            // 
            this.lblPrenomNom.AutoSize = true;
            this.lblPrenomNom.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblPrenomNom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblPrenomNom.Location = new System.Drawing.Point(19, 16);
            this.lblPrenomNom.Margin = new System.Windows.Forms.Padding(2, 0, 2, 6);
            this.lblPrenomNom.Name = "lblPrenomNom";
            this.lblPrenomNom.Size = new System.Drawing.Size(126, 22);
            this.lblPrenomNom.TabIndex = 0;
            this.lblPrenomNom.Text = "Prénom et Nom";
            this.lblPrenomNom.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtPrenomNom
            // 
            this.txtPrenomNom.AcceptsReturn = true;
            this.txtPrenomNom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtPrenomNom.Location = new System.Drawing.Point(149, 18);
            this.txtPrenomNom.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtPrenomNom.Name = "txtPrenomNom";
            this.txtPrenomNom.Size = new System.Drawing.Size(126, 20);
            this.txtPrenomNom.TabIndex = 1;
            // 
            // lblNoteFinale
            // 
            this.lblNoteFinale.AutoSize = true;
            this.lblNoteFinale.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNoteFinale.Location = new System.Drawing.Point(19, 184);
            this.lblNoteFinale.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNoteFinale.Name = "lblNoteFinale";
            this.lblNoteFinale.Size = new System.Drawing.Size(126, 35);
            this.lblNoteFinale.TabIndex = 0;
            this.lblNoteFinale.Text = "Note finale";
            this.lblNoteFinale.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtNoteTravail4
            // 
            this.txtNoteTravail4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtNoteTravail4.Location = new System.Drawing.Point(409, 130);
            this.txtNoteTravail4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtNoteTravail4.Name = "txtNoteTravail4";
            this.txtNoteTravail4.Size = new System.Drawing.Size(128, 20);
            this.txtNoteTravail4.TabIndex = 9;
            // 
            // txtNoteFinale
            // 
            this.txtNoteFinale.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtNoteFinale.Location = new System.Drawing.Point(149, 186);
            this.txtNoteFinale.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtNoteFinale.Name = "txtNoteFinale";
            this.txtNoteFinale.ReadOnly = true;
            this.txtNoteFinale.Size = new System.Drawing.Size(126, 20);
            this.txtNoteFinale.TabIndex = 11;
            // 
            // lblMention
            // 
            this.lblMention.AutoSize = true;
            this.lblMention.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblMention.Location = new System.Drawing.Point(279, 184);
            this.lblMention.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblMention.Name = "lblMention";
            this.lblMention.Size = new System.Drawing.Size(126, 35);
            this.lblMention.TabIndex = 0;
            this.lblMention.Text = "Mention";
            this.lblMention.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtMention
            // 
            this.txtMention.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtMention.Location = new System.Drawing.Point(409, 186);
            this.txtMention.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtMention.Name = "txtMention";
            this.txtMention.ReadOnly = true;
            this.txtMention.Size = new System.Drawing.Size(128, 20);
            this.txtMention.TabIndex = 12;
            // 
            // btnCalculerNoteFinale
            // 
            this.tblPrincipal.SetColumnSpan(this.btnCalculerNoteFinale, 4);
            this.btnCalculerNoteFinale.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnCalculerNoteFinale.Location = new System.Drawing.Point(19, 158);
            this.btnCalculerNoteFinale.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnCalculerNoteFinale.Name = "btnCalculerNoteFinale";
            this.btnCalculerNoteFinale.Size = new System.Drawing.Size(518, 24);
            this.btnCalculerNoteFinale.TabIndex = 10;
            this.btnCalculerNoteFinale.Text = "Calculer la note finale";
            this.btnCalculerNoteFinale.UseVisualStyleBackColor = true;
            this.btnCalculerNoteFinale.Click += new System.EventHandler(this.btnCalculerNoteFinale_Click);
            // 
            // frmTP3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(556, 235);
            this.Controls.Add(this.tblPrincipal);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.MaximumSize = new System.Drawing.Size(572, 274);
            this.MinimumSize = new System.Drawing.Size(572, 274);
            this.Name = "frmTP3";
            this.Text = "Calcul des notes finales COURS BUREAUTIQUE";
            this.tblPrincipal.ResumeLayout(false);
            this.tblPrincipal.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tblPrincipal;
        private System.Windows.Forms.Label lblNoteTravail4;
        private System.Windows.Forms.TextBox txtNoteTravail3;
        private System.Windows.Forms.Label lblNoteTravail3;
        private System.Windows.Forms.TextBox txtNoteExamen3;
        private System.Windows.Forms.Label lblNoteExamen3;
        private System.Windows.Forms.TextBox txtNoteTravail2;
        private System.Windows.Forms.Label lblNoteTravail2;
        private System.Windows.Forms.TextBox txtNoteExamen2;
        private System.Windows.Forms.Label lblNoteExamen2;
        private System.Windows.Forms.TextBox txtNoteTravail1;
        private System.Windows.Forms.Label lblNoteTravail1;
        private System.Windows.Forms.TextBox txtNoteExamen1;
        private System.Windows.Forms.Label lblNoteExamen1;
        private System.Windows.Forms.TextBox txtMatricule;
        private System.Windows.Forms.Label lblMatricule;
        private System.Windows.Forms.Label lblPrenomNom;
        private System.Windows.Forms.Label lblNoteFinale;
        private System.Windows.Forms.TextBox txtNoteTravail4;
        private System.Windows.Forms.TextBox txtNoteFinale;
        private System.Windows.Forms.Label lblMention;
        private System.Windows.Forms.TextBox txtMention;
        private System.Windows.Forms.Button btnCalculerNoteFinale;
        private System.Windows.Forms.TextBox txtPrenomNom;
    }
}

