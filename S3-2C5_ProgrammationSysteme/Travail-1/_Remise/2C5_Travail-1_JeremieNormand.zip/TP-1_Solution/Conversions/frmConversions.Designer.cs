﻿namespace Conversions
{
    partial class frmConversions
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtBinDeHexa = new System.Windows.Forms.TextBox();
            this.txtHexaABin = new System.Windows.Forms.TextBox();
            this.txtHexaDeBin = new System.Windows.Forms.TextBox();
            this.txtBinAHexa = new System.Windows.Forms.TextBox();
            this.txtHexaDeDec = new System.Windows.Forms.TextBox();
            this.txtDecimalAHexa = new System.Windows.Forms.TextBox();
            this.txtDecimalDeHexa = new System.Windows.Forms.TextBox();
            this.txtHexaADec = new System.Windows.Forms.TextBox();
            this.txtBinaireDeDec = new System.Windows.Forms.TextBox();
            this.txtDecimalABin = new System.Windows.Forms.TextBox();
            this.txtDecimalDeBin = new System.Windows.Forms.TextBox();
            this.txtBinaireADec = new System.Windows.Forms.TextBox();
            this.lblHexaDeBin = new System.Windows.Forms.Label();
            this.lblBinAHexa = new System.Windows.Forms.Label();
            this.lblBinDeHexa = new System.Windows.Forms.Label();
            this.lblHexaABin = new System.Windows.Forms.Label();
            this.lblDecimalAHexa = new System.Windows.Forms.Label();
            this.lblHexaDeDec = new System.Windows.Forms.Label();
            this.lblHexaADec = new System.Windows.Forms.Label();
            this.lblDecimalDeHexa = new System.Windows.Forms.Label();
            this.lblBinaireDeDec = new System.Windows.Forms.Label();
            this.lblDecimalABin = new System.Windows.Forms.Label();
            this.lblDecimalDeBin = new System.Windows.Forms.Label();
            this.lblBinaireADec = new System.Windows.Forms.Label();
            this.btnHexaBinaire = new System.Windows.Forms.Button();
            this.btnBinaireHexa = new System.Windows.Forms.Button();
            this.btnDecimalHexa = new System.Windows.Forms.Button();
            this.btnHexaDecimal = new System.Windows.Forms.Button();
            this.btnDecimalBinaire = new System.Windows.Forms.Button();
            this.btnBinaireDecimal = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtBinDeHexa
            // 
            this.txtBinDeHexa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBinDeHexa.Location = new System.Drawing.Point(583, 470);
            this.txtBinDeHexa.Margin = new System.Windows.Forms.Padding(5);
            this.txtBinDeHexa.Name = "txtBinDeHexa";
            this.txtBinDeHexa.ReadOnly = true;
            this.txtBinDeHexa.Size = new System.Drawing.Size(211, 30);
            this.txtBinDeHexa.TabIndex = 59;
            // 
            // txtHexaABin
            // 
            this.txtHexaABin.BackColor = System.Drawing.Color.White;
            this.txtHexaABin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHexaABin.Location = new System.Drawing.Point(63, 470);
            this.txtHexaABin.Margin = new System.Windows.Forms.Padding(5);
            this.txtHexaABin.Name = "txtHexaABin";
            this.txtHexaABin.Size = new System.Drawing.Size(212, 30);
            this.txtHexaABin.TabIndex = 58;
            this.txtHexaABin.Validating += new System.ComponentModel.CancelEventHandler(this.txtHexaABin_Validating);
            // 
            // txtHexaDeBin
            // 
            this.txtHexaDeBin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHexaDeBin.Location = new System.Drawing.Point(583, 386);
            this.txtHexaDeBin.Margin = new System.Windows.Forms.Padding(5);
            this.txtHexaDeBin.Name = "txtHexaDeBin";
            this.txtHexaDeBin.ReadOnly = true;
            this.txtHexaDeBin.Size = new System.Drawing.Size(211, 30);
            this.txtHexaDeBin.TabIndex = 57;
            // 
            // txtBinAHexa
            // 
            this.txtBinAHexa.BackColor = System.Drawing.Color.White;
            this.txtBinAHexa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBinAHexa.Location = new System.Drawing.Point(63, 386);
            this.txtBinAHexa.Margin = new System.Windows.Forms.Padding(5);
            this.txtBinAHexa.Name = "txtBinAHexa";
            this.txtBinAHexa.Size = new System.Drawing.Size(212, 30);
            this.txtBinAHexa.TabIndex = 56;
            this.txtBinAHexa.Validating += new System.ComponentModel.CancelEventHandler(this.txtBinAHexa_Validating);
            // 
            // txtHexaDeDec
            // 
            this.txtHexaDeDec.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHexaDeDec.Location = new System.Drawing.Point(583, 304);
            this.txtHexaDeDec.Margin = new System.Windows.Forms.Padding(5);
            this.txtHexaDeDec.Name = "txtHexaDeDec";
            this.txtHexaDeDec.ReadOnly = true;
            this.txtHexaDeDec.Size = new System.Drawing.Size(211, 30);
            this.txtHexaDeDec.TabIndex = 55;
            // 
            // txtDecimalAHexa
            // 
            this.txtDecimalAHexa.BackColor = System.Drawing.Color.White;
            this.txtDecimalAHexa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDecimalAHexa.Location = new System.Drawing.Point(63, 304);
            this.txtDecimalAHexa.Margin = new System.Windows.Forms.Padding(5);
            this.txtDecimalAHexa.Name = "txtDecimalAHexa";
            this.txtDecimalAHexa.Size = new System.Drawing.Size(212, 30);
            this.txtDecimalAHexa.TabIndex = 54;
            this.txtDecimalAHexa.Validating += new System.ComponentModel.CancelEventHandler(this.txtDecimalAHexa_Validating);
            // 
            // txtDecimalDeHexa
            // 
            this.txtDecimalDeHexa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDecimalDeHexa.Location = new System.Drawing.Point(583, 229);
            this.txtDecimalDeHexa.Margin = new System.Windows.Forms.Padding(5);
            this.txtDecimalDeHexa.Name = "txtDecimalDeHexa";
            this.txtDecimalDeHexa.ReadOnly = true;
            this.txtDecimalDeHexa.Size = new System.Drawing.Size(211, 30);
            this.txtDecimalDeHexa.TabIndex = 53;
            // 
            // txtHexaADec
            // 
            this.txtHexaADec.BackColor = System.Drawing.Color.White;
            this.txtHexaADec.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHexaADec.Location = new System.Drawing.Point(63, 230);
            this.txtHexaADec.Margin = new System.Windows.Forms.Padding(5);
            this.txtHexaADec.Name = "txtHexaADec";
            this.txtHexaADec.Size = new System.Drawing.Size(212, 30);
            this.txtHexaADec.TabIndex = 52;
            this.txtHexaADec.Validating += new System.ComponentModel.CancelEventHandler(this.txtHexaADec_Validating);
            // 
            // txtBinaireDeDec
            // 
            this.txtBinaireDeDec.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBinaireDeDec.Location = new System.Drawing.Point(583, 140);
            this.txtBinaireDeDec.Margin = new System.Windows.Forms.Padding(5);
            this.txtBinaireDeDec.Name = "txtBinaireDeDec";
            this.txtBinaireDeDec.ReadOnly = true;
            this.txtBinaireDeDec.Size = new System.Drawing.Size(211, 30);
            this.txtBinaireDeDec.TabIndex = 51;
            // 
            // txtDecimalABin
            // 
            this.txtDecimalABin.BackColor = System.Drawing.Color.White;
            this.txtDecimalABin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDecimalABin.Location = new System.Drawing.Point(63, 140);
            this.txtDecimalABin.Margin = new System.Windows.Forms.Padding(5);
            this.txtDecimalABin.Name = "txtDecimalABin";
            this.txtDecimalABin.Size = new System.Drawing.Size(212, 30);
            this.txtDecimalABin.TabIndex = 50;
            this.txtDecimalABin.Validating += new System.ComponentModel.CancelEventHandler(this.txtDecimalABin_Validating);
            // 
            // txtDecimalDeBin
            // 
            this.txtDecimalDeBin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDecimalDeBin.Location = new System.Drawing.Point(583, 62);
            this.txtDecimalDeBin.Margin = new System.Windows.Forms.Padding(5);
            this.txtDecimalDeBin.Name = "txtDecimalDeBin";
            this.txtDecimalDeBin.ReadOnly = true;
            this.txtDecimalDeBin.Size = new System.Drawing.Size(211, 30);
            this.txtDecimalDeBin.TabIndex = 49;
            // 
            // txtBinaireADec
            // 
            this.txtBinaireADec.BackColor = System.Drawing.Color.White;
            this.txtBinaireADec.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBinaireADec.Location = new System.Drawing.Point(63, 57);
            this.txtBinaireADec.Margin = new System.Windows.Forms.Padding(5);
            this.txtBinaireADec.Name = "txtBinaireADec";
            this.txtBinaireADec.Size = new System.Drawing.Size(212, 30);
            this.txtBinaireADec.TabIndex = 48;
            this.txtBinaireADec.Validating += new System.ComponentModel.CancelEventHandler(this.txtBinaireADec_Validating);
            // 
            // lblHexaDeBin
            // 
            this.lblHexaDeBin.AutoSize = true;
            this.lblHexaDeBin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHexaDeBin.Location = new System.Drawing.Point(575, 359);
            this.lblHexaDeBin.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblHexaDeBin.Name = "lblHexaDeBin";
            this.lblHexaDeBin.Size = new System.Drawing.Size(136, 25);
            this.lblHexaDeBin.TabIndex = 47;
            this.lblHexaDeBin.Text = "Hexadécimal";
            // 
            // lblBinAHexa
            // 
            this.lblBinAHexa.AutoSize = true;
            this.lblBinAHexa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBinAHexa.Location = new System.Drawing.Point(56, 359);
            this.lblBinAHexa.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblBinAHexa.Name = "lblBinAHexa";
            this.lblBinAHexa.Size = new System.Drawing.Size(79, 25);
            this.lblBinAHexa.TabIndex = 46;
            this.lblBinAHexa.Text = "Binaire";
            // 
            // lblBinDeHexa
            // 
            this.lblBinDeHexa.AutoSize = true;
            this.lblBinDeHexa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBinDeHexa.Location = new System.Drawing.Point(577, 442);
            this.lblBinDeHexa.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblBinDeHexa.Name = "lblBinDeHexa";
            this.lblBinDeHexa.Size = new System.Drawing.Size(79, 25);
            this.lblBinDeHexa.TabIndex = 45;
            this.lblBinDeHexa.Text = "Binaire";
            // 
            // lblHexaABin
            // 
            this.lblHexaABin.AutoSize = true;
            this.lblHexaABin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHexaABin.Location = new System.Drawing.Point(56, 439);
            this.lblHexaABin.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblHexaABin.Name = "lblHexaABin";
            this.lblHexaABin.Size = new System.Drawing.Size(136, 25);
            this.lblHexaABin.TabIndex = 44;
            this.lblHexaABin.Text = "Hexadécimal";
            // 
            // lblDecimalAHexa
            // 
            this.lblDecimalAHexa.AutoSize = true;
            this.lblDecimalAHexa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDecimalAHexa.Location = new System.Drawing.Point(56, 276);
            this.lblDecimalAHexa.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblDecimalAHexa.Name = "lblDecimalAHexa";
            this.lblDecimalAHexa.Size = new System.Drawing.Size(89, 25);
            this.lblDecimalAHexa.TabIndex = 43;
            this.lblDecimalAHexa.Text = "Décimal";
            // 
            // lblHexaDeDec
            // 
            this.lblHexaDeDec.AutoSize = true;
            this.lblHexaDeDec.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHexaDeDec.Location = new System.Drawing.Point(575, 276);
            this.lblHexaDeDec.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblHexaDeDec.Name = "lblHexaDeDec";
            this.lblHexaDeDec.Size = new System.Drawing.Size(136, 25);
            this.lblHexaDeDec.TabIndex = 42;
            this.lblHexaDeDec.Text = "Hexadécimal";
            // 
            // lblHexaADec
            // 
            this.lblHexaADec.AutoSize = true;
            this.lblHexaADec.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHexaADec.Location = new System.Drawing.Point(56, 194);
            this.lblHexaADec.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblHexaADec.Name = "lblHexaADec";
            this.lblHexaADec.Size = new System.Drawing.Size(136, 25);
            this.lblHexaADec.TabIndex = 41;
            this.lblHexaADec.Text = "Hexadécimal";
            // 
            // lblDecimalDeHexa
            // 
            this.lblDecimalDeHexa.AutoSize = true;
            this.lblDecimalDeHexa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDecimalDeHexa.Location = new System.Drawing.Point(577, 199);
            this.lblDecimalDeHexa.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblDecimalDeHexa.Name = "lblDecimalDeHexa";
            this.lblDecimalDeHexa.Size = new System.Drawing.Size(89, 25);
            this.lblDecimalDeHexa.TabIndex = 40;
            this.lblDecimalDeHexa.Text = "Décimal";
            // 
            // lblBinaireDeDec
            // 
            this.lblBinaireDeDec.AutoSize = true;
            this.lblBinaireDeDec.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBinaireDeDec.Location = new System.Drawing.Point(575, 112);
            this.lblBinaireDeDec.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblBinaireDeDec.Name = "lblBinaireDeDec";
            this.lblBinaireDeDec.Size = new System.Drawing.Size(79, 25);
            this.lblBinaireDeDec.TabIndex = 39;
            this.lblBinaireDeDec.Text = "Binaire";
            // 
            // lblDecimalABin
            // 
            this.lblDecimalABin.AutoSize = true;
            this.lblDecimalABin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDecimalABin.Location = new System.Drawing.Point(56, 112);
            this.lblDecimalABin.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblDecimalABin.Name = "lblDecimalABin";
            this.lblDecimalABin.Size = new System.Drawing.Size(89, 25);
            this.lblDecimalABin.TabIndex = 38;
            this.lblDecimalABin.Text = "Décimal";
            // 
            // lblDecimalDeBin
            // 
            this.lblDecimalDeBin.AutoSize = true;
            this.lblDecimalDeBin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDecimalDeBin.Location = new System.Drawing.Point(575, 26);
            this.lblDecimalDeBin.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblDecimalDeBin.Name = "lblDecimalDeBin";
            this.lblDecimalDeBin.Size = new System.Drawing.Size(89, 25);
            this.lblDecimalDeBin.TabIndex = 37;
            this.lblDecimalDeBin.Text = "Décimal";
            // 
            // lblBinaireADec
            // 
            this.lblBinaireADec.AutoSize = true;
            this.lblBinaireADec.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBinaireADec.Location = new System.Drawing.Point(56, 26);
            this.lblBinaireADec.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblBinaireADec.Name = "lblBinaireADec";
            this.lblBinaireADec.Size = new System.Drawing.Size(79, 25);
            this.lblBinaireADec.TabIndex = 36;
            this.lblBinaireADec.Text = "Binaire";
            // 
            // btnHexaBinaire
            // 
            this.btnHexaBinaire.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHexaBinaire.Location = new System.Drawing.Point(344, 468);
            this.btnHexaBinaire.Margin = new System.Windows.Forms.Padding(5);
            this.btnHexaBinaire.Name = "btnHexaBinaire";
            this.btnHexaBinaire.Size = new System.Drawing.Size(149, 34);
            this.btnHexaBinaire.TabIndex = 35;
            this.btnHexaBinaire.Text = "-->";
            this.btnHexaBinaire.UseVisualStyleBackColor = true;
            this.btnHexaBinaire.Click += new System.EventHandler(this.btnHexaBinaire_Click);
            // 
            // btnBinaireHexa
            // 
            this.btnBinaireHexa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBinaireHexa.Location = new System.Drawing.Point(344, 384);
            this.btnBinaireHexa.Margin = new System.Windows.Forms.Padding(5);
            this.btnBinaireHexa.Name = "btnBinaireHexa";
            this.btnBinaireHexa.Size = new System.Drawing.Size(149, 34);
            this.btnBinaireHexa.TabIndex = 34;
            this.btnBinaireHexa.Text = "-->";
            this.btnBinaireHexa.UseVisualStyleBackColor = true;
            this.btnBinaireHexa.Click += new System.EventHandler(this.btnBinaireHexa_Click);
            // 
            // btnDecimalHexa
            // 
            this.btnDecimalHexa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDecimalHexa.Location = new System.Drawing.Point(344, 302);
            this.btnDecimalHexa.Margin = new System.Windows.Forms.Padding(5);
            this.btnDecimalHexa.Name = "btnDecimalHexa";
            this.btnDecimalHexa.Size = new System.Drawing.Size(149, 34);
            this.btnDecimalHexa.TabIndex = 33;
            this.btnDecimalHexa.Text = "-->";
            this.btnDecimalHexa.UseVisualStyleBackColor = true;
            this.btnDecimalHexa.Click += new System.EventHandler(this.btnDecimalHexa_Click);
            // 
            // btnHexaDecimal
            // 
            this.btnHexaDecimal.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHexaDecimal.Location = new System.Drawing.Point(344, 226);
            this.btnHexaDecimal.Margin = new System.Windows.Forms.Padding(5);
            this.btnHexaDecimal.Name = "btnHexaDecimal";
            this.btnHexaDecimal.Size = new System.Drawing.Size(149, 34);
            this.btnHexaDecimal.TabIndex = 32;
            this.btnHexaDecimal.Text = "-->";
            this.btnHexaDecimal.UseVisualStyleBackColor = true;
            this.btnHexaDecimal.Click += new System.EventHandler(this.btnHexaDecimal_Click);
            // 
            // btnDecimalBinaire
            // 
            this.btnDecimalBinaire.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDecimalBinaire.Location = new System.Drawing.Point(344, 138);
            this.btnDecimalBinaire.Margin = new System.Windows.Forms.Padding(5);
            this.btnDecimalBinaire.Name = "btnDecimalBinaire";
            this.btnDecimalBinaire.Size = new System.Drawing.Size(149, 34);
            this.btnDecimalBinaire.TabIndex = 31;
            this.btnDecimalBinaire.Text = "-->";
            this.btnDecimalBinaire.UseVisualStyleBackColor = true;
            this.btnDecimalBinaire.Click += new System.EventHandler(this.btnDecimalBinaire_Click);
            // 
            // btnBinaireDecimal
            // 
            this.btnBinaireDecimal.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBinaireDecimal.Location = new System.Drawing.Point(344, 57);
            this.btnBinaireDecimal.Margin = new System.Windows.Forms.Padding(5);
            this.btnBinaireDecimal.Name = "btnBinaireDecimal";
            this.btnBinaireDecimal.Size = new System.Drawing.Size(149, 34);
            this.btnBinaireDecimal.TabIndex = 30;
            this.btnBinaireDecimal.Text = "-->";
            this.btnBinaireDecimal.UseVisualStyleBackColor = true;
            this.btnBinaireDecimal.Click += new System.EventHandler(this.btnBinaireDecimal_Click);
            // 
            // frmConversions
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(873, 554);
            this.Controls.Add(this.txtBinDeHexa);
            this.Controls.Add(this.txtHexaABin);
            this.Controls.Add(this.txtHexaDeBin);
            this.Controls.Add(this.txtBinAHexa);
            this.Controls.Add(this.txtHexaDeDec);
            this.Controls.Add(this.txtDecimalAHexa);
            this.Controls.Add(this.txtDecimalDeHexa);
            this.Controls.Add(this.txtHexaADec);
            this.Controls.Add(this.txtBinaireDeDec);
            this.Controls.Add(this.txtDecimalABin);
            this.Controls.Add(this.txtDecimalDeBin);
            this.Controls.Add(this.txtBinaireADec);
            this.Controls.Add(this.lblHexaDeBin);
            this.Controls.Add(this.lblBinAHexa);
            this.Controls.Add(this.lblBinDeHexa);
            this.Controls.Add(this.lblHexaABin);
            this.Controls.Add(this.lblDecimalAHexa);
            this.Controls.Add(this.lblHexaDeDec);
            this.Controls.Add(this.lblHexaADec);
            this.Controls.Add(this.lblDecimalDeHexa);
            this.Controls.Add(this.lblBinaireDeDec);
            this.Controls.Add(this.lblDecimalABin);
            this.Controls.Add(this.lblDecimalDeBin);
            this.Controls.Add(this.lblBinaireADec);
            this.Controls.Add(this.btnHexaBinaire);
            this.Controls.Add(this.btnBinaireHexa);
            this.Controls.Add(this.btnDecimalHexa);
            this.Controls.Add(this.btnHexaDecimal);
            this.Controls.Add(this.btnDecimalBinaire);
            this.Controls.Add(this.btnBinaireDecimal);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmConversions";
            this.Text = "Les conversions - Jérémie Normand";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtBinDeHexa;
        private System.Windows.Forms.TextBox txtHexaABin;
        private System.Windows.Forms.TextBox txtHexaDeBin;
        private System.Windows.Forms.TextBox txtBinAHexa;
        private System.Windows.Forms.TextBox txtHexaDeDec;
        private System.Windows.Forms.TextBox txtDecimalAHexa;
        private System.Windows.Forms.TextBox txtDecimalDeHexa;
        private System.Windows.Forms.TextBox txtHexaADec;
        private System.Windows.Forms.TextBox txtBinaireDeDec;
        private System.Windows.Forms.TextBox txtDecimalABin;
        private System.Windows.Forms.TextBox txtDecimalDeBin;
        private System.Windows.Forms.TextBox txtBinaireADec;
        private System.Windows.Forms.Label lblHexaDeBin;
        private System.Windows.Forms.Label lblBinAHexa;
        private System.Windows.Forms.Label lblBinDeHexa;
        private System.Windows.Forms.Label lblHexaABin;
        private System.Windows.Forms.Label lblDecimalAHexa;
        private System.Windows.Forms.Label lblHexaDeDec;
        private System.Windows.Forms.Label lblHexaADec;
        private System.Windows.Forms.Label lblDecimalDeHexa;
        private System.Windows.Forms.Label lblBinaireDeDec;
        private System.Windows.Forms.Label lblDecimalABin;
        private System.Windows.Forms.Label lblDecimalDeBin;
        private System.Windows.Forms.Label lblBinaireADec;
        private System.Windows.Forms.Button btnHexaBinaire;
        private System.Windows.Forms.Button btnBinaireHexa;
        private System.Windows.Forms.Button btnDecimalHexa;
        private System.Windows.Forms.Button btnHexaDecimal;
        private System.Windows.Forms.Button btnDecimalBinaire;
        private System.Windows.Forms.Button btnBinaireDecimal;
    }
}

